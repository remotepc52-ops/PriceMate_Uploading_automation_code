from urllib.parse import urljoin


from config import *
cookies = {
    'session-id': '356-0471235-3154402',
    'session-id-time': '2082787201l',
    'i18n-prefs': 'SGD',
    'lc-acbsg': 'en_SG',
    'ubid-acbsg': '356-9598858-3488666',
    'session-token': 'iBkV6JvS6s+pBIGBhayi1D/kRm5GLd8272uLBTy5tqZKMEsPElmBfR+6fYMou1XohbU9zCwB2ki65YugoMGHPVjF+dTLhCrnDJlnXDcSTphJ5ANIc4UMLhKa61zO5t4RUBQDzkf4G+dAPMW+DQZNqBcfHS7aWhUBnIHWn4avrZCAnCB4NAw1vyfoYxI5eLXowsRBclvx1xxYCMQes6MqHQ4EI/AT8dL44LPXIch17MAfz3AmYZw/uP9BNUVUnbh40ZVS6tBODSpzMVG77/RaYNivrwNoaDUxDiFC7OrxXcikep4eFY40C186pKFZDT5ykXCwz6CYh/XmlVa7VfNq9wbAgHxcC24s',
    'csm-hit': 'tb:s-7JVV8FZXY6TQB4N85MHD|1767165321060&t:1767165321188&adb:adblk_no',
    'rxc': 'ABNj3kgv/4zAnQZqyaI',
}

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9,hi;q=0.8',
    'cache-control': 'max-age=0',
    'device-memory': '8',
    'downlink': '10',
    'dpr': '1.25',
    'ect': '4g',
    'priority': 'u=0, i',
    'rtt': '100',
    'sec-ch-device-memory': '8',
    'sec-ch-dpr': '1.25',
    'sec-ch-ua': '"Google Chrome";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
    'sec-ch-ua-full-version-list': '"Google Chrome";v="143.0.7499.170", "Chromium";v="143.0.7499.170", "Not A(Brand";v="24.0.0.0"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-ch-ua-platform-version': '"19.0.0"',
    'sec-ch-viewport-width': '1536',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
    'viewport-width': '1536',
    # 'cookie': 'session-id=356-0471235-3154402; session-id-time=2082787201l; i18n-prefs=SGD; lc-acbsg=en_SG; ubid-acbsg=356-9598858-3488666; session-token=iBkV6JvS6s+pBIGBhayi1D/kRm5GLd8272uLBTy5tqZKMEsPElmBfR+6fYMou1XohbU9zCwB2ki65YugoMGHPVjF+dTLhCrnDJlnXDcSTphJ5ANIc4UMLhKa61zO5t4RUBQDzkf4G+dAPMW+DQZNqBcfHS7aWhUBnIHWn4avrZCAnCB4NAw1vyfoYxI5eLXowsRBclvx1xxYCMQes6MqHQ4EI/AT8dL44LPXIch17MAfz3AmYZw/uP9BNUVUnbh40ZVS6tBODSpzMVG77/RaYNivrwNoaDUxDiFC7OrxXcikep4eFY40C186pKFZDT5ykXCwz6CYh/XmlVa7VfNq9wbAgHxcC24s; csm-hit=tb:s-7JVV8FZXY6TQB4N85MHD|1767165321060&t:1767165321188&adb:adblk_no; rxc=ABNj3kgv/4zAnQZqyaI',
}

params = {
    'almBrandId': 'KQENHJywk4',
    'ref': 'watso_dsk_sn_logo-4440d',
}

response = requests.get(
    "https://www.amazon.sg/alm/storefront/watsons",
    params=params,
    cookies=cookies,
    headers=headers
)

base_url = "https://www.amazon.sg"

if response.status_code == 200:
    selector = Selector(response.text)

    hrefs = selector.xpath(
        "//li[contains(@class,'sl-sobe-carousel-sub-card')]//a/@href"
    ).getall()

    for h in hrefs:
        if not h or h == "/":
            continue

        link = urljoin(base_url, h)

        cat_gory = {
            "cat_url": link,
            "Status": "Pending"
        }

        print("CATEGORY:", cat_gory)

        # ⬇️ INSERT HERE
        search_data.insert_one(cat_gory)
        cat_link_response = requests.get(
            link,
            cookies=cookies,
            headers=headers,
        )

        if cat_link_response.status_code == 200:

            main_selector = Selector(cat_link_response.text)

            all_cats = main_selector.xpath(
                "//div[contains(@id,'parentCarousel-alm-legacy-merchandised-strategy')]//h2//a[text()='See all']/@href"
            ).getall()

            if not all_cats:
                all_cats = main_selector.xpath(
                    "//span[contains(@class,'_Y29ud_bxcGridButtonLight')]//a/@href"
                ).getall()

            for m in all_cats:
                if not m or m == "/":
                    continue

                cat_links = urljoin(base_url, m)

                main_category = {
                    "cat_url": cat_links,
                    "Status": "Pending"
                }

                print("SEE ALL:", main_category)
                search_data.insert_one(main_category)



