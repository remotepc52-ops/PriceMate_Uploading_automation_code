from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urljoin
from config import *
import requests, json, html

cookies = {
    'session-id': '356-0471235-3154402',
    'session-id-time': '2082787201l',
    'i18n-prefs': 'SGD',
    'lc-acbsg': 'en_SG',
    'ubid-acbsg': '356-9598858-3488666',
    'session-token': 'yUqqaqEatZ4F7F/WH+dK8YBbRcYurd3HYyskmGlp2ELJXvjhhaGIaQwkuM+X7PPS+GCziOuqYU4acVo3zY/XvzR1s/1HcDFeNb3ONSQke5S8lA0Krp/khzhyRI/MaE0dJ4r+FTC1IFyYkdSROhjeVkg0NGyiCKXbbAAXbzqBPIOTkhbwudQLR8HliLGKZct/Vo6S1UFjTE/ZhmW5V2Eorsj3d0Plq3Anqjn1ZJVyBwxGl/x2efdwMjbrhaDEeVSVoR+RyNk7jyXIR/GQ87g0rI/lCm+qr3PZYwMj58sNZOC+muz/hacaSuekpBuhW7shWx0nj9iMOR14K6wp0e+gY21k5f4IUYDZ',
    'csm-hit': 'tb:V9Q72ME46VX0Q0RKCVPP+b-YMVW22QQ9SKV4GFPWPDH|1767171087162&t:1767171087162&adb:adblk_no',
    'rxc': 'ABNj3kiS1ozAnQZqyaI',
}

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9,hi;q=0.8',
    'cache-control': 'max-age=0',
    'device-memory': '8',
    'downlink': '10',
    'dpr': '1.25',
    'ect': '4g',
    'priority': 'u=0, i',
    'rtt': '100',
    'sec-ch-device-memory': '8',
    'sec-ch-dpr': '1.25',
    'sec-ch-ua': '"Google Chrome";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
    'sec-ch-ua-full-version-list': '"Google Chrome";v="143.0.7499.170", "Chromium";v="143.0.7499.170", "Not A(Brand";v="24.0.0.0"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-ch-ua-platform-version': '"19.0.0"',
    'sec-ch-viewport-width': '1536',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
    'viewport-width': '1536',
    # 'cookie': 'session-id=356-0471235-3154402; session-id-time=2082787201l; i18n-prefs=SGD; lc-acbsg=en_SG; ubid-acbsg=356-9598858-3488666; session-token=yUqqaqEatZ4F7F/WH+dK8YBbRcYurd3HYyskmGlp2ELJXvjhhaGIaQwkuM+X7PPS+GCziOuqYU4acVo3zY/XvzR1s/1HcDFeNb3ONSQke5S8lA0Krp/khzhyRI/MaE0dJ4r+FTC1IFyYkdSROhjeVkg0NGyiCKXbbAAXbzqBPIOTkhbwudQLR8HliLGKZct/Vo6S1UFjTE/ZhmW5V2Eorsj3d0Plq3Anqjn1ZJVyBwxGl/x2efdwMjbrhaDEeVSVoR+RyNk7jyXIR/GQ87g0rI/lCm+qr3PZYwMj58sNZOC+muz/hacaSuekpBuhW7shWx0nj9iMOR14K6wp0e+gY21k5f4IUYDZ; csm-hit=tb:V9Q72ME46VX0Q0RKCVPP+b-YMVW22QQ9SKV4GFPWPDH|1767171087162&t:1767171087162&adb:adblk_no; rxc=ABNj3kiS1ozAnQZqyaI',
}
base_url = "https://www.amazon.sg"

def insert_product(asin):
    product_url = f"{base_url}/dp/{asin}"

    product = {
        "product_url": product_url,
        "ProductCode": asin,
        "Status": "Pending"
    }

    print("INSERT:", product)

    try:
        main_data.insert_one(product)
    except Exception as e:
        print("INSERT ERROR:", e)


def process_document(doc):
    category_url = doc['cat_url']
    url = category_url
    page = 1

    while url:
        print(f"\n==========================")
        print(f"PAGE : {page}  -->  {url}")
        print(f"==========================")

        response = requests.get(url, cookies=cookies, headers=headers)

        if response.status_code != 200:
            print("REQUEST FAILED", response.status_code)
            break

        selector = Selector(response.text)

        # ------------------------------------------------
        # 1️⃣ NORMAL CATEGORY / SEARCH RESULT PAGES
        # ------------------------------------------------
        p_urls = selector.xpath(".//a[contains(@href, '/dp/')]/@href").getall()

        p_urls = selector.xpath(".//a[contains(@href, '/dp/')]/@href").getall()

        if p_urls:
            for p in p_urls:
                if not p:
                    continue

                clean = p.split("?")[0]
                full = urljoin(base_url, clean)

                try:
                    asin = full.split("/dp/")[1].split("/")[0]
                    insert_product(asin)
                except:
                    pass

        # ------------------------------------------------
        # 2️⃣ CLIENT GRID (LOADING TYPE UI)
        # Always try this ALSO — not inside else
        # ------------------------------------------------
        print("TRYING CLIENT GRID MODE")

        client_blocks = selector.xpath(
            "//div[contains(@data-client-recs-list,'pd_rd_i')]/@data-client-recs-list"
        ).getall()

        for block in client_blocks:
            try:
                decoded = html.unescape(block)

                # Make valid JSON array
                fixed = f"[{decoded}]"
                items = json.loads(fixed)

                for item in items:
                    asin = item.get("id")
                    if asin:
                        insert_product(asin)

            except Exception as e:
                print("CLIENT GRID PARSE ERROR:", e)

            # ------------------------------------------------
            # 3️⃣ data-client-recs-list MODE
            # (ASINs are embedded in full HTML JSON blocks)
            # ------------------------------------------------


        # ------------------------------------------------
        # PAGINATION
        # ------------------------------------------------
        next_page = selector.xpath(
            "//a[contains(@class,'s-pagination-next') and not(@aria-disabled)]/@href"
        ).get()

        if next_page:
            url = urljoin(base_url, next_page)
            page += 1
        else:
            url = None
    search_data.update_one(
        {"_id": doc["_id"]},
        {"$set": {"Status": "Done"}}
    )
    print(f"STATUS UPDATED TO DONE → {category_url}")


if __name__ == "__main__":
    docs = list(search_data.find({"Status": "Pending"}))

    with ThreadPoolExecutor(max_workers=10) as executor:
        executor.map(process_document, docs)