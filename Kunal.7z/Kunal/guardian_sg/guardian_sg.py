import json
from concurrent.futures import ThreadPoolExecutor
from config import *
import requests

current_proxy = '2c6ea6e6d8c14216a62781b8f850cd5b'

proxy_host = "api.zyte.com"
proxy_port = "8011"
proxy_auth = f"{current_proxy}:"

zyte_proxies = {
    "http": "https://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port),
    "https": "http://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port)
}

def process_document(doc):
    referer_url = doc['url']
    doc_id = doc['_id']
    cat_id = doc['cat_id']
    page = 1
    title = referer_url.rstrip('/').split('/')[-1].replace('-', ' ')
    main_title = referer_url.rstrip('/').split('/')[-1].replace('-', ' ').title()
    total_pages = 1

    while page <= total_pages:
        cookies = {
            'PHPSESSID': 'b279649c90896e130e011b810d8dfc98',
            '_gcl_au': '1.1.1113879356.1750744735',
            '_fbp': 'fb.2.1750744735345.175167229390424008',
            '_ga': 'GA1.1.264370054.1750744735',
            '_qg_fts': '1750744736',
            'QGUserId': '1828891182410115',
            'aiq_cs_0d487b21e95c13344d9e': '[%22https:%22%2C%22guardian.com.sg%22%2Cnull%2C[[null%2C%22b%22]%2C[%22www%22%2C%22d%22]]]',
            '_tt_enable_cookie': '1',
            '_ttp': '01JYGS6H8C5J7FFWMWT8YK9K7A_.tt.2',
            '__qca': 'P1-2edda62e-9b96-48da-9379-40a754a65e34',
            '_qg_cm': '2',
            '_clck': '9kmz2l%7C2%7Cfxu%7C0%7C2001',
            '_qg_pushrequest': 'true',
            'tfpsi': '5e0d36ce-5b34-4813-a8ea-0278f52028b4',
            'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A197a0849ad1376-00e0452cfe28448-26011e51-144000-197a0849ad1376%22%2C%22%24device_id%22%3A%20%22197a0849ad1376-00e0452cfe28448-26011e51-144000-197a0849ad1376%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
            '_ga_R43R310S1K': 'GS2.1.s1753254928$o9$g1$t1753257174$j44$l0$h0',
            'ttcsid': '1753254996157::5aGPumPZfroywlPZ_oJB.7.1753257175810',
            'dicbo_id': '%7B%22dicbo_fetch%22%3A1753257176023%7D',
            'ttcsid_C7L5UB5ROSV8GC26I1DG': '1753254996148::QaWYdf8Dmcw-9_qPEGA2.7.1753257176116',
            'private_content_version': 'e934c826fb80ca6d16b9944f84dc9e6c',
            '_clsk': '15vvufw%7C1753257176753%7C9%7C1%7Ca.clarity.ms%2Fcollect',
        }
        headers = {
            'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
            'Connection': 'keep-alive',
            'Magento-Environment-Id': 'c584c612-9024-4412-83c0-b5272686bf83',
            'Magento-Store-Code': 'main_website_store',
            'Magento-Store-View-Code': 'default',
            'Magento-Website-Code': 'base',
            'Origin': 'https://guardian.com.sg',
            'Referer': 'https://guardian.com.sg/',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'cross-site',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
            'X-Api-Key': 'ec65acf46bf94166a991f66af1dee7ff',
            'accept': '*/*',
            'content-type': 'application/json',
            'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
        }

        params = {
            "query": """
                query productSearch($phrase: String!, $filter: [SearchClauseInput!], $current_page: Int, $page_size: Int, $sort: [ProductSearchSortInput!]) {
                    productSearch(phrase: $phrase, filter: $filter, current_page: $current_page, page_size: $page_size, sort: $sort) {
                        page_info {
                            total_pages
                            current_page
                        }
                        items {
                            product {
                                sku
                                canonical_url
                            }
                        }
                    }
                }
            """,
            "operationName": "productSearch",
            "variables": {
                "phrase": "",
                "current_page": page,
                "page_size": 12,
                "filter": [
                    {"attribute": "inStock", "eq": "true"},
                    {"attribute": "visibility", "in": ["Search", "Catalog", "Catalog, Search"]},
                    {"attribute": "price", "range": {"from": 0.01, "to": 999999}},
                    {"attribute": "categoryIds", "in": [f"{cat_id}"]},
                    {"attribute": "categoryPath", "in": f"{title}"},
                ],
                "sort": []
            }
        }

        response = requests.post(
            'https://catalog-service.adobe.io/graphql',
            json=params,
            headers=headers,
            proxies=zyte_proxies,
            verify=False,
        )

        if response.status_code == 200:
            data = response.json()
            result = data.get('data', {}).get('productSearch', {})
            page_info = result.get("page_info", {})
            total_pages = page_info.get("total_pages", 1)
            products = result.get('items', [])

            for product in products:
                sku = product.get('product', {}).get('sku')
                canonical_url = product.get('product', {}).get('canonical_url')
                main_url = f"https:{canonical_url}"

                headers_two = {
                    'accept': '*/*',
                    'content-type': 'application/json',
                    'referer': referer_url,
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
                }

                guardian_variables = {
                    "search": "",
                    "filter": {
                        "sku": {
                            "eq": sku
                        }
                    },
                    "pageSize": 12,
                    "currentPage": 1,
                    "sort": {}
                }

                guardian_params = {
                    "query": """
                    query getProductDetailV2($search: String, $filter: ProductAttributeFilterInput, $pageSize: Int, $currentPage: Int, $sort: ProductAttributeSortInput) {
                      products(search: $search, filter: $filter, pageSize: $pageSize, currentPage: $currentPage, sort: $sort) {
                        items {
                          name
                          sku
                          url_key
                          brand
                          stock_status
                          pack_size
                          measurement_unit  
                          price {
                            regularPrice {
                              amount {
                                value
                              }
                            }
                          }
                          price_range {
                            minimum_price {
                              final_price {
                                value
                              }
                            }
                            maximum_price {
                              discount {
                                percent_off
                              }
                            }
                          }
                          media_gallery_entries {
                            file
                            label
                          }
                        }
                      }
                    }
                    """,
                    "operationName": "getProductDetailV2",
                    "variables": json.dumps(guardian_variables)
                }


                guardian_response = requests.get(
                    'https://guardian.com.sg/graphql',
                    headers=headers_two,
                    params=guardian_params,
                    cookies=cookies,
                    proxies=zyte_proxies,
                    verify=False,
                )

                if guardian_response.status_code == 200:
                    print(guardian_response.text)
                    result = guardian_response.json()
                    items = result.get("data", {}).get("products", {}).get("items", [])
                    for item in items:
                        media = item.get('media_gallery_entries', [])
                        image_urls = []

                        for image in media:
                            file = image.get('file')
                            if file:
                                full_url = f"https://guardian.com.sg/media/catalog/product{file}"
                                image_urls.append(full_url)

                        joined_image_urls = " | ".join(image_urls)

                        name = item.get("name")
                        brand = item.get("brand")
                        stock = item.get("stock_status")
                        size = item.get('pack_size')
                        measurement = item.get('measurement_unit')

                        if size and measurement:
                            pack_size = f"{size} {measurement}"
                        elif size:
                            pack_size = str(size)
                        elif measurement:
                            pack_size = measurement
                        else:
                            pack_size = ""
                        url_key = item.get("url_key")
                        sku = item.get("sku")
                        was_price = item.get("price", {}).get("regularPrice", {}).get("amount", {}).get("value")
                        orignal_price = item.get("price_range", {}).get("minimum_price", {}).get("final_price", {}).get(
                            "value")
                        discount = item.get("price_range", {}).get("maximum_price", {}).get("discount", {}).get(
                            "percent_off")

                        was_price = float(was_price) if was_price else 0.0
                        orignal_price = float(orignal_price) if orignal_price else 0.0
                        discount = int(round(discount)) if discount else None

                        stock_status = stock == "IN_STOCK"
                        offer_info = f"{discount}% off" if discount else ""

                        if not was_price or orignal_price == was_price:
                            rrp_price = orignal_price
                            was_price = ""
                        else:
                            rrp_price = was_price

                        main_list = {
                            "Name": name,
                            "Promo_Type": "",
                            "Price": orignal_price,
                            "per_unit_price": "",
                            "WasPrice": was_price,
                            "Offer_info": offer_info,
                            "Pack_size": pack_size,
                            "Barcode": "",
                            "Images": joined_image_urls,
                            "ProductURL": main_url,
                            "is_available": stock_status,
                            "Status": "Done",
                            "ParentCode": "",
                            "ProductCode": sku,
                            "retailer_name": "Guardian",
                            "Category_Hierarchy": main_title,
                            "Brand": brand,
                            "RRP": rrp_price
                        }

                        try:
                            product_data.insert_one(main_list)
                            print("data inserting")
                            search_data.update_one({'_id': doc_id}, {'$set': {'Status': "Done"}})
                        except Exception as e:
                            print(e)
                else:
                    print(f"Guardian request failed for SKU {sku}: {guardian_response.status_code}")
        else:
            print(f"Catalog API request failed: {response.status_code}")
            break  # Stop if API fails

        page += 1  # ✅ Continue to next page if allowed


if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=30) as executor:
        docs = list(search_data.find({"Status": "Pending"}))
        executor.map(process_document, docs)
