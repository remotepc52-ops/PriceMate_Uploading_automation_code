import json
from concurrent.futures import ThreadPoolExecutor
from config import *
import requests

def process_document(doc):
    referer_url = doc['url']
    doc_id = doc['_id']
    cat_id = doc['cat_id']
    page = 1
    title = referer_url.rstrip('/').split('/')[-1].replace('-', ' ')
    main_title = referer_url.rstrip('/').split('/')[-1].replace('-', ' ').title()
    total_pages = 1  # Initialize total_pages

    while page <= total_pages:
        cookies = {
            'PHPSESSID': '64a97130730a5220806448608603c0cc',
            '_gcl_au': '1.1.1113879356.1750744735',
            '_fbp': 'fb.2.1750744735345.175167229390424008',
            '_ga': 'GA1.1.264370054.1750744735',
            '_qg_fts': '1750744736',
            'QGUserId': '1828891182410115',
            'aiq_cs_0d487b21e95c13344d9e': '[%22https:%22%2C%22guardian.com.sg%22%2Cnull%2C[[null%2C%22b%22]%2C[%22www%22%2C%22d%22]]]',
            '_tt_enable_cookie': '1',
            '_ttp': '01JYGS6H8C5J7FFWMWT8YK9K7A_.tt.2',
            '__qca': 'P1-2edda62e-9b96-48da-9379-40a754a65e34',
            '_qg_cm': '2',
            '_clck': '9kmz2l%7C2%7Cfxu%7C0%7C2001',
            '_qg_pushrequest': 'true',
            'tfpsi': '5e0d36ce-5b34-4813-a8ea-0278f52028b4',
            'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A197a0849ad1376-00e0452cfe28448-26011e51-144000-197a0849ad1376%22%2C%22%24device_id%22%3A%20%22197a0849ad1376-00e0452cfe28448-26011e51-144000-197a0849ad1376%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
            '_ga_R43R310S1K': 'GS2.1.s1753254928$o9$g1$t1753257174$j44$l0$h0',
            'ttcsid': '1753254996157::5aGPumPZfroywlPZ_oJB.7.1753257175810',
            'dicbo_id': '%7B%22dicbo_fetch%22%3A1753257176023%7D',
            'ttcsid_C7L5UB5ROSV8GC26I1DG': '1753254996148::QaWYdf8Dmcw-9_qPEGA2.7.1753257176116',
            'private_content_version': '2dfc1e4e16d06d54eff7780e6620c5fc',
            '_clsk': '15vvufw%7C1753257176753%7C9%7C1%7Ca.clarity.ms%2Fcollect',
        }
        headers = {
            'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
            'Connection': 'keep-alive',
            'Magento-Environment-Id': 'c584c612-9024-4412-83c0-b5272686bf83',
            'Magento-Store-Code': 'main_website_store',
            'Magento-Store-View-Code': 'default',
            'Magento-Website-Code': 'base',
            'Origin': 'https://guardian.com.sg',
            'Referer': 'https://guardian.com.sg/',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'cross-site',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
            'X-Api-Key': 'ec65acf46bf94166a991f66af1dee7ff',
            'accept': '*/*',
            'content-type': 'application/json',
            'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
        }

        params = {
            "query": """
                query productSearch($phrase: String!, $filter: [SearchClauseInput!], $current_page: Int, $page_size: Int, $sort: [ProductSearchSortInput!]) {
                    productSearch(phrase: $phrase, filter: $filter, current_page: $current_page, page_size: $page_size, sort: $sort) {
                        page_info {
                            total_pages
                            current_page
                        }
                        items {
                            product {
                                sku
                                canonical_url
                            }
                        }
                    }
                }
            """,
            "operationName": "productSearch",
            "variables": json.dumps({  # ✅ JSON encode inner variables dict
                "phrase": "",
                "current_page": page,
                "page_size": 12,
                "filter": [
                    {"attribute": "inStock", "eq": "true"},
                    {"attribute": "visibility", "in": ["Search", "Catalog", "Catalog, Search"]},
                    {"attribute": "price", "range": {"from": 0.01, "to": 999999}},
                    {"attribute": "categoryIds", "in": [str(cat_id)]},  # ✅ ensure string
                    {"attribute": "categoryPath", "in": [str(title)]},  # ✅ ensure list
                ],
                "sort": []
            })
        }

        # Generate file name
        unique_key = f"{cat_id}-{page}"
        hashid = generate_hashId(unique_key)
        html_filename = f"PL_{hashid}_page.json"
        html_filepath = os.path.join(html_path, html_filename)

        # Make request
        response = obj.to_requests(
            url='https://catalog-service.adobe.io/graphql',
            headers=headers,
            params=params,
            html_path=html_filepath,
            should_be=['productSearch'],
            max_retry=3
        )
        if not response:
            print(f"Getting wrong response: {referer_url}")
            return None
        elif 'Result Not Found' in response or 'This product is invalid.' in response or 'This page could not be found' in response:
            search_data.update_one({'_id': id}, {'$set': {'Status': "Not found"}})
            print("Status Updated...")
            return None
        else:
            try:
                data = json.loads(response)
            except Exception as e:
                print(f"Error parsing JSON on page {page}: {e}")
                return None

            result = data.get('data', {}).get('productSearch', {})
            page_info = result.get("page_info", {})
            total_pages = page_info.get("total_pages", 1)

            # ❗ EARLY EXIT IF WE'VE REACHED MAX PAGES
            if page > total_pages:
                print(f"Page {page} exceeds total_pages {total_pages}, stopping.")
                break

            products = result.get('items', [])
            for product in products:
                sku = product.get('product', {}).get('sku')
                canonical_url = product.get('product', {}).get('canonical_url')
                main_url = f"https:{canonical_url}"

                headers_two = {
                    'accept': '*/*',
                    'content-type': 'application/json',
                    'referer': referer_url,
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
                    'cookie': 'PHPSESSID=64a97130730a5220806448608603c0cc; _gcl_au=1.1.1113879356.1750744735; _fbp=fb.2.1750744735345.175167229390424008; _ga=GA1.1.264370054.1750744735; _qg_fts=1750744736; QGUserId=1828891182410115; aiq_cs_0d487b21e95c13344d9e=[%22https:%22%2C%22guardian.com.sg%22%2Cnull%2C[[null%2C%22b%22]%2C[%22www%22%2C%22d%22]]]; _tt_enable_cookie=1; _ttp=01JYGS6H8C5J7FFWMWT8YK9K7A_.tt.2; __qca=P1-2edda62e-9b96-48da-9379-40a754a65e34; _qg_cm=2; _qg_pushrequest=true; dicbo_id=%7B%22dicbo_fetch%22%3A1753335912934%7D; _clck=9kmz2l%7C2%7Cfxv%7C0%7C2001; tfpsi=80822c28-4b45-4a69-a0b8-b5e5344c5502; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A1983787e95b19f-06a3e72ec038948-26011151-144000-1983787e95b19f%22%2C%22%24device_id%22%3A%20%221983787e95b19f-06a3e72ec038948-26011151-144000-1983787e95b19f%22%2C%22%24initial_referrer%22%3A%20%22https%3A%2F%2Fguardian.com.sg%2Fhair-care.html%22%2C%22%24initial_referring_domain%22%3A%20%22guardian.com.sg%22%7D; _ga_R43R310S1K=GS2.1.s1753335912$o14$g1$t1753336129$j9$l0$h0; ttcsid=1753335913396::i8Yp_H0vpNt9Zk48_wa4.10.1753336130207; ttcsid_C7L5UB5ROSV8GC26I1DG=1753335913388::3eqasZJImUdTo_S2l6dw.10.1753336130458; _clsk=1foko8w%7C1753336130960%7C5%7C1%7Ca.clarity.ms%2Fcollect; private_content_version=dc0ef717cd54da3ec62c31ae6816d064',

                }

                guardian_variables = {
                    "search": "",
                    "filter": {
                        "sku": {
                            "eq": sku
                        }
                    },
                    "pageSize": 12,
                    "currentPage": 1,
                    "sort": {}
                }

                guardian_params = {
                    "query": """
                    query getProductDetailV2($search: String, $filter: ProductAttributeFilterInput, $pageSize: Int, $currentPage: Int, $sort: ProductAttributeSortInput) {
                      products(search: $search, filter: $filter, pageSize: $pageSize, currentPage: $currentPage, sort: $sort) {
                        items {
                          name
                          sku
                          url_key
                          brand
                          stock_status
                          pack_size
                          measurement_unit  
                          price {
                            regularPrice {
                              amount {
                                value
                              }
                            }
                          }
                          price_range {
                            minimum_price {
                              final_price {
                                value
                              }
                            }
                            maximum_price {
                              discount {
                                percent_off
                              }
                            }
                          }
                          media_gallery_entries {
                            file
                            label
                          }
                        }
                      }
                    }
                    """,
                    "operationName": "getProductDetailV2",
                    "variables": json.dumps(guardian_variables)
                }

                unique_key = f"{sku}-{page}"
                hashid = generate_hashId(unique_key)
                html_filename = f"PL_{hashid}_page.json"
                html_filepath = os.path.join(html_path, html_filename)

                guardian_response = obj.to_requests('https://guardian.com.sg/graphql', params=guardian_params,
                                                headers=headers_two, html_path=html_filepath,
                                                should_be=['media_gallery_entries'], max_retry=3)

                if not guardian_response:
                    print(f"getting wrong response:{referer_url}")
                    return None
                elif 'Result Not Found' in guardian_response or 'This product is invalid.' in guardian_response or 'This page could not be found' in guardian_response:
                    search_data.update_one(
                        {'_id': id}, {'$set': {'Status': "Not found"}})
                    print("Status Updated...")
                elif guardian_response:


                    result = json.loads(guardian_response)
                    items = result.get("data", {}).get("products", {}).get("items", [])
                    for item in items:
                        media = item.get('media_gallery_entries', [])
                        image_urls = []

                        for image in media:
                            file = image.get('file')
                            if file:
                                full_url = f"https://guardian.com.sg/media/catalog/product{file}"
                                image_urls.append(full_url)

                        joined_image_urls = " | ".join(image_urls)

                        name = item.get("name")
                        brand = item.get("brand")
                        stock = item.get("stock_status")
                        size = item.get('pack_size')
                        measurement = item.get('measurement_unit')

                        if size and measurement:
                            pack_size = f"{size} {measurement}"
                        elif size:
                            pack_size = str(size)
                        elif measurement:
                            pack_size = measurement
                        else:
                            pack_size = ""
                        url_key = item.get("url_key")
                        sku = item.get("sku")
                        was_price = item.get("price", {}).get("regularPrice", {}).get("amount", {}).get("value")
                        orignal_price = item.get("price_range", {}).get("minimum_price", {}).get("final_price", {}).get("value")
                        discount = item.get("price_range", {}).get("maximum_price", {}).get("discount", {}).get("percent_off")

                        was_price = float(was_price) if was_price else 0.0
                        orignal_price = float(orignal_price) if orignal_price else 0.0
                        discount = int(round(discount)) if discount else None

                        stock_status = stock == "IN_STOCK"
                        offer_info = f"{discount}% off" if discount else ""

                        if not was_price or orignal_price == was_price:
                            rrp_price = orignal_price
                            was_price = ""
                        else:
                            rrp_price = was_price

                        main_list = {
                            "Name": name,
                            "Promo_Type": "",
                            "Price": orignal_price,
                            "per_unit_price": "",
                            "WasPrice": was_price,
                            "Offer_info": offer_info,
                            "Pack_size": pack_size,
                            "Barcode": "",
                            "Images": joined_image_urls,
                            "ProductURL": main_url,
                            "is_available": stock_status,
                            "Status": "Done",
                            "ParentCode": "",
                            "ProductCode": sku,
                            "retailer_name": "Guardian",
                            "Category_Hierarchy": main_title,
                            "Brand": brand,
                            "RRP": rrp_price
                        }

                        try:
                            product_data.insert_one(main_list)
                            search_data.update_one({'_id': doc_id}, {'$set': {'Status': "Not found"}})
                        except Exception as e:
                            print(e)
                else:
                    print(f"Guardian request failed for SKU {sku}: {guardian_response.status_code}")


        page += 1  # ✅ Continue to next page if allowed

if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=20) as executor:
        docs = list(search_data.find({"Status": "Pending"}))
        print(f"Found {len(docs)} documents with Status: Pending")  # ✅ Add this
        executor.map(process_document, docs)
