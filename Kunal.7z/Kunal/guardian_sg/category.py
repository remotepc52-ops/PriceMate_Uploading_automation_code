from config import *
headers = {
    'accept': '*/*',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
    'authorization': '',
    'content-type': 'application/json',
    'priority': 'u=1, i',
    'referer': 'https://www.guardian.com.sg/',
    'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'store': 'default',
    # 'traceparent': '00-f1507234d6868525e400d9f683ff5543-e8f656fd82c15e16-01',
    # 'tracestate': '1322840@nr=0-1-4173002-1120259267-e8f656fd82c15e16----1750762677210',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    'cookie': 'PHPSESSID=64a97130730a5220806448608603c0cc; _gcl_au=1.1.1113879356.1750744735; _fbp=fb.2.1750744735345.175167229390424008; _ga=GA1.1.264370054.1750744735; _clck=9kmz2l%7C2%7Cfx1%7C0%7C2001; _qg_fts=1750744736; QGUserId=1828891182410115; _qg_cm=2; PHPSESSID=64a97130730a5220806448608603c0cc; _qg_pushrequest=true; aiq_cs_0d487b21e95c13344d9e=[%22https:%22%2C%22guardian.com.sg%22%2Cnull%2C[[null%2C%22b%22]%2C[%22www%22%2C%22d%22]]]; tfpsi=f9f100b5-170a-47df-b49a-3d7ffc296a97; _tt_enable_cookie=1; _ttp=01JYGS6H8C5J7FFWMWT8YK9K7A_.tt.2; dicbo_id=%7B%22dicbo_fetch%22%3A1750762473064%7D; ttcsid=1750762472718::_BraefOzMpbgezLprmJP.1.1750762475330; _clsk=1rifzis%7C1750762476484%7C2%7C1%7Cv.clarity.ms%2Fcollect; private_content_version=2a6c03b2b58892c15e413bf886147726; ttcsid_C7L5UB5ROSV8GC26I1DG=1750762472718::1ekAFo4RUPftVCErAQji.1.1750762493228; _ga_R43R310S1K=GS2.1.s1750762472$o3$g1$t1750762676$j60$l0$h0; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A197a0849ad1376-00e0452cfe28448-26011e51-144000-197a0849ad1376%22%2C%22%24device_id%22%3A%20%22197a0849ad1376-00e0452cfe28448-26011e51-144000-197a0849ad1376%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
}

params = {
    'query': 'query GetNavigationMenu($id:Int!){category(id:$id){id name display_mode product_count children{product_count children_count id include_in_menu name position url_path url_suffix dropdown_image_link image promo_logo description popular_brand popular_brands_childs{id name url_path url_suffix __typename}children{product_count children_count id include_in_menu name position url_path url_suffix dropdown_image_link image promo_logo popular_brand popular_brands_childs{id name url_path url_suffix __typename}children{product_count children_count id include_in_menu name position url_path url_suffix dropdown_image_link image promo_logo __typename}__typename}__typename}image include_in_menu url_path url_suffix __typename}}',
    'operationName': 'GetNavigationMenu',
    'variables': '{"id":2,"source_code":null}',
}

response = requests.get('https://guardian.com.sg/graphql', params=params, headers=headers)
if response.status_code== 200:
    data = response.json()
    children = data.get('data',{}).get('category',{}).get('children',{})
    for child in children:
        url_key = child.get('url_path')
        id = child.get('id')

        url = f"https://guardian.com.sg/{url_key}"

        existing = search_data.find_one({"url": url})

        if not existing:
            document = {
                "cat_id": id,
                "url": url,
                "Status": "Pending"
            }
            search_data.insert_one(document)
            print("Category Inserted")
        else:
            search_data.update_one({"url": url},{"$set":{"Status": "Pending"}})
            print("Document already exists, skipping insert.")
