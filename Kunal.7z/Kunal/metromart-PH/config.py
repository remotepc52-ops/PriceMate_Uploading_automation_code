from Common_Modual.common_functionality import *
from pymongo import MongoClient
import os
from datetime import datetime


obj = RequestsManager()

# Parameters
website = "metromart"  # Replace with the actual website name or variable
region = "ph"
today = datetime.today().strftime("%Y_%m_%d")

conn = MongoClient("mongodb://localhost:27017/")
db = conn[f"pricemate_eshop_metromart_ph"]

# search_data = db[f'Search_Data_{today}']
search_data = db[f'Search_Data_{today}']
static_search = db[f'Static_Data_{today}']
product_data = db[f'Product_Data_{today}']

# Use url or another identifier instead of ProductCode
# search_data.create_index("url", unique=True)
static_search.create_index("shops_url", unique=True)
search_data.create_index("Sub_id", unique=True)
product_data.create_index("ProductCode", unique=True)




# Base path
base_path = f"E:\\Data\\Crawl_Data_Collection\\PriceMate\\{today}\\{website}"

# Define paths for different file types
html_path = os.path.join(base_path, "Data_Files", "HTML_Files")
excel_path = os.path.join(base_path, "Data_Files", "Excel_Files")

# Create directories
os.makedirs(html_path, exist_ok=True)
os.makedirs(excel_path, exist_ok=True)

print(f"HTML files path: {html_path}")
print(f"Excel files path: {excel_path}")


# current_proxy = '2c6ea6e6d8c14216a62781b8f850cd5b'

proxy = "http://21ed11ef5c872bc7727680a52233027db4578a0e:@api.zenrows.com:8001"
proxies = {"http": proxy, "https": proxy}
