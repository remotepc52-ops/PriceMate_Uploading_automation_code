from config import *
headers = {
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
    'authorization': 'Token eyJhbGciOiJIUzI1NiJ9.eyJpZCI6MTU0NTkxMDMsInR5cGUiOiJndWVzdCIsInNob3AtaWQiOjIxMjQsImlhdCI6MTc2NDY3NjY2MX0.y6-jsE-sq6ujd-TRDLigcUrn-MnFpGpG7u6SWRY9wNg',
    'cache-control': 'public, max-age=3600, s-maxage=86400, stale-while-revalidate=60',
    'origin': 'https://www.metromart.com',
    'priority': 'u=1, i',
    'referer': 'https://www.metromart.com/',
    'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
    'x-client-platform': 'Web',
    'x-powered-by': 'ARM JS Library/2.5.2',
}

page = 1

while True:
    params = {
        'filter[area.id]': '48',
        'filter[status]': 'open,closed',
        'page[number]': str(page),
        'page[size]': '18',
        'sort': '-priority',
        'fields[shops]': 'available-products-count,background-color,banner-background-color,banner-text-color,border-color,bulk-delivery-fee-in-cents,checkout-time-slot-announcement,checkout-time-slot-announcement-background-color,checkout-time-slot-announcement-border-color,checkout-time-slot-announcement-text-color,created-at,current-assigned-driver-count,current-assigned-driver-helper-count,current-assigned-runner-count,current-assigned-shopper-count,default-job-order-bulk-tip-amount-in-cents,default-job-order-large-tip-amount-in-cents,default-job-order-tip-amount-in-cents,delivery-fee-in-cents,disabled-payment-modes,express,express-delivery-time-in-minutes,external-code,featured,free-delivery-minimum-in-cents,friday-closing-time,friday-opening-time,grocery,inactive-background-color,inactive-border-color,inactive-logo-path,inactive-logo-url,location-name,locked-products-count,logo-path,logo-url,long-description,max-express-products-count,membership-enrolled,merchant-app-enabled,merchant-code,minimum-purchase-in-cents,mobile-banner-path,mobile-banner-url,monday-closing-time,monday-opening-time,name,new-arrival-products-count,next-delivery-from,next-delivery-phrase,next-opening-phrase,next-opening-time-from,next-opening-time-to,non-membership-fee-percentage,non-membership-number,on-sale,popular-products-count,pricing-policy,primary-contact-full-name,primary-contact-number,priority,products-on-markup-count,products-on-sale-count,products-with-buy-x-take-y-count,sari-sari-enabled,saturday-closing-time,saturday-opening-time,service-fee-threshold-in-cents,shop-price-guarantee,shopping-fee-in-cents,shopping-fee-kind,shopping-fee-tier-one-percentage,shopping-fee-tier-two-percentage,shopping-fee-tier-two-percentage-threshold-in-cents,short-description,slug,staging-area-enabled,staging-area-image-path,staging-area-image-url,status,sunday-closing-time,sunday-opening-time,text-color,thursday-closing-time,thursday-opening-time,next-opening-time-from,unlisted-deliverable-enabled,updated-at,web-banner-path,web-banner-url,web-logo-banner-path,web-logo-banner-url,wednesday-closing-time,wednesday-opening-time,active-fmcg-campaigns',
        'include': 'active-fmcg-campaigns,active-fmcg-campaigns.fmcg-campaign-vouchers',
    }
    base_url = "https://api.metromart.com/api/v2/shops"
    response = requests.get(base_url, params=params, headers=headers)
    print("Page:", page, "Status:", response.status_code)

    if response.status_code != 200:
        break

    store_data = response.json()

    # Extract shops
    data = store_data.get('data', [])
    for store in data:
        shop_id = store.get('id')
        main_store = store.get('attributes', {})
        slug = main_store.get('slug')
        print(slug)

        shop_url = f"https://www.metromart.com/shops/{slug}"
        main_listing = {
            "shops_id": shop_id,
            "shops_url": shop_url,
            "Status": "Pending"
        }
        # Insert into DB
        static_search.insert_one(main_listing)

    # Pagination logic
    meta = store_data.get('meta', {})
    page_info = meta.get('page', {})

    total_pages = page_info.get('total', 1)

    if page >= total_pages:
        print("Reached last page")
        break
    # Move to next page
    page += 1
