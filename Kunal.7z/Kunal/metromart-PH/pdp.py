from concurrent.futures import ThreadPoolExecutor
from config import *
def process_document(doc):
    shop_id = doc['shops_id']
    aisles = doc['Sub_id']
    category_name = doc['category_name']
    headers = {
        'accept': 'application/vnd.api+json',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
        'authorization': 'Token eyJhbGciOiJIUzI1NiJ9.eyJpZCI6MTU0NjE2ODAsInR5cGUiOiJndWVzdCIsInNob3AtaWQiOjIxMjQsImlhdCI6MTc2NDc1MjAzNH0.8loyW3uye8Z6IJPxUuEoJ0dq5wY7dTB31HP-XzPUtik',
        'origin': 'https://www.metromart.com',
        'priority': 'u=1, i',
        'referer': 'https://www.metromart.com/',
        'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
        'x-client-platform': 'Web',
    }
    page = 1
    while True:

        params = {
            'include': 'weights,take-y-weight,take-y-products,favorites,fmcg-campaign,fmcg-campaign.fmcg-campaign-vouchers,dhz-campaign-brand,department',
            'fields[products]': 'alcoholic,amount-in-cents,base-amount-in-cents,business-max-items-count,buy-x,buy-x-take-y,bulk,bulk-quantity-threshold,delicate,description,dhz-campaign-brand,dhz-campaign-brand-priority,image-url,image-740x740,max-items-count,name,percent-off,priority,require-legal-age,sari-sari-max-items-count,size,sold-as,status,take-y,weight-metric,weight-multiplier,weighted,weighted-disclaimer,fmcg-campaign,fmcg-campaign.fmcg-campaign-vouchers,department,aisle,shop,buy-x-weight,take-y-products,take-y-weight,weights',
            'fields[fmcg-campaigns]': 'kind,status,fmcg-campaign-vouchers',
            'fields[weights]': 'value,default',
            'filter[aisle.id]': f'{aisles}',
            'filter[sub-aisle.id]': '',
            'filter[brand.id]': '',
            'fields[fmcg-campaign-vouchers]': 'discount-in-cents,minimum-spend-in-cents',
            'filter[shop.id]': f'{shop_id}',
            'filter[status]': 'available',
            'page[number]': f'{page}',
            'page[size]': '30',
            'sort': 'fmcg-campaign.status=[active],fmcg-campaign.kind=[free-delivery,peso-discount,free-shopping-fee,display-only],-monthly-popular-score,-updated-at',
        }

        response = requests.get('https://api.metromart.com/api/v2/products', params=params, headers=headers)
        if response.status_code == 200:
            main_data = response.json()
            # print(main_data)
            data = main_data.get('data')
            for main in data:
                attributess = main.get('attributes')
                product_code = main.get('id')
                name = attributess.get('name')
                size = attributess.get('size')
                image_url = attributess.get('image-url')
                cents = attributess.get('amount-in-cents')
                # if cents is not None:
                #     price = f"{cents / 100:,.2f}"
                # if price.is_integer():
                #     price = int(price)
                #     print(price)

                if cents is not None:
                    price = cents / 100  # float

                    # remove .0 only if decimal part is zero
                    if price.is_integer():
                        price = int(price)

                status = attributess.get('status')
                if "available" in status:
                    main_status = True
                else:
                    main_status = False
                Items = {"Name": name, "Promo_Type": "", "Price": price, "per_unit_price": "",
                         "WasPrice": "",
                         "Offer_info": "", "Pack_size": size, "Barcode": "",
                         "Images": image_url,
                         "ProductURL": "", "is_available": main_status,
                         "Status": "Done", "ParentCode": "", "ProductCode": product_code,
                         "retailer_name": "metromart_ph",
                         "Category_Hierarchy": category_name, "Brand": "", "RRP": price}
                product_data.insert_one(Items)
                print("Data inserted", product_code)
            meta = main_data.get('meta', {})
            page_info = meta.get('page', {})

            total_pages = page_info.get('total', 1)

            if page >= total_pages:
                print("Reached last page")
                break
            # Move to next page
            page += 1





if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=50) as executor:
        docs = list(search_data.find({"Status": "Pending"}))
        executor.map(process_document, docs)