from concurrent.futures import ThreadPoolExecutor

from config import *
def cat_document(doc):
    shod_id = doc['shops_id']
    headers = {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
        'authorization': 'Token eyJhbGciOiJIUzI1NiJ9.eyJpZCI6MTU0NjE2ODAsInR5cGUiOiJndWVzdCIsInNob3AtaWQiOjIxMjQsImlhdCI6MTc2NDc1MjAzNH0.8loyW3uye8Z6IJPxUuEoJ0dq5wY7dTB31HP-XzPUtik',
        'origin': 'https://www.metromart.com',
        'priority': 'u=1, i',
        'referer': 'https://www.metromart.com/',
        'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
        'x-client-platform': 'Web',
        'x-powered-by': 'ARM JS Library/2.5.2',
    }

    response = requests.get(
        f'https://api.metromart.com/api/v2/departments?filter%5Bshop-id%5D={shod_id }&filter%5Bproduct.status%5D=available&fields%5Baisles%5D=name,priority,available-products-count,department&fields%5Bdepartments%5D=name,available-products-count,priority,special,special-text-color,special-background-color,special-on-hover-text-color,special-on-hover-background-color,name-background-color,logo-background-color,image-url,aisles&include=aisles&sort=special%3D%5Btrue%5D,-priority,name',
        headers=headers,
    )

    if response.status_code == 200:
        data = response.json()
        main = data.get('data')
        for looping in main:
            main_cat_id = looping.get('id')
            category_name = looping.get('attributes').get('name')
            print(main_cat_id)
            relational = looping.get('relationships').get('aisles').get('data')
            for subs in relational:
                sub_id = subs.get('id')
                category_url = f"https://www.metromart.com/shops/snr-new-manila/departments/{main_cat_id}/aisles/{sub_id}"
                main_list = {
                    "shops_id": shod_id,
                    "Main_cat_id": main_cat_id,
                    "Sub_id": sub_id,
                    "category_name": category_name,
                    "Category": category_url,
                    "Status":"Pending"
                }
                search_data.insert_one(main_list)

if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=20) as executor:
        docs = list(static_search.find({"Status": "Pending"}))
        executor.map(cat_document, docs)


