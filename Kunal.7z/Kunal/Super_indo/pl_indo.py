from config import *
import requests

url = "https://service.mysuperindo.co.id/store/v1/store-product"



headers = {
    "accept-encoding": "gzip",
    "activity_source": "app",
    "adid": "a8b1dad5319416d8968d5c09cfd80075",
    "asset_id": "8891d927b8228b8e4797705eeba7a540",
    "authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJBdXRoQ29uc3VtZXIiOiJzSS9UOE9adkV5MVJFNXBDTXJBYnBnSXQ4VjFrL1ErdVFlelpjMHM4YjNXUy9MOG1Hc0hWVFlVQjByTEJ0anRkelFiWGNqam9PNVR4QXV4eW5kR3U2bkYwcEwwUXpxUm1pUU1FR1dSTHJxUzYveW43UWpESGM5WnlZYWJUTzF0THFGZTk5emNZTjlMSHVqZFU3Z21uZDFzdGFOTjhGSGV2U1IxSUtmZ2p5UHlSUFdNbGtHZHNiNVFoWkxDWUFpOEtMZ3NZTWVlOU1hai9vVnZKSkpwK1gxRGYzOHlwS0RzbWJRUTM1RFVYOTNKdlBsYXlHOXFxajZzWGZMMEt0NVZramhpaGhUNHFmZ1ZPZm8zb0NhZXV5akM3NG9abkxyOFlYdXlTQ2xZa1AyUUZXL1Y4M0FFZnlmNlREdVptZ1Fqa3RPOGlTVThoL050djNMLyt6TU16NWdjREhPRXhJMTdORm95cTVjbFVaZGpXTnpCY3pHQnFxdE05dTREeU5xbDVIbk1aZEFPYythMmZEZVlDd3l6cmMxYmx3L1AvS0NzbFg5V2srUzdwTkNKSVlYTkhzN3YzbTUvWFhSWENDYW81ZDVuK1NRV0FUOS9uWW05WUNCY0lCd1V5MGRURXpLSnFJR1I4Unh0dXBVaUdqdklNOHJiMlI3Q0oyckgreVJOZjJiMk1MYStKeVBRYVA2aDQ5bVk0V1hJZTRZZEF0bldFSzRGSVBTRVdkV1hrM1FGV1podWZyc2pSWld6Y1RFakFOMXFIcTQ0MkdOVWxLTVYwY2FRNk82QW9NcWM5K3FnOXN5dmU2L0pMVjBzPSIsImV4cCI6MTc3ODU3ODI2OX0.eR4MPktQpqajMsrHEcak9z8cHv3xTkWQX8g2_o87fa8",
    "content-type": "application/json",
    "gps_adid": "79f286de-f66b-423e-9a41-4699ae70d65a",
    "host": "service.mysuperindo.co.id",
    "idfa": "",
    "idfv": "",
    "language": "en",
    "mobile_version_code": "12002000",
    "mobile_version_name": "20.02.000",
    "platform": "android",
    "user-agent": "Dart/3.7 (dart:io)"
}
page = 1
limit = 20
while True:
    params = {
        "store_id": "6527c14160f363746e2d5309",
        "name": "",
        "sort": "",
        "sort_by": "",
        "page": str(page),
        "limit": str(limit)
    }

    response = requests.get(url,proxies=proxies,verify='zyte-ca.crt', headers=headers, params=params)
    if response.status_code == 200:
        data = response.json()
        main = data.get('data', {}).get('data', [])
        was_price = ''
        promo_type = ''
        for get_json in main:
            promos = get_json.get('promos')

            if promos == "None" or promos is None:
                price = get_json.get('selling_price')
                rrp = price
            else:
                promo_type = None
                if isinstance(promos, list) and len(promos) > 0:
                    promo_type = promos[0].get('promo_type')
                    price = promos[0].get('discount_value', get_json.get('selling_price'))
                elif isinstance(promos, dict):
                    promo_type = promos.get('promo_type')
                    price = promos.get('discount_value', get_json.get('selling_price'))
                else:
                    price = get_json.get('selling_price')

                was_price = get_json.get('selling_price')

                # ✅ Handle when discount price is 0 — use was_price instead
                if not price or price == 0:
                    price = was_price

                # ✅ RRP logic: use was_price if valid, else use price
                rrp = was_price if was_price else price

            print(f"Price: {price}, RRP: {rrp}")


            main_stock = get_json.get('stock')
            if main_stock == 0:
                main_stock = False
            else:
                main_stock = True




            product_detail = get_json.get('product')
            product_id = product_detail.get('plu')
            name = product_detail.get('product_commercial_name')
            brand = product_detail.get('brand')
            if brand:
                brand = brand.title()
            size = product_detail.get('unit')
            category = product_detail.get('product_sub_categories').get('name')
            if category:
                category = f"Home > {category.title()}"
            print(product_id)
            base_url = "https://assets.mysuperindo.co.id/"
            images = product_detail.get("product_images", [])

            full_urls = [base_url + img for img in images]
            joined_urls = "|".join(full_urls)

            print(joined_urls)
            items = {
                "Name": name,
                "Promo_Type": promo_type.title(),
                "Price": price,
                "per_unit_price": '',
                "WasPrice": was_price,
                "Offer_info": '',
                "Pack_size": size,
                "Barcode": "",
                "is_available": main_stock,
                "Images": joined_urls,
                "ProductURL": "",
                "Status": "Done",
                "ParentCode": '',
                "ProductCode": product_id,
                "retailer_name": "Super_indo",
                "Category_Hierarchy": category,
                "Brand": brand,
                "RRP": rrp,
            }
            try:
                product_data.insert_one(items)
                print("Data Inserting for Pricemate")
            except Exception as e:
                print(e)
        page += 1
        time.sleep(0.5)

