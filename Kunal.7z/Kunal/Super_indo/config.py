import datetime
from Common_Modual.common_functionality import *
import pymongo
import os
import re
from  datetime import datetime

obj = RequestsManager()


website = "Super_indo"
today = datetime.today().strftime("%Y_%m_%d")

# conn = pymongo.MongoClient("mongodb://192.168.1.52:27017/")
conn = pymongo.MongoClient("mongodb://localhost:27017/")
db = conn[f"pricemate_eshop_superindo_id"]

# search_data = db[f'Search_Data_{today}']
product_data = db[f'Product_Data_{today}']

# search_data.create_index("url", unique=True)
product_data.create_index("ProductCode", unique=True)

base_path = f"E:\\Data\\Crawl_Data_Collection\\PriceMate\\{website}\\{today}"

# Define paths for different file types
html_path = os.path.join(base_path, "Data_Files", "HTML_Files")
excel_path = os.path.join(base_path, "Data_Files", "Excel_Files")

# Create directories
os.makedirs(html_path, exist_ok=True)
os.makedirs(excel_path, exist_ok=True)

print(f"HTML files path: {html_path}")
print(f"Excel files path: {excel_path}")


# current_proxy = '7d12e8dc87c84c9b9fccc23416cbdc40'
current_proxy = '2c6ea6e6d8c14216a62781b8f850cd5b'

proxy_host = "api.zyte.com"
proxy_port = "8011"
proxy_auth = f"{current_proxy}:"


proxies = {
    "http": "https://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port),
    "https": "http://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port)
}

# scraper_api_key = "f8f2ef6134be4c604d89eb084196f7bd"
