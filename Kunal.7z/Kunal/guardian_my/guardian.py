import json
from concurrent.futures import ThreadPoolExecutor

from config import *
def extract_size(size_string):
    try:
        # Updated regex pattern
        size_pattern = r'\b(?:Size|Pack Size):\s*(\d+(\.\d+)?)\s*(ml|mL|L|g|kg|oz|lb|packs?|tablets?|capsules?)?\b'

        # Search for size
        size_match = re.search(size_pattern, size_string, re.IGNORECASE)

        # Extract the size and unit
        if size_match:
            size_value = size_match.group(1)  # The number
            size_unit = size_match.group(3) if size_match.group(3) else ""  # The unit (if available)
            if not size_unit:
                return None

            print(f"Extracted Size: {size_value} {size_unit}".strip())
            Product_Size = f"{size_value} {size_unit}".strip()
        else:
            # print("No size found in first try...")

            # Regular expression pattern to match size and quantity like "90g×1本"
            size_quantity_pattern = r'(\d+(\.\d+)?(?:g|kg|ml|l|oz|lb))\s*×\s*(\d+個|袋|本)'
            size_quantity_match = re.search(size_quantity_pattern, size_string.lower())
            # Regex pattern to extract size details

            if size_quantity_match:
                # Extract size and quantity from the match
                size = size_quantity_match.group(1)
                quantity = size_quantity_match.group(3)
                # Combine size and quantity in the format "size (quantity)"
                Product_Size = f"{size}×{quantity}"

            else:
                # Regular expression pattern to match sizes only (e.g., 90g, 200ml)
                size_pattern = r'\b\d+(\.\d+)?\s*(ml|mL|l|g|kg|oz|lb|packs|pack|tablets|tablet|capsules)\b'
                size_match = re.search(size_pattern, size_string.lower())

                # Regular expression pattern to match quantities only (e.g., 24本入り)
                # quantity_pattern = r'\(\d+\s*本入り\)'
                quantity_pattern = r'\(\d+\s*本入り\)|(\d+\s*個)'
                quantity_match = re.search(quantity_pattern, size_string.lower())

                # Extract the size and quantity separately
                if size_match:
                    size = size_match.group()
                else:
                    size = ""

                if quantity_match:
                    quantity = quantity_match.group()
                else:
                    quantity = ""

                # Combine size and quantity if both are present
                if size and quantity:
                    Product_Size = f"{size} {quantity}"
                else:
                    Product_Size = size or quantity

                if not Product_Size:
                    # Regular expression pattern to match sizes only (e.g., 90g, 200ml)
                    size_pattern = r'\b(lozenges|packs|pack|tablets|tablet|capsules)?\s*\d+(\.\d+)\b'
                    size_match = re.search(size_pattern, size_string.lower())

                    # Regular expression pattern to match quantities only (e.g., 24本入り)
                    # quantity_pattern = r'\(\d+\s*本入り\)'
                    quantity_pattern = r'\(\d+\s*本入り\)|(\d+\s*個)'
                    quantity_match = re.search(quantity_pattern, size_string.lower())

                    # Extract the size and quantity separately
                    if size_match:
                        size = size_match.group()
                    else:
                        size = ""

                    if quantity_match:
                        quantity = quantity_match.group()
                    else:
                        quantity = ""

                    # Combine size and quantity if both are present
                    if size and quantity:
                        Product_Size = f"{size} {quantity}"
                    else:
                        Product_Size = size or quantity


    except Exception as e:
        Product_Size = ""

    return Product_Size
def process_document(doc):
    referer_url = doc['url']
    doc_id = doc['_id']
    cat_id = doc['cat_id']
    page = 1
    title = referer_url.rstrip('/').split('/')[-1].replace('-', ' ').title()

    main_json = []
    while True:



        headers = {
            'accept': '*/*',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
            'authorization': '',
            'content-type': 'application/json',
            'priority': 'u=1, i',
            'referer': f'{referer_url}.html?page={page}',
            'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'store': 'default',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
            'cookie': '_tt_enable_cookie=1; _ttp=01JX1X8FQE0AX91TX79S4VK07H_.tt.2; _fbp=fb.2.1749189673210.287713854908159558; _qg_fts=1749189673; QGUserId=4818225691862007; _gcl_au=1.1.1903929435.1749189674; _gid=GA1.3.1357406108.1749189674; _qg_cm=2; private_content_version=f0d609486ff95dceace5915ead29f3c2; store_default=a96cdf2eab189c5b75999709ffc33065; _qg_pushrequest=true; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A19743d43e812a2-016fc30f9db1a3-26011e51-144000-19743d43e822a2%22%2C%22%24device_id%22%3A%20%2219743d43e812a2-016fc30f9db1a3-26011e51-144000-19743d43e822a2%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; _ga=GA1.3.1233141374.1749189673; _gat_UA-43979305-1=1; _ga_0XRWJZS5N2=GS2.1.s1749209149$o3$g1$t1749210202$j60$l0$h0; _ga_RN47FENS9P=GS2.1.s1749209149$o3$g1$t1749210202$j59$l0$h0; ttcsid_CP7GPVJC77UBS72H1QT0=1749209150692::EjG8N571J00Rh4En7Tql.3.1749210245842; ttcsid=1749209150692::dgwnvUjHSHg6HXjpgb_g.3.1749210245842',
        }

        params = {
            'query': 'query GetCategories($id:Int!$pageSize:Int!$currentPage:Int!$filters:ProductAttributeFilterInput!$sort:ProductAttributeSortInput$cartId:String$source_code:String){category(id:$id cart_id:$cartId source_code:$source_code){id description name product_count meta_title meta_keywords meta_description __typename}products(pageSize:$pageSize currentPage:$currentPage filter:$filters sort:$sort cart_id:$cartId source_code:$source_code){items{id name sku brand price{regularPrice{amount{currency value __typename}__typename}__typename}price_range{minimum_price{final_price{currency value __typename}discount{amount_off percent_off __typename}__typename}maximum_price{final_price{currency value __typename}discount{amount_off percent_off __typename}__typename}__typename}member_price{currency value __typename}promotion_label promotion_label_name promotion_label_2 promotion_label_2_name promotion_label_3 promotion_label_3_name sales_icon sales_icon_2 sales_icon_3 small_image{url __typename}stock_status url_key url_suffix ...on ConfigurableProduct{configurable_options{id attribute_id attribute_id_v2 label position use_default attribute_code values{value_index label default_label store_label use_default_value swatch_data{...on ImageSwatchData{thumbnail __typename}value __typename}__typename}product_id swatch_additional_data{swatch_input_type use_product_image_for_swatch __typename}__typename}variants{product{id name sku stock_status sales_icon sales_icon_2 sales_icon_3 promotion_label promotion_label_name promotion_label_2 promotion_label_2_name promotion_label_3 promotion_label_3_name attribute_set_id ...on PhysicalProductInterface{weight __typename}price{regularPrice{amount{currency value __typename}__typename}__typename}price_range{minimum_price{final_price{currency value __typename}discount{amount_off percent_off __typename}__typename}maximum_price{final_price{currency value __typename}discount{amount_off percent_off __typename}__typename}__typename}member_price{currency value __typename}media_gallery_entries{id disabled file label position __typename}swatch_image{disabled label position url __typename}__typename}attributes{uid label code value_index __typename}__typename}__typename}__typename}page_info{total_pages __typename}total_count __typename}}',
            'operationName': 'GetCategories',
            'variables': json.dumps({
                "currentPage": page,
                "id": cat_id,
                "filters": {
                    "category_id": {
                        "in": [str(cat_id)]
                    }
                },
                "pageSize": 60,
                "sort": {
                    "position": "ASC"
                },
                "cartId": "LlCFOa1UjHon7ajHAZbEa0MN6Rsu1jyN",
                "source_code": "8799"
            })
        }
        unique_key = f"{cat_id}-{page}"
        hashid = generate_hashId(unique_key)
        html_filename = f"PL_{hashid}_page.json"
        html_filepath = os.path.join(html_path, html_filename)

        response = obj.to_requests(url='https://guardian.com.my/graphql', headers=headers, params=params,
                                   html_path=html_filepath,
                                   should_be=['regularPrice'], max_retry=3)
        if not response:
            print(f"getting wrong response:{referer_url}")
            return None
        elif 'Result Not Found' in response or 'This product is invalid.' in response or 'This page could not be found' in response:
            search_data.update_one(
                {'_id': id}, {'$set': {'Status': "Not found"}})
            print("Status Updated...")
        elif response:

            data = json.loads(response)
            print(data)
            category = data.get('data',{}).get('category',{}).get('name',{})
            items = data.get('data',{}).get('products',{}).get('items',[])
            for product in items:
                name = product.get('name')
                product_id = product.get('id')
                sku =  product.get('sku')
                brand = product.get('brand')
                if brand:
                    brand = brand.title()
                stock = product.get('stock_status')
                pro_url = product.get('url_key')
                # image = product.get('small_image').get('url')
                if stock == "IN_STOCK":
                    stock_status = True
                else:
                    stock_status = False
                main_was_price = product.get('price', {}).get('regularPrice', {}).get('amount', {}).get('value')
                was_price = float(main_was_price) if main_was_price is not None else None

                main_price = product.get('price_range', {}).get('minimum_price', {}).get('final_price', {}).get('value')
                orignal_price = float(main_price)

                discount = product.get('price_range', {}).get('maximum_price', {}).get('discount', {}).get(
                    'percent_off')
                main_discount = int(round(discount)) if discount  else None

                headers_main = {
                    'accept': '*/*',
                    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
                    'authorization': '',
                    'content-type': 'application/json',
                    'newrelic': 'eyJ2IjpbMCwxXSwiZCI6eyJ0eSI6IkJyb3dzZXIiLCJhYyI6IjMwNDI4MDAiLCJhcCI6Ijg0NTczNDA5OCIsImlkIjoiYjhkNDllZDc2N2Y0YzRlNiIsInRyIjoiM2I0YjdlZGM3N2U2ZjJiODkzM2Q0ZjBmZWFjNTFkNmQiLCJ0aSI6MTc0OTU1MjUyOTExMCwidGsiOiIxMzIyODQwIn19',
                    'priority': 'u=1, i',
                    'referer': f'{referer_url}.html?page={page}',
                    'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
                    'sec-ch-ua-mobile': '?0',
                    'sec-ch-ua-platform': '"Windows"',
                    'sec-fetch-dest': 'empty',
                    'sec-fetch-mode': 'cors',
                    'sec-fetch-site': 'same-origin',
                    'store': 'default',
                    'traceparent': '00-3b4b7edc77e6f2b8933d4f0feac51d6d-b8d49ed767f4c4e6-01',
                    'tracestate': '1322840@nr=0-1-3042800-845734098-b8d49ed767f4c4e6----1749552529110',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
                    'cookie': '_tt_enable_cookie=1; _ttp=01JX1X8FQE0AX91TX79S4VK07H_.tt.2; _fbp=fb.2.1749189673210.287713854908159558; _qg_fts=1749189673; QGUserId=4818225691862007; _gcl_au=1.1.1903929435.1749189674; private_content_version=f0d609486ff95dceace5915ead29f3c2; _qg_pushrequest=true; _gid=GA1.3.472456486.1750748631; _qg_cm=2; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A19743d43e812a2-016fc30f9db1a3-26011e51-144000-19743d43e822a2%22%2C%22%24device_id%22%3A%20%2219743d43e812a2-016fc30f9db1a3-26011e51-144000-19743d43e822a2%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; _ga=GA1.1.1233141374.1749189673; _ga_0XRWJZS5N2=GS2.1.s1750748629$o12$g1$t1750748740$j59$l0$h0; _ga_RN47FENS9P=GS2.1.s1750748629$o12$g1$t1750748740$j59$l0$h0; ttcsid_CP7GPVJC77UBS72H1QT0=1750748629494::lSJ1LEJRLkgii-EKTCjD.9.1750748762614; ttcsid=1750748629495::pX8rI57Bb9qraO9Nk3Bg.9.1750748762614',
                }
                params_main = {
                    'query': 'query getProductDetailForProductPage($urlKey:String!$source_code:String){products(filter:{url_key:{eq:$urlKey}}source_code:$source_code){items{id ...ProductDetailsFragment __typename}__typename}}fragment ProductDetailsFragment on ProductInterface{__typename categories{id breadcrumbs{category_id __typename}url_path url_suffix name __typename}description{html __typename}id media_gallery_entries{id label position disabled file __typename}meta_description name price{regularPrice{amount{currency value __typename}__typename}__typename}brand brands sales_icon sales_icon_2 sales_icon_3 hide_description hide_short_description quick_overview direction_for_use ingredients contra_indication caution promotion_label promotion_label_name promotion_label_2 promotion_label_2_name promotion_label_3 promotion_label_3_name price_range{minimum_price{final_price{currency value __typename}discount{amount_off percent_off __typename}__typename}maximum_price{final_price{currency value __typename}discount{amount_off percent_off __typename}__typename}__typename}member_price{currency value __typename}short_description{html __typename}sku small_image{url __typename}stock_status url_key ...on ConfigurableProduct{configurable_options{attribute_code attribute_id id label values{default_label label store_label use_default_value value_index swatch_data{...on ImageSwatchData{thumbnail __typename}value __typename}__typename}swatch_additional_data{swatch_input_type use_product_image_for_swatch __typename}__typename}variants{attributes{code value_index __typename}product{id name media_gallery_entries{id disabled file label position __typename}sku stock_status sales_icon sales_icon_2 sales_icon_3 promotion_label promotion_label_name promotion_label_2 promotion_label_2_name promotion_label_3 promotion_label_3_name price{regularPrice{amount{currency value __typename}__typename}__typename}price_range{minimum_price{final_price{currency value __typename}discount{amount_off percent_off __typename}__typename}maximum_price{final_price{currency value __typename}discount{amount_off percent_off __typename}__typename}__typename}member_price{currency value __typename}swatch_image{disabled label position url __typename}modiface_upc __typename}__typename}__typename}modiface_functionality}',
                    'operationName': 'getProductDetailForProductPage',
                    'variables': json.dumps({"urlKey": pro_url, "source_code": "8799"})
                }
                unique_key = f"{sku}-{page}"
                hashid = generate_hashId(unique_key)
                html_filename = f"PL_{hashid}_page.json"
                html_filepath = os.path.join(html_path, html_filename)

                response_main = obj.to_requests('https://guardian.com.my/graphql', params=params_main,
                                        headers=headers_main,html_path=html_filepath,proxies=proxies,verify=False,
                                   should_be=['media_gallery_entries'], max_retry=3)

                if not response_main:
                    print(f"getting wrong response:{referer_url}")
                    return None
                elif 'Result Not Found' in response_main or 'This product is invalid.' in response_main or 'This page could not be found' in response_main:
                    search_data.update_one(
                        {'_id': id}, {'$set': {'Status': "Not found"}})
                    print("Status Updated...")
                elif response_main:

                    image_data = json.loads(response_main)
                    items = image_data.get("data", {}).get("products", {}).get("items", [])
                    try:
                        category_name_br = (items[0].get("categories", [{}])[0].get("name", "")) if items else ""
                    except Exception as e:
                        print(e)

                    if items:
                        image_main = items[0].get('media_gallery_entries', [])
                        image_urls = []

                        for imaging in image_main:
                            file = imaging.get('file')
                            if file:
                                image_url = f"https://guardian.com.my/media/catalog/product{file}?optimize=medium&bg-color=255,255,255&fit=bounds&height=&width="
                                image_urls.append(image_url)

                        joined_image_urls = '|'.join(image_urls)
                        print("Joined Image URLs:", joined_image_urls)
                    else:
                        print("No items found in response.")
                product_url = f"https://guardian.com.my/{pro_url}.html"
                if not was_price or orignal_price == was_price:
                    rrp_price = orignal_price
                    was_price = ''
                else:
                    rrp_price = was_price
                breadcrumb = category
                if main_discount:
                    offer_info = f"{main_discount}% off"
                else:
                    offer_info = ""
                size_text = extract_size(name)
                Items = {"Name": name, "Promo_Type": "", "Price": orignal_price, "per_unit_price": "",
                         "WasPrice": was_price,
                         "Offer_info": offer_info, "Pack_size": size_text, "Barcode": "",
                         "Images": joined_image_urls,
                         "ProductURL": product_url, "is_available": stock_status,
                         "Status": "Done", "ParentCode": "", "ProductCode": sku,
                         "retailer_name": "Guardian",
                         "Category_Hierarchy": category_name_br, "Brand": brand, "RRP": rrp_price}
                try:
                    product_data.insert_one(Items)
                    search_data.update_one({'_id': doc_id}, {'$set': {'Status': "Not found"}})
                except Exception as e:
                    print(e)

        page += 1
if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=50) as executor:
        docs = list(search_data.find({"Status": "Pending"}))
        executor.map(process_document, docs)

        # data.products.items[4].small_image.url
        # data.products.items[4].url_key