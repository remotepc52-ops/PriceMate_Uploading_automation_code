from config import *
cookies = {
    '_tt_enable_cookie': '1',
    '_ttp': '01JX1X8FQE0AX91TX79S4VK07H_.tt.2',
    '_fbp': 'fb.2.1749189673210.287713854908159558',
    '_qg_fts': '1749189673',
    'QGUserId': '4818225691862007',
    '_gcl_au': '1.1.1903929435.1749189674',
    '_gid': 'GA1.3.1357406108.1749189674',
    '_qg_cm': '2',
    'private_content_version': 'f0d609486ff95dceace5915ead29f3c2',
    'store_default': 'a96cdf2eab189c5b75999709ffc33065',
    '_qg_pushrequest': 'true',
    '_ga_0XRWJZS5N2': 'GS2.1.s1749209149$o3$g1$t1749209987$j54$l0$h0',
    '_ga': 'GA1.3.1233141374.1749189673',
    '_gat_UA-43979305-1': '1',
    '_ga_RN47FENS9P': 'GS2.1.s1749209149$o3$g1$t1749209987$j54$l0$h0',
    'ttcsid_CP7GPVJC77UBS72H1QT0': '1749209150692::EjG8N571J00Rh4En7Tql.3.1749209998900',
    'ttcsid': '1749209150692::dgwnvUjHSHg6HXjpgb_g.3.1749209998901',
    'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A19743d43e812a2-016fc30f9db1a3-26011e51-144000-19743d43e822a2%22%2C%22%24device_id%22%3A%20%2219743d43e812a2-016fc30f9db1a3-26011e51-144000-19743d43e822a2%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
}

headers = {
    'accept': '*/*',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
    'authorization': '',
    'content-type': 'application/json',
    'priority': 'u=1, i',
    'referer': 'https://guardian.com.my/skincare',
    'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'store': 'default',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    # 'cookie': '_tt_enable_cookie=1; _ttp=01JX1X8FQE0AX91TX79S4VK07H_.tt.2; _fbp=fb.2.1749189673210.287713854908159558; _qg_fts=1749189673; QGUserId=4818225691862007; _gcl_au=1.1.1903929435.1749189674; _gid=GA1.3.1357406108.1749189674; _qg_cm=2; private_content_version=f0d609486ff95dceace5915ead29f3c2; store_default=a96cdf2eab189c5b75999709ffc33065; _qg_pushrequest=true; _ga_0XRWJZS5N2=GS2.1.s1749209149$o3$g1$t1749209987$j54$l0$h0; _ga=GA1.3.1233141374.1749189673; _gat_UA-43979305-1=1; _ga_RN47FENS9P=GS2.1.s1749209149$o3$g1$t1749209987$j54$l0$h0; ttcsid_CP7GPVJC77UBS72H1QT0=1749209150692::EjG8N571J00Rh4En7Tql.3.1749209998900; ttcsid=1749209150692::dgwnvUjHSHg6HXjpgb_g.3.1749209998901; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A19743d43e812a2-016fc30f9db1a3-26011e51-144000-19743d43e822a2%22%2C%22%24device_id%22%3A%20%2219743d43e812a2-016fc30f9db1a3-26011e51-144000-19743d43e822a2%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
}

params = {
    'query': 'query GetNavigationMenu($id:Int!$source_code:String){category(id:$id source_code:$source_code){id name children{children_count id include_in_menu name position url_path url_suffix dropdown_image_link image promo_logo description popular_brand popular_brands_childs{id name url_path url_suffix __typename}children{children_count id include_in_menu name position url_path url_suffix image promo_logo popular_brand popular_brands_childs{id name url_path url_suffix __typename}children{children_count id include_in_menu name position url_path url_suffix image promo_logo __typename}__typename}__typename}include_in_menu url_path url_suffix __typename}}',
    'operationName': 'GetNavigationMenu',
    'variables': '{"id":2}',
}

response = requests.get('https://guardian.com.my/graphql', params=params, cookies=cookies, headers=headers)
if response.status_code== 200:
    data = response.json()
    children = data.get('data',{}).get('category',{}).get('children',{})
    for child in children:
        url_key = child.get('url_path')
        id = child.get('id')

        document = {
            "cat_id": id,
            "url": f"https://guardian.com.my/{url_key}",
            "Status": "Pending"
        }
        existing = search_data.find_one({"url": f"https://guardian.com.my/{url_key}"})
        if not existing:
            search_data.insert_one(document)
            print("Category Inserted")

        else:
            print("Document already exists, skipping insert.")


