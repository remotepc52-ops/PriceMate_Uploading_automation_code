from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse

import config
import json
from config import *





def process_document(doc):
    referer_url = doc['url']
    doc_id = doc['_id']
    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-US,en;q=0.9,hi;q=0.8',
        'cache-control': 'max-age=0',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
        'sec-ch-ua-arch': '"x86"',
        'sec-ch-ua-bitness': '"64"',
        'sec-ch-ua-full-version': '"137.0.7151.69"',
        'sec-ch-ua-full-version-list': '"Google Chrome";v="137.0.7151.69", "Chromium";v="137.0.7151.69", "Not/A)Brand";v="24.0.0.0"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-model': '""',
        'sec-ch-ua-platform': '"Windows"',
        'sec-ch-ua-platform-version': '"15.0.0"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
        'cookie': 'fornax_anonymousId=8b9bffb3-8ead-4afe-b9f3-17a039a80109; _gcl_au=1.1.2069150272.1746074497; _shg_user_id=5ee5947d-2215-44e6-a6be-7b4d794815c5; _fbp=fb.2.1746074497307.30734925764514257; _ga=GA1.1.947569310.1746074498; hubspotutk=365c33d5a4abf09717bbf69c1312e6aa; __cf_bm=c5lgF__b6aK8bFrxgvWCCeNbPDr9yXEaNdHpN4eng5E-1749564164-1.0.1.1-eynBMx1VJVsCmB4qEz6GX4OKj_4E_HcBM0Hl.U5kJBHbTJGbNzgFqyE92fMZA6XXTHt.1GWyWpgAKBsCfI0TlORnaI0av6OtMOfRYIuMZYc; cf_clearance=s0kvNLDH94knTmSb469pw.rIZCbSHfW.T1SSoK4w.dc-1749564170-1.2.1.1-_kmEbwe_u7Dt5SxHVgU.2nwmvZ7CzmEhGZiwpBQio.4pzXef3XqtuuT0eA3SwP892aRRN2u7LZ35qwOn_G511FQo2pX7N3EYC68ktlwwK0aUZF.QnU1n3DnA5t5moZ8q1THzpiHDiWvgg1MC9wcwpDU15wUsdhOMZj7NMX7EASfhE_3qB4zcaTze17ff4udycq2shPboUelgUYNS9eVBR40p66T1R.GPqdp2J9_.g5dVocmUIzoJeQpt652JM0yACTzXbnVVHz3ZOUq061..DctoUVKFFqg2zWs3GFHTdqa9isNmssgNaIhiabLNwT.iVBS822ITgDIaxGsUBT5jiYA0CDcSSKsfurjUzHWkTqCUOZyj_UNmpTvQeLaLwbVd; SF-CSRF-TOKEN=7420c54c-e934-4bed-93d3-5fb3c9a41a2f; athena_short_visit_id=581711f0-29c1-4ea0-ab63-5b34fd07d875:1749564170; XSRF-TOKEN=f75ef73e1cb3e227dd23b7b7e6a3a49220e90f1ed7f7583ffeb76c50e96a5200; SHOP_SESSION_TOKEN=268f8f15-5ec5-4683-af8d-353552615db6; _shg_session_id=deaa3662-36be-424d-9dd6-189b988272fa; STORE_VISITOR=1; __hstc=59852978.365c33d5a4abf09717bbf69c1312e6aa.1746074499571.1746074499571.1749564175737.2; __hssrc=1; lastVisitedCategory=1355; _uetsid=9afbbc60460311f0a1e41faa993e3a7e; _uetvid=9151f250264611f0bde061e59f411af5; Shopper-Pref=CD2E7B62DE2055B683AAB3431D95B3C4F0B94610-1750169461180-x%7B%22cur%22%3A%22AUD%22%7D; __hssc=59852978.7.1749564175737; _ga_3MQNH2RT82=GS2.1.s1749564174$o3$g1$t1749564662$j58$l0$h543628439',
    }
    parsed_url = urlparse(referer_url)

    product_slug = parsed_url.path.strip('/').split('/')[-1]

    print(product_slug)
    html_filename = f"{product_slug}_page.html"
    html_filepath = os.path.join(html_path, html_filename)
    response = obj.to_requests(url=referer_url, headers=headers, html_path=html_filepath,
                                    should_be=['productView-title'], max_retry=3)  # proxies=proxies, verify=False,
    # print(response_html.status_code)
    if not response:
        print(f"getting wrong response:{referer_url}")
        return None
    elif 'Result Not Found' in response or 'This product is invalid.' in response or 'This page could not be found' in response:
        search_data.update_one(
            {'_id': id}, {'$set': {'Status': "Not found"}})
        print("Status Updated...")
    elif response:

        selector = Selector(text=response)
        main_path = selector.xpath('//div[@class="productView"]')

        name = main_path.xpath('.//h1[@class="productView-title"]/text()').get()
        # was_price_text = main_path.xpath('.//span[@class="price price--non-sale"]/text()').get()
        # sku = main_path.xpath('.//dd[@data-product-sku]/text()').get()
        match = re.search(r'var\s+BCData\s*=\s*(\{.*?\});', response, re.DOTALL)
        instock = ""
        if match:
            try:
                bcdata_raw = match.group(1)
                bcdata_json = json.loads(bcdata_raw)
                instock = bcdata_json.get('product_attributes', {}).get('instock')
            except Exception as e:
                print(f"Failed to parse BCData JSON: {e}")
        product_id = main_path.xpath('.//input[@name="product_id"]/@value').get()
        image = '|'.join(main_path.xpath('.//a[@data-lightbox="loadimage-pc"]/@href').getall())
        bread = main_path.xpath('//dt[contains(text(),"Category:")]/following-sibling::dd/text()').get()
        if not product_id:
            print(f"No product ID found for {referer_url}")
            return

        params = {
            'productIds': f'{product_id}:',
        }

        try:
            inventory_response = requests.get(
                'https://cc.peto.com.au/api/Inventory/getProducts',
                params=params,
                headers=headers,
                timeout=10
            )
            inventory_response.raise_for_status()
            inventory_data = inventory_response.json()
        except Exception as e:
            print(f"Inventory API failed for {product_id}: {e}")
            return

        variants = inventory_data.get("data", [{}])[0].get("variants", [])
        main_json = []

        for variant in variants:
            weight = variant.get('option_values',[{}])[0].get('label')
            price = variant.get("calculated_price")
            was_price = variant.get("price")
            barcode = variant.get("upc")
            if barcode and barcode.isdigit():
                barcode = barcode
            else:
                barcode = ""
            sku_main = variant.get("sku")

            try:
                price_float = float(price)
                was_price_float = float(was_price)
            except (TypeError, ValueError):
                price_float = was_price_float = ''

            if price_float == was_price_float:
                was_price_display = ''
                rrp = price
            else:
                was_price_display = was_price
                rrp = was_price or price

            items = {
                "Name": name,
                "Promo_Type": '',
                "Price": price,
                "per_unit_price": '',
                "WasPrice": was_price_display,
                "Offer_info": '',
                "Pack_size": weight,
                "Barcode": barcode,
                "is_available": instock,
                "Images": image,
                "ProductUrl": referer_url,
                "Status": "Done",
                "ParentCode": '',
                "ProductCode": sku_main,
                "retailer_name": "peto",
                "Category_Hierarchy": bread,
                "Brand": '',
                "RRP": rrp,
            }

            main_json.append(items)

        if main_json:
            product_data.insert_many(main_json)
            category_data.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
            print(f"Processed and updated: {referer_url}")
        else:
            print(f"No variant data found for: {referer_url}")




with ThreadPoolExecutor(max_workers=30) as executor:
    docs = list(category_data.find({"Status": "Pending"}))
    executor.map(process_document, docs)



