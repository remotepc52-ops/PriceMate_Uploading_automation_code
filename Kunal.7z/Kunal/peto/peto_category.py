
from config import *
import time

cookies = {
    'fornax_anonymousId': '8b9bffb3-8ead-4afe-b9f3-17a039a80109',
    '_gcl_au': '1.1.2069150272.1746074497',
    '_shg_user_id': '5ee5947d-2215-44e6-a6be-7b4d794815c5',
    '_fbp': 'fb.2.1746074497307.30734925764514257',
    '_ga': 'GA1.1.947569310.1746074498',
    'hubspotutk': '365c33d5a4abf09717bbf69c1312e6aa',
    '__cf_bm': 'c5lgF__b6aK8bFrxgvWCCeNbPDr9yXEaNdHpN4eng5E-1749564164-1.0.1.1-eynBMx1VJVsCmB4qEz6GX4OKj_4E_HcBM0Hl.U5kJBHbTJGbNzgFqyE92fMZA6XXTHt.1GWyWpgAKBsCfI0TlORnaI0av6OtMOfRYIuMZYc',
    'cf_clearance': 's0kvNLDH94knTmSb469pw.rIZCbSHfW.T1SSoK4w.dc-1749564170-1.2.1.1-_kmEbwe_u7Dt5SxHVgU.2nwmvZ7CzmEhGZiwpBQio.4pzXef3XqtuuT0eA3SwP892aRRN2u7LZ35qwOn_G511FQo2pX7N3EYC68ktlwwK0aUZF.QnU1n3DnA5t5moZ8q1THzpiHDiWvgg1MC9wcwpDU15wUsdhOMZj7NMX7EASfhE_3qB4zcaTze17ff4udycq2shPboUelgUYNS9eVBR40p66T1R.GPqdp2J9_.g5dVocmUIzoJeQpt652JM0yACTzXbnVVHz3ZOUq061..DctoUVKFFqg2zWs3GFHTdqa9isNmssgNaIhiabLNwT.iVBS822ITgDIaxGsUBT5jiYA0CDcSSKsfurjUzHWkTqCUOZyj_UNmpTvQeLaLwbVd',
    'SF-CSRF-TOKEN': '7420c54c-e934-4bed-93d3-5fb3c9a41a2f',
    'athena_short_visit_id': '581711f0-29c1-4ea0-ab63-5b34fd07d875:1749564170',
    'XSRF-TOKEN': 'f75ef73e1cb3e227dd23b7b7e6a3a49220e90f1ed7f7583ffeb76c50e96a5200',
    'SHOP_SESSION_TOKEN': '268f8f15-5ec5-4683-af8d-353552615db6',
    '_shg_session_id': 'deaa3662-36be-424d-9dd6-189b988272fa',
    'STORE_VISITOR': '1',
    '__hstc': '59852978.365c33d5a4abf09717bbf69c1312e6aa.1746074499571.1746074499571.1749564175737.2',
    '__hssrc': '1',
    'lastVisitedCategory': '1355',
    '_uetsid': '9afbbc60460311f0a1e41faa993e3a7e',
    '_uetvid': '9151f250264611f0bde061e59f411af5',
    '__hssc': '59852978.5.1749564175737',
    'Shopper-Pref': 'CA82044A00CA31B888B6B48F0EA322A41A79BB3D-1750169160225-x%7B%22cur%22%3A%22AUD%22%7D',
    '_ga_3MQNH2RT82': 'GS2.1.s1749564174$o3$g1$t1749564365$j53$l0$h543628439',
}

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9,hi;q=0.8',
    'cache-control': 'max-age=0',
    'priority': 'u=0, i',
    'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-arch': '"x86"',
    'sec-ch-ua-bitness': '"64"',
    'sec-ch-ua-full-version': '"137.0.7151.69"',
    'sec-ch-ua-full-version-list': '"Google Chrome";v="137.0.7151.69", "Chromium";v="137.0.7151.69", "Not/A)Brand";v="24.0.0.0"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-model': '""',
    'sec-ch-ua-platform': '"Windows"',
    'sec-ch-ua-platform-version': '"15.0.0"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    # 'cookie': 'fornax_anonymousId=8b9bffb3-8ead-4afe-b9f3-17a039a80109; _gcl_au=1.1.2069150272.1746074497; _shg_user_id=5ee5947d-2215-44e6-a6be-7b4d794815c5; _fbp=fb.2.1746074497307.30734925764514257; _ga=GA1.1.947569310.1746074498; hubspotutk=365c33d5a4abf09717bbf69c1312e6aa; __cf_bm=c5lgF__b6aK8bFrxgvWCCeNbPDr9yXEaNdHpN4eng5E-1749564164-1.0.1.1-eynBMx1VJVsCmB4qEz6GX4OKj_4E_HcBM0Hl.U5kJBHbTJGbNzgFqyE92fMZA6XXTHt.1GWyWpgAKBsCfI0TlORnaI0av6OtMOfRYIuMZYc; cf_clearance=s0kvNLDH94knTmSb469pw.rIZCbSHfW.T1SSoK4w.dc-1749564170-1.2.1.1-_kmEbwe_u7Dt5SxHVgU.2nwmvZ7CzmEhGZiwpBQio.4pzXef3XqtuuT0eA3SwP892aRRN2u7LZ35qwOn_G511FQo2pX7N3EYC68ktlwwK0aUZF.QnU1n3DnA5t5moZ8q1THzpiHDiWvgg1MC9wcwpDU15wUsdhOMZj7NMX7EASfhE_3qB4zcaTze17ff4udycq2shPboUelgUYNS9eVBR40p66T1R.GPqdp2J9_.g5dVocmUIzoJeQpt652JM0yACTzXbnVVHz3ZOUq061..DctoUVKFFqg2zWs3GFHTdqa9isNmssgNaIhiabLNwT.iVBS822ITgDIaxGsUBT5jiYA0CDcSSKsfurjUzHWkTqCUOZyj_UNmpTvQeLaLwbVd; SF-CSRF-TOKEN=7420c54c-e934-4bed-93d3-5fb3c9a41a2f; athena_short_visit_id=581711f0-29c1-4ea0-ab63-5b34fd07d875:1749564170; XSRF-TOKEN=f75ef73e1cb3e227dd23b7b7e6a3a49220e90f1ed7f7583ffeb76c50e96a5200; SHOP_SESSION_TOKEN=268f8f15-5ec5-4683-af8d-353552615db6; _shg_session_id=deaa3662-36be-424d-9dd6-189b988272fa; STORE_VISITOR=1; __hstc=59852978.365c33d5a4abf09717bbf69c1312e6aa.1746074499571.1746074499571.1749564175737.2; __hssrc=1; lastVisitedCategory=1355; _uetsid=9afbbc60460311f0a1e41faa993e3a7e; _uetvid=9151f250264611f0bde061e59f411af5; __hssc=59852978.5.1749564175737; Shopper-Pref=CA82044A00CA31B888B6B48F0EA322A41A79BB3D-1750169160225-x%7B%22cur%22%3A%22AUD%22%7D; _ga_3MQNH2RT82=GS2.1.s1749564174$o3$g1$t1749564365$j53$l0$h543628439',
}

base_url = "https://peto.com.au"
path = os.path.join(html_path, f"PL_{generate_hashId(base_url)}.html")

response = requests.get(f'{base_url}/dog/dog-food/', cookies=cookies, headers=headers)

if response.status_code == 200:
    selector = Selector(response.text)

    menu_items = selector.xpath('//ul[@class="navPage-childList"]')

    all_urls = []
    for menu in menu_items:
        urls = menu.xpath('.//a[@class="navPage-childList-action navPages-action"]/@href').getall()
        all_urls.extend(urls)

    all_urls = list(set([base_url + url if url.startswith('/') else url for url in all_urls]))

    for url in all_urls:
        search_data.update_one({"url": url}, {"$setOnInsert": {"url": url}}, upsert=True)

    print(f"Stored {len(all_urls)} category URLs.")

    for category_url in all_urls:
        print(f"\nProcessing category: {category_url}")
        page = 1
        while True:
            paginated_url = f"{category_url}?page={page}"

            hashid = generate_hashId(paginated_url)
            path = os.path.join(html_path, f"PL_{hashid}.html")

            res = requests.get(paginated_url, headers=headers, cookies=cookies)
            if res.status_code != 200:
                print(f"Failed to load: {paginated_url}")
                break

            sel = Selector(res.text)

            pdp_urls = sel.xpath('//article[@class="card "]/figure/a/@href').getall()
            pdp_urls = [base_url + url if url.startswith('/') else url for url in pdp_urls]

            if not pdp_urls:
                print(f"No more products on page {page}")
                break

            for pdp_url in pdp_urls:
                category_data.update_one({"url": pdp_url}, {"$set": {"url": pdp_url, "Status": "Pending"}}, upsert=True)

            print(f"Page {page}: Collected {len(pdp_urls)} product URLs.")

            next_page = sel.xpath(f'//a[@class="pagination-link" and text()="{page + 1}"]/@href').get()
            if not next_page:
                break

            page += 1
            time.sleep(1)

else:
    print(f"Failed to load base category page. Status: {response.status_code}")

