from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse

import config
import json
import peto_category
from config import *





def process_document(doc):
    referer_url = doc['url']
    doc_id = doc['_id']
    headers = {
        'Accept': '*/*',
        'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'DNT': '1',
        'Origin': 'https://peto.com.au',
        'Pragma': 'no-cache',
        'Referer': 'https://peto.com.au/',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-site',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
        'sec-ch-ua': '"Chromium";v="136", "Google Chrome";v="136", "Not.A/Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
    }
    parsed_url = urlparse(referer_url)

    # Get the last part of the path (slug)
    product_slug = parsed_url.path.strip('/').split('/')[-1]

    print(product_slug)
    html_filename = f"{product_slug}_page.html"
    html_filepath = os.path.join(html_path, html_filename)
    response = obj.to_requests(url=referer_url, headers=headers, html_path=html_filepath,
                                    should_be=['productView-title'], max_retry=3)  # proxies=proxies, verify=False,
    # print(response_html.status_code)
    if not response:
        print(f"getting wrong response:{referer_url}")
        return None
    elif 'Result Not Found' in response or 'This product is invalid.' in response or 'This page could not be found' in response:
        search_data.update_one(
            {'_id': id}, {'$set': {'Status': "Not found"}})
        print("Status Updated...")
    elif response:

        selector = Selector(text=response)
        main_path = selector.xpath('//div[@class="productView"]')

        name = main_path.xpath('.//h1[@class="productView-title"]/text()').get()
        # was_price_text = main_path.xpath('.//span[@class="price price--non-sale"]/text()').get()
        # sku = main_path.xpath('.//dd[@data-product-sku]/text()').get()
        match = re.search(r'var\s+BCData\s*=\s*(\{.*?\});', response, re.DOTALL)
        instock = ""
        if match:
            try:
                bcdata_raw = match.group(1)
                bcdata_json = json.loads(bcdata_raw)
                instock = bcdata_json.get('product_attributes', {}).get('instock')
            except Exception as e:
                print(f"Failed to parse BCData JSON: {e}")
        product_id = main_path.xpath('.//input[@name="product_id"]/@value').get()
        if product_id:
            html_filename = f"{product_id}_page.html"
        else:
            html_filename = "unknown_page.html"




        image = '|'.join(main_path.xpath('.//a[@data-lightbox="loadimage-pc"]/@href').getall())
        bread = main_path.xpath('//dt[contains(text(),"Category:")]/following-sibling::dd/text()').get()
        if not product_id:
            print(f"No product ID found for {referer_url}")
            return

        params = {
            'productIds': f'{product_id}:',
        }

        try:
            inventory_response = requests.get(
                'https://cc.peto.com.au/api/Inventory/getProducts',
                params=params,
                headers=headers,
                timeout=10
            )
            inventory_response.raise_for_status()
            inventory_data = inventory_response.json()
        except Exception as e:
            print(f"Inventory API failed for {product_id}: {e}")
            return

        variants = inventory_data.get("data", [{}])[0].get("variants", [])
        main_json = []

        for variant in variants:
            weight = variant.get('option_values',[{}])[0].get('label')
            price = variant.get("calculated_price")
            was_price = variant.get("price")
            barcode = variant.get("upc")
            sku_main = variant.get("sku")

            try:
                price_float = float(price)
                was_price_float = float(was_price)
            except (TypeError, ValueError):
                price_float = was_price_float = ''

            if price_float == was_price_float:
                was_price_display = ''
                rrp = price
            else:
                was_price_display = was_price
                rrp = was_price or price

            items = {
                "Name": name,
                "Promo_Type": '',
                "Price": price,
                "per_unit_price": '',
                "WasPrice": was_price_display,
                "Offer_info": '',
                "Pack_size": weight,
                "Barcode": barcode,
                "is_available": instock,
                "Images": image,
                "ProductUrl": referer_url,
                "Status": "Done",
                "ParentCode": '',
                "ProductCode": sku_main,
                "retailer_name": "peto",
                "Category_Hierarchy": bread,
                "Brand": '',
                "RRP": rrp,
            }

            main_json.append(items)

        if main_json:
            product_data.insert_many(main_json)
            category_data.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
            print(f"Processed and updated: {referer_url}")
        else:
            print(f"No variant data found for: {referer_url}")



# peto_category.fetch_sitemap_and_save()

with ThreadPoolExecutor(max_workers=1) as executor:
    docs = list(category_data.find({"Status": "Pending"}))
    executor.map(process_document, docs)



