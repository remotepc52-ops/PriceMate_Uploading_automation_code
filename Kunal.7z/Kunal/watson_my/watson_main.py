import json
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse

from config import *
def extract_size(size_string):
    try:
        size_string = size_string.strip()

        pattern1 = r'(?:Size|Pack Size)[:\s]*([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb|packs?|pack|tablets?|capsules?)'
        match = re.search(pattern1, size_string, re.IGNORECASE)
        if match:
            size_value = match.group(1)
            size_unit = match.group(2)
            return f"{size_value} {size_unit}"

        # 2️⃣ Look for things like "200ml", "2kg", "90g", etc.
        pattern2 = r'([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb|packs?|pack|tablets?|capsules?)'
        match = re.search(pattern2, size_string, re.IGNORECASE)
        if match:
            size_value = match.group(1)
            size_unit = match.group(2)
            return f"{size_value} {size_unit}"

        # 3️⃣ Look for patterns like "90g×2" or "200ml x 3"
        pattern3 = r'([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb)\s*[×xX]\s*(\d+)'
        match = re.search(pattern3, size_string, re.IGNORECASE)
        if match:
            size = f"{match.group(1)} {match.group(2)}"
            quantity = match.group(3)
            return f"{size} x {quantity}"

        # 4️⃣ Look for just quantity (like "24本入り" or "2個")
        pattern4 = r'(\d+)\s*(個|本入り|袋|本)'
        match = re.search(pattern4, size_string, re.IGNORECASE)
        if match:
            quantity = f"{match.group(1)} {match.group(2)}"
            return quantity

        # If nothing matched
        return ""

    except Exception as e:
        print(f"Error extracting size: {e}")
        return ""
def process_document(doc):
    referer_url = doc['url']
    doc_id = doc['_id']
    cookies = {
        'ROUTE': '.jsapps-65f749749d-bdnl5',
        'PIM-SESSION-ID': 'XxKhPqbRE6YIflgw',
        'e2-language': 'en',
        'language': 'en',
        'langcode': 'en',
        'ak_bmsc': 'B31F2F28FFC670584ACF70FBB34F6E7E~000000000000000000000000000000~YAAQj/zTF7H5K3qXAQAAX7LGoRzuAS2YPuts6i2GY3c5NPh29GDRPDuVcsU5ldOgLT7vVOIxWin+nyFHABHMC1AzExM2hgf8ephPbFyTKOvw+oqZYCotc2SZ9KInqsVW9Uv5DM3ADRsT8N/NpRj3k9mmInVTOFyhfwRqy49PIefuymKmcOjFVFlm4TgfjQjbcvXASGDfCGekdowZn+q0StBcaMRqG4l8R6uT8AFhB4Lwtcx/iwp1rbY2C/xcyAnhBJxxrQPbrH+p0CYuG+i+JeJGk/8PifjXRdoOfDl/UbYAOp/iSkdMVoOBd60Ph/wzwMrQT5mXmm8xG/p+oBTmmpkceD1kXc3F291wWdZejeefZo9bf9PYaxQ6SMhYdoj53TW2iR6WDVPmbvzo8TmK5wOVYAImRWxw0onSqeinTO3zbSk7sS61cJu86Gk8Fh/mfSnzspsDwTKE5HhLqBC0N60=',
        '_gcl_au': '1.1.179072727.1750765844',
        'gaUserId': '303bd5a6-cd8f-4e8d-aec9-a90cffaa6c86',
        '_gid': 'GA1.3.1597619331.1750765845',
        '_fbp': 'fb.2.1750765844989.690167923411978391',
        'FPLC': 'QasWFkci%2FU0VMbaWwqFP%2BbYh9Yf4y2Tn%2BHUvcCFcJ3nzy4pKFQAx1QQdscbANrcNJsPvSlqpHpNvgMWLEuN9pFrRUOibQy%2FLsww29qaS94PK1KJ0zIV81PK9lq0%2BIw%3D%3D',
        '_tt_enable_cookie': '1',
        '_ttp': '01JYGWDEMZEM25885RTGD4D919_.tt.2',
        'FPID': 'FPID2.3.hZhLs%2F78H3D26s%2FRCyEIaP6UZvV72nkKVu8eDxfmSXs%3D.1750765844',
        '_abck': '344C7DCC1C7EC8D18746111544D886DB~0~YAAQj/zTF3b6K3qXAQAAt9TGoQ5+R9JOQ93CC6zhOXZBXPYwtzRcnsgXhsf8E5Ce1c/UuUBNGHcJiOwJCj/w2NPxyVsveS5mO4XJzteXpqLSV2NSMEfDX+jOPC+wNRXVCKQJ1rlyV/yLSG+N+T8EE9s/R3+WdlT5CfWOur6lZbpRr8uzGtT5kTnYk58i2aS/OHduZXetO0IO+eYoRDb+WsLY+4aYWNkgz0S8CKbB9jR/BgaV4/w274gEB3Y5VmigNAS1fCFBeInZ3bK7p6Qom7plx+lGGbg34hql20oRFzdGvw9aZ5HelF/zFX1uCwU82NIbIqwopQFMo5Bmk3hmVEmXkyXonIPv+MGuNNs2YJYt2vAOu26QG7j7jydacQWk+usU5gD6NbejeUWDSDRcZNFUKOBQ3lrpzxoMP1NKfLY0rBMHfAHznp+nXYFHyOKbfwpgCvObqG8mkaeWMZcTG6B9tIZE1iRxws+wC5IJUqFayz49BTe0lKGEZ8uH4FgwcBkEMT3gnBxM06leRuFABxEnuCAo2AsCKTi/1oZJGHhRNsaYAfY5BX1DsbRmzgIEU2bcZdTVTB3NGJPL7AaHiTAaXqtpRvTYY9W74K6b2nKxGqLozdSUDwwsLejZmXx8BbU=~-1~-1~-1',
        'OptanonAlertBoxClosed': '2025-06-24T12:06:24.770Z',
        'BP_69647_itemListId': "don't%20miss%20out!_up%20to%2050%25%20off%20hot%20deals_gnc%20top%20sellers",
        'BP_69647_itemListName': "don't%20miss%20out!_up%20to%2050%25%20off%20hot%20deals_gnc%20top%20sellers",
        'RT': '"z=1&dm=www.watsons.com.sg&si=7bb82727-0074-4ac4-b2e5-f632b665a633&ss=mcai9b0m&sl=0&tt=0"',
        'checkout_sskey': '0351e948569844b18f914b3a309b4378',
        'checkout_utm_src': 'Optimise_Involve_Asia',
        'checkout_utm_medium': 'affiliate',
        '__gtm_campaign_url': 'https%3A%2F%2Fwww.watsons.com.sg%2F%3Futm_source%3DOptimise_Involve_Asia%26utm_medium%3Daffiliate%26sskey%3D0351e948569844b18f914b3a309b4378',
        '__gtm_referrer': 'https%3A%2F%2Ftatrck.com%2F1rOlv4MrHp',
        '__rtbh.uid': '%7B%22eventType%22%3A%22uid%22%2C%22id%22%3A%22unknown%22%2C%22expiryDate%22%3A%222026-06-24T12%3A32%3A18.713Z%22%7D',
        'AKA_A2': 'A',
        'bm_sz': 'A25E0CE00FA4FB63EF14B114B5274A53~YAAQE9YsF2NTD1yXAQAApqv0oRyCxre1Piw4CBgG9oL9DxCJZAHZgHAhXezPTDV1tbxOpgGWvV0mYwK/rxx6BETQseslJTCJdaF+ky90FUE8gu/Ec6gLxt2M3KAVFvK78MSnEg09GdglBkWzN8Zxrdy7R5uo9PRyPlOADutz4Yc4jImRHBj996uoEHG2mQEAicvAvfDkgu2nEGU+Pty80JAmKzreSwo8sZzyc2KTaP1iGXQd8o9+5F9AngrYuWIoFNiZHRUQxuA0dbL3eC7xXFXsq2v+0C9t0Y9Z7Cl0PJeb6NERwDOqxdSL7y1yhHC0px3tj8YZ8sh3qBz5jIuEM3vuT07T9837wgcg7zc91PQsetx+gbgyrEnp8BzJY3orNC416DHaUk5i6O/I50piE1DwQRV8azdUoCL7+0w2GTpyTzIDLQJ9r2vtiFIcl9DyD4qKTAVZ~4405561~4600889',
        'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A197a1c6b11f655-0eb3dd7f7eba0f8-26011e51-144000-197a1c6b11f655%22%2C%22%24device_id%22%3A%20%22197a1c6b11f655-0eb3dd7f7eba0f8-26011e51-144000-197a1c6b11f655%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
        'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Jun+24+2025+18%3A10%3A57+GMT%2B0530+(India+Standard+Time)&version=202411.1.0&browserGpcFlag=0&isIABGlobal=false&hosts=&consentId=845bdbbb-a92b-4d6b-9569-371863b6cf54&interactionCount=2&isAnonUser=1&landingPath=NotLandingPage&groups=C0001%3A1%2CC0003%3A1%2CC0009%3A1&intType=3&geolocation=SG%3B&AwaitingReconsent=false',
        '__rtbh.lid': '%7B%22eventType%22%3A%22lid%22%2C%22id%22%3A%22DrU46361zDjP1ZeNlJAm%22%2C%22expiryDate%22%3A%222026-06-24T12%3A40%3A58.284Z%22%7D',
        '_ga': 'GA1.3.809404733.1750765844',
        '_dc_gtm_UA-24603058-1': '1',
        'FPGSID': '1.1750768335.1750768858.G-74TLQ1GNYW.UB2ZbqP_58fEIBlEdrto6Q',
        'bm_sv': 'AB07BC1810B6AEDCF26E91B95DF34FCD~YAAQueQ+F1FWQX+XAQAArbf0oRyPE9vlECWO4Ad0FQIluGa1VuEWCURKCAOX0mraB1fq6KakQoqt+XoBbILVvQWvNBEYA89cnrexWz9FHvw5N2Ai8v9esdpibDAYEU6qGXazpI7bgWkQms4hL4zCkSYuqBLw5pd2WiYpHK0L5W5NTtT+L2AGZ6l3WreW5Dr2lyJCPifNv0UHWy3V+Y3yIhBeQRZLL4LS7G593j3gH4Rg8+xzK6Y514duWk10oD46uTtANR8=~1',
        'ttcsid': '1750765845154::5Pg5V4whGzZzAgV-3YfR.1.1750768859380',
        'ttcsid_CVHRSNBC77UC8GUEIHN0': '1750765845153::j4Tml3PQU5oMZwt18p3-.1.1750768859605',
        '_ga_74TLQ1GNYW': 'GS2.1.s1750765844$o1$g1$t1750768861$j57$l0$h76476424',
    }

    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
        'cache-control': 'max-age=0',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
        'cookie': 'gaUserId=841c9511-559c-4e18-bf4d-6281db83fe7f; _gcl_au=1.1.223475166.1749446789; FPID=FPID2.3.l6LHFbWHktBb1Kp4bj%2FtBFFkMNLAD9YBF%2FVBbJ9qYEE%3D.1749446789; _atrk_siteuid=Kc4f39qwOyO2Ax6L; _tt_enable_cookie=1; _ttp=01JX9JF2S9CWDHES38GS2FHZGJ_.tt.2; _fbp=fb.3.1749446789865.1386455679; superuser=7afe20df-1468-4764-8577-96bf2520119a; page_refreshed=true; OptanonAlertBoxClosed=2025-06-09T05:27:22.811Z; dot_v_2416=YWFiZDBhYjI5YzAwY2ZhZjYyM2IzYjRiMDhhOGU2YjRjNWFhZWIwMmM3YzE1NDExYjA4ODE2YTM0NjRlODBmZjo6clNCcVRLdjZzSWxqZXZUa2tObkY5RlJoTHdlUUtQbUJrenV3TmVLTEJPYz0=; _ga_MK3DWTMMGQ=deleted; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A19753277cae922-06cda604015d05-26011e51-144000-19753277caf922%22%2C%22%24device_id%22%3A%20%2219753277cae922-06cda604015d05-26011e51-144000-19753277caf922%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; _ga=GA1.3.641459402.1749446789; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Jun+24+2025+17%3A20%3A15+GMT%2B0530+(India+Standard+Time)&version=202411.2.0&browserGpcFlag=0&isIABGlobal=false&hosts=&consentId=c9811122-4cda-4dd5-abc7-0e848a6e1cd0&interactionCount=2&isAnonUser=1&landingPath=NotLandingPage&groups=C0001%3A1%2CC0003%3A1%2CC0009%3A1&intType=3&geolocation=SG%3B&AwaitingReconsent=false; ttcsid=1750765816566::WcjkvxATjZkzwwGAMqL6.12.1750765816566; supersession=3644920; ttcsid_CFIA2EBC77U1MMAF3CM0=1750765816565::EdQ4K2sCoNsc-Ey4l-fp.12.1750765816808; _ga_MK3DWTMMGQ=GS2.1.s1750765815$o12$g1$t1750765837$j38$l0$h351782369; ROUTE=.jsapps-57db5b68fc-b6v8b; AKA_A2=A; _abck=CDC5FCECAF2814E95712D3880C7B8707~0~YAAQjPzTF4qgpbCXAQAAb8Jfyg4Rr0OPrJBUVNltFOdcakPmoMC/SYEcIDM/V8LoEhLitolqcJicwin946D93C7BomTLBXGOmUER5+l8jMnqLdaNeYj0lN6PDtP4D0HCWuyRg7owAWhppXqzr8Co9JhZPJr9CWVy7wNLQq5KQi0iiu/eAFMnIMSxh3aZvUqb0HADf3pK7fZmjYZZJHGiIHlveydjQGzE+R4IvcfYhyNT7qv4uIXcur2vYIy1CxO52rj7ZGLs/Hh4Jtb0KETXbIzdGhJCzIY7MHZWDgr85oXetuOhazvL7VKBFtTB4GGGE4N5Q+S4Qu5C+SeIhzIjZEoBlVz6m0I6Jm+HjBEMhAppUH7IyHb+wadz679uibCnmlFTUKaARerzSsUkb36MCwLZSr1WFOdhX/MX33FQk6pO8nWR+U1emP0tJw4VtKr7mvj3QMpw6nfvQ4pnZF7WN/SsaZ+dLiCLOTvrAtlSNfjpic+QwDecHyR+ylDj1BRamHgKYGhvpMgYIhzETmL8YR7sxxn9/oco3x78treeMMs67JGCpMPamnwda4iAIEkg7yVC+ovKqmXQXF53mzIlyXZvkyVRESAKuvt2ePlSk5LJKYaB4sdhmivosTk/0G+Krg8=~-1~-1~-1; bm_sz=22C9190DE95E91056056D674CF4CD163~YAAQjPzTF4ugpbCXAQAAb8JfyhwSo50x2ygTPsj+tzUm/5psIFW+jev9mPoT59otSK248+NN04gGwFBY38wz7xRqMBwQ/aaWGPB6IEI6s60EIrZbdgFvZ9C7E+tDuAcbEDFSTnQqKe2MgBh+2/fKcfgL8eOHowQfHUv4hbM9SzCOpFqE3Xtm/fuJ7P6y9lcubL+XV0K09eEi5WlrhT5DASe1amU2HxLMUeU/SI03TWdLWXXohRFHe2pUhMyljZAXT6QCaUw6GTKxp7SwL9jz58C1FEtXpU3ouPHFhf+JghQPhS3sGJepY6xbNp4KC0/ji0k/T3NyV3Q14tsLxby/OR3KqG+9pC0jd56IDxfcVITOzB9BMVL3okgUniYVtZ7g8EtppggKaK9m0azvvIH6reOCtA==~3159095~3163206',
    }
    parsed_url = urlparse(referer_url)

    product_slug = parsed_url.path.strip('/').split('/')[-1]
    # print("Product slug:", product_slug)
    html_filename = f"{product_slug}_page.html"
    html_filepath = os.path.join(html_path, html_filename)
    # main = 'https://www.bigpharmacy.com.my/product/ego-qv-cream-50g'

    apikey = '21ed11ef5c872bc7727680a52233027db4578a0e'
    params = {
        'url': f"{referer_url}",
        'apikey': apikey,
        'custom_headers': 'true',
        'js_render': 'true',

    }

    # address_main_response = obj_to.request('https://api.zenrows.com/v1/', params=params, headers=headers)
    # address_main_response = obj.to_requests(url='https://api.zenrows.com/v1/', headers=headers, params=params,
    #                            html_path=html_filepath,
    #                            should_be=['wtcmy-state'], max_retry=3)

    response = obj.to_requests(url=referer_url, headers=headers, html_path=html_filepath,
                               should_be=['wtcmy-state'], max_retry=3,proxies=proxies, verify=False)  # proxies=proxies, verify=False,
    if not response:
        print(f"getting wrong response:{referer_url}")
        return None
    elif 'Result Not Found' in response or 'This product is invalid.' in response or 'This page could not be found' in response:
        search_data.update_one(
            {'_id': id}, {'$set': {'Status': "Not found"}})
        print("Status Updated...")
    elif response:

        product_id = urlparse(referer_url).path.split('/')[-1].replace("BP_", "").strip()


        selector = Selector(text=response)

        json_text = selector.xpath('//script[@id="wtcmy-state"]/text()').get()
        data = json.loads(json_text)
        try:
            stock_status = data['cx-state']['product']['details']['entities'][str(product_id)]['variants']['value']['baseOptions'][0]['options'][
                0][
                'stock']['stockLevelStatus']
        except Exception as e:
            stock_status = data['cx-state']['product']['details']['entities'][str(product_id)]['variants']['value']['baseOptions'][0][
                'options'][
                0][
                'stock']['stockLevelStatus']
        if stock_status == "inStock":
            stock = True
        else:
            stock = False

        product = selector.xpath('//div[@class="ProductSummaryGroup"]')
        name = product.xpath('//div[@class="product-name"]/text()').get()
        brand = product.xpath('//h2[@class="product-brand"]/a/text()').get()
        main_price = product.xpath('//span[@class="price"]/text()').get()

        if main_price:
            price_value = float(main_price)

            price = int(price_value) if price_value.is_integer() else round(price_value, 2)
        else:
            price = None

        compare_price = product.xpath('//span[@class="retail-price"]/text()').get()

        if compare_price:
            cleaned_compare_price = compare_price.replace('RM', '').replace(',', '').strip()
            was_price_value = float(cleaned_compare_price)
            was_price = int(was_price_value) if was_price_value.is_integer() else round(was_price_value, 2)
        else:
            was_price = None

        # print(was_price)
        image_urls = product.xpath('//div[@class="ProductImages"]//img/@src').getall()
        main_offer = product.xpath('//span[@class="discount ng-star-inserted"]/text()').get() or ""
        offer = main_offer.strip()
        main_product_id = selector.xpath('//div[@class="info-container"]//div[@class="value"]/text()').get()
        joined_urls = '|'.join(image_urls)
        breadcrumbs = selector.xpath(
            '//span[@itemprop="itemListElement"]//span[contains(@itemprop, "name")]/text()').getall()
        breads = ' > '.join(item.strip() for item in breadcrumbs if item.strip())

        main_promo = selector.xpath('//div[@class="container-title"]/text()').get() or ""
        promo = main_promo.strip()
        if not was_price or price == was_price:
            rrp_price = price
            was_price = ''
        else:
            rrp_price = was_price
        pack_size = extract_size(name)

        Items = {"Name": name, "Promo_Type": promo, "Price": price, "per_unit_price": "",
                 "WasPrice": was_price,
                 "Offer_info": offer, "Pack_size": pack_size, "Barcode": "",
                 "Images": joined_urls,
                 "ProductURL": referer_url, "is_available": stock,
                 "Status": "Done", "ParentCode": "", "ProductCode": main_product_id,
                 "retailer_name": "Watson",
                 "Category_Hierarchy": breads, "Brand": brand, "RRP": rrp_price}
        try:
                product_data.insert_one(Items)
                print("product inserted")
                search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
        except Exception as e:
            print(e)

        # print(Items)

if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=20) as executor:
        docs = list(search_data.find({"Status": "Pending"}))
        executor.map(process_document, docs)


