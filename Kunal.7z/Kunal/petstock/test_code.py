import requests
from parsel import Selector
import json
cookies = {
    '_gcl_au': '1.1.2091965214.1745820429',
    '_hjSessionUser_1114048': 'eyJpZCI6ImU3MWQ4ZDljLTlhODktNWFkZi1iNzU4LWU1ZTU5ODEwNzNhNiIsImNyZWF0ZWQiOjE3NDU4MjA0MzAyNzgsImV4aXN0aW5nIjp0cnVlfQ==',
    '_fbp': 'fb.2.1745820430391.322218718713799742',
    '_cs_c': '0',
    '_ga_N6H4CZJYHX': 'deleted',
    '_gid': 'GA1.3.1442710934.1747206788',
    '_hjSession_1114048': 'eyJpZCI6ImNiOTk1MTYwLTMzMzktNDM4Zi1hM2RjLTc2NTFlYzk3NTE3MiIsImMiOjE3NDcyMDY3ODg3MjIsInMiOjEsInIiOjAsInNiIjowLCJzciI6MCwic2UiOjAsImZzIjowLCJzcCI6MH0=',
    'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A1967b01aa2c954-0f6f0f0b86dbad-26011c51-144000-1967b01aa2c954%22%2C%22%24device_id%22%3A%20%221967b01aa2c954-0f6f0f0b86dbad-26011c51-144000-1967b01aa2c954%22%2C%22%24search_engine%22%3A%20%22google%22%2C%22%24initial_referrer%22%3A%20%22https%3A%2F%2Fwww.google.com%2F%22%2C%22%24initial_referring_domain%22%3A%20%22www.google.com%22%7D',
    '_gat_UA-36272097-1': '1',
    '__kla_id': 'eyJjaWQiOiJOVFl4TW1VNE16Z3RZakJrTVMwME1tSm1MVGhqWlRNdFl6UTNOV1JtTnpabE9ERTUiLCIkcmVmZXJyZXIiOnsidHMiOjE3NDU4MjA0MzAsInZhbHVlIjoiaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8iLCJmaXJzdF9wYWdlIjoiaHR0cHM6Ly93d3cucGV0c3RvY2suY29tLmF1LyJ9LCIkbGFzdF9yZWZlcnJlciI6eyJ0cyI6MTc0NzIwOTAzNywidmFsdWUiOiJodHRwczovL3d3dy5nb29nbGUuY29tLyIsImZpcnN0X3BhZ2UiOiJodHRwczovL3d3dy5wZXRzdG9jay5jb20uYXUvP3Nyc2x0aWQ9QWZtQk9vcWo0bDRlOWpRWjcxN3RQNTVUYTBEd2traDBueVZhUVYyWXZnNkxrMk9uNWpUa0VTSmQifX0=',
    'dicbo_id': '%7B%22dicbo_fetch%22%3A1747209037644%7D',
    'cto_bundle': 'lYP0yl9OelBxSnNsRkFKM2R0clJQVXh0TDc3bFJkdVhQbVlXTDF5ZHoySkpCVGp1VGRnS3Jad1Y0TDZmQlRkTjZ3TUJjUTBpJTJGbnJHS2dXRVE2S2olMkJjeEVya0JUSlh6ekM3Q1dQclRsaHBrOUpJT28lMkJDSjNtQ1E3VU1yT1FlbTA3cTVqZ05pNzdTMFUySGt6czJOenF2TnI4dEdYejBXYXRESDVoOTFKdCUyQnp3NHlaaG1RYXVRR0YlMkJGTmdTM3NteTlpWVZ0WCUyQnBJNlVqY0pMZGlDSXpzbTg2S0dBJTNEJTNE',
    '_ga': 'GA1.3.1830772252.1745820430',
    '_cs_id': '3123ef53-1c04-acfd-8aab-3dc5479f0085.1745820431.10.1747209039.1747206791.1.1779984431701.1.x',
    '_cs_s': '3.0.0.9.1747210839339',
    '_uetsid': 'e38e7db0309211f08c3677891ad28461',
    '_uetvid': '0554900023f711f0a55daf9702a81ff8',
    '_ga_N6H4CZJYHX': 'GS2.1.s1747208901$o6$g1$t1747209040$j56$l0$h1450417118',
    '_pz_clickref': '1110l3FEwJX',
}

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
    'cache-control': 'max-age=0',
    # 'if-none-match': 'W/"et572tgg3u4k96"',
    'priority': 'u=0, i',
    'referer': 'https://www.google.com/',
    'sec-ch-ua': '"Chromium";v="136", "Google Chrome";v="136", "Not.A/Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
    # 'cookie': '_gcl_au=1.1.2091965214.1745820429; _hjSessionUser_1114048=eyJpZCI6ImU3MWQ4ZDljLTlhODktNWFkZi1iNzU4LWU1ZTU5ODEwNzNhNiIsImNyZWF0ZWQiOjE3NDU4MjA0MzAyNzgsImV4aXN0aW5nIjp0cnVlfQ==; _fbp=fb.2.1745820430391.322218718713799742; _cs_c=0; _ga_N6H4CZJYHX=deleted; _gid=GA1.3.1442710934.1747206788; _hjSession_1114048=eyJpZCI6ImNiOTk1MTYwLTMzMzktNDM4Zi1hM2RjLTc2NTFlYzk3NTE3MiIsImMiOjE3NDcyMDY3ODg3MjIsInMiOjEsInIiOjAsInNiIjowLCJzciI6MCwic2UiOjAsImZzIjowLCJzcCI6MH0=; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A1967b01aa2c954-0f6f0f0b86dbad-26011c51-144000-1967b01aa2c954%22%2C%22%24device_id%22%3A%20%221967b01aa2c954-0f6f0f0b86dbad-26011c51-144000-1967b01aa2c954%22%2C%22%24search_engine%22%3A%20%22google%22%2C%22%24initial_referrer%22%3A%20%22https%3A%2F%2Fwww.google.com%2F%22%2C%22%24initial_referring_domain%22%3A%20%22www.google.com%22%7D; _gat_UA-36272097-1=1; __kla_id=eyJjaWQiOiJOVFl4TW1VNE16Z3RZakJrTVMwME1tSm1MVGhqWlRNdFl6UTNOV1JtTnpabE9ERTUiLCIkcmVmZXJyZXIiOnsidHMiOjE3NDU4MjA0MzAsInZhbHVlIjoiaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8iLCJmaXJzdF9wYWdlIjoiaHR0cHM6Ly93d3cucGV0c3RvY2suY29tLmF1LyJ9LCIkbGFzdF9yZWZlcnJlciI6eyJ0cyI6MTc0NzIwOTAzNywidmFsdWUiOiJodHRwczovL3d3dy5nb29nbGUuY29tLyIsImZpcnN0X3BhZ2UiOiJodHRwczovL3d3dy5wZXRzdG9jay5jb20uYXUvP3Nyc2x0aWQ9QWZtQk9vcWo0bDRlOWpRWjcxN3RQNTVUYTBEd2traDBueVZhUVYyWXZnNkxrMk9uNWpUa0VTSmQifX0=; dicbo_id=%7B%22dicbo_fetch%22%3A1747209037644%7D; cto_bundle=lYP0yl9OelBxSnNsRkFKM2R0clJQVXh0TDc3bFJkdVhQbVlXTDF5ZHoySkpCVGp1VGRnS3Jad1Y0TDZmQlRkTjZ3TUJjUTBpJTJGbnJHS2dXRVE2S2olMkJjeEVya0JUSlh6ekM3Q1dQclRsaHBrOUpJT28lMkJDSjNtQ1E3VU1yT1FlbTA3cTVqZ05pNzdTMFUySGt6czJOenF2TnI4dEdYejBXYXRESDVoOTFKdCUyQnp3NHlaaG1RYXVRR0YlMkJGTmdTM3NteTlpWVZ0WCUyQnBJNlVqY0pMZGlDSXpzbTg2S0dBJTNEJTNE; _ga=GA1.3.1830772252.1745820430; _cs_id=3123ef53-1c04-acfd-8aab-3dc5479f0085.1745820431.10.1747209039.1747206791.1.1779984431701.1.x; _cs_s=3.0.0.9.1747210839339; _uetsid=e38e7db0309211f08c3677891ad28461; _uetvid=0554900023f711f0a55daf9702a81ff8; _ga_N6H4CZJYHX=GS2.1.s1747208901$o6$g1$t1747209040$j56$l0$h1450417118; _pz_clickref=1110l3FEwJX',
}

response = requests.get(
    'https://www.petstock.com.au/products/be-frank-kangaroo-and-lamb-dry-dog-food-variant-100000141764',
    cookies=cookies,
    headers=headers,
)
selector = Selector(response.text)

# Extract the JSON content inside the <script id="__NEXT_DATA__">

json_text = selector.xpath('//script[@id="__NEXT_DATA__"]/text()').get()

if json_text:
    try:
        data = json.loads(json_text)
        print("Parsed JSON successfully!")
        props = data.get('props', {})
        pageProps = props.get('pageProps', {})
        product_path = pageProps.get('product')
        variants = product_path.get('variants')[1]
        stock = variants.get("inStockInNetwork")
        # Navigate the structure as needed:
        # e.g. product = data["props"]["pageProps"]["product"]
        print(data)
        print(stock)
    except json.JSONDecodeError as e:
        print("JSON parsing failed:", e)
else:
    print("Script tag with id='__NEXT_DATA__' not found.")