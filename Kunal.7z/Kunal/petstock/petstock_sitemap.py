from lxml import etree
# from pymongo import MongoClient
from config import *
cookies = {
    '_gcl_au': '1.1.2091965214.1745820429',
    '_hjSessionUser_1114048': 'eyJpZCI6ImU3MWQ4ZDljLTlhODktNWFkZi1iNzU4LWU1ZTU5ODEwNzNhNiIsImNyZWF0ZWQiOjE3NDU4MjA0MzAyNzgsImV4aXN0aW5nIjp0cnVlfQ==',
    '_fbp': 'fb.2.1745820430391.322218718713799742',
    '_cs_c': '0',
    '_ga_N6H4CZJYHX': 'deleted',
    '_pz_clickref': '1110l3FEwJX',
    '_gid': 'GA1.3.773063262.1748327058',
    '_hjSession_1114048': 'eyJpZCI6IjE4ZTYzOTk2LWU3ODItNDVhZC04ZmY2LTA4ZWY2OThhMTBhZCIsImMiOjE3NDgzMjcwNTgzMjUsInMiOjEsInIiOjAsInNiIjowLCJzciI6MCwic2UiOjAsImZzIjowLCJzcCI6MH0=',
    'dicbo_id': '%7B%22dicbo_fetch%22%3A1748327059309%7D',
    '_gat_UA-36272097-1': '1',
    '_ga': 'GA1.1.1830772252.1745820430',
    '__kla_id': 'eyJjaWQiOiJOVFl4TW1VNE16Z3RZakJrTVMwME1tSm1MVGhqWlRNdFl6UTNOV1JtTnpabE9ERTUiLCIkcmVmZXJyZXIiOnsidHMiOjE3NDU4MjA0MzAsInZhbHVlIjoiaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8iLCJmaXJzdF9wYWdlIjoiaHR0cHM6Ly93d3cucGV0c3RvY2suY29tLmF1LyJ9LCIkbGFzdF9yZWZlcnJlciI6eyJ0cyI6MTc0ODMyNzMxOSwidmFsdWUiOiIiLCJmaXJzdF9wYWdlIjoiaHR0cHM6Ly93d3cucGV0c3RvY2suY29tLmF1L3Byb2R1Y3RzL2dyZWVuaWVzLW92ZW4tcm9hc3RlZC1jaGlja2VuLWZlbGluZS1kZW50YWwtY2F0LXRyZWF0cyJ9fQ==',
    '_uetsid': '37f677703ac311f0af109386294fbcca',
    '_uetvid': '0554900023f711f0a55daf9702a81ff8',
    'cto_bundle': 'O8swzF9OelBxSnNsRkFKM2R0clJQVXh0TDclMkJwJTJGTyUyRnYzM1RSSk9mYnBnV0RJb1NJYUxtZWdteFNZc3gydk43c0Mxb1RYbUpPWXJ0VHZSd1ZnZWtSTnFyaDhsMEpxbUs0bXlPbW1OT2FqenJ1MHBobEdRc2IlMkYlMkZQTSUyRjBPU0JpQ2FFYWJCOGo5RUhMRVh2WDBHV1kwZHJ1TlhrOGQxbzZhRjFSTHpTTElncFJKa3dTTWp6OG5vdDlOUWJEaDZtbm5TaHlMMWdJSndHcDdzanpKTXNKN2t0dTZRdEIzN2s0NU5laWp3d2h6c2lzeGRZaHpuaVducDJjZ1klMkZtZU1uTCUyRnFOdHhOQmVXQk9kbk5CQ1BhbWRVUjlhWFJZSHdvampPSXN5OVB1SE5XWWhacnpXNHhKZFdXTzZwNVZwMzUwNW02RmIlMkJ6JTJC',
    '_cs_id': '3123ef53-1c04-acfd-8aab-3dc5479f0085.1745820431.16.1748327320.1748327061.1.1779984431701.1.x',
    '_cs_s': '2.0.0.9.1748329120117',
    '_ga_N6H4CZJYHX': 'GS2.1.s1748327057$o12$g1$t1748327338$j39$l0$h1033483174$dV-upZGONDRINM3pMIA8T30G7I4ajPXWSIg',
    'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A1967b01aa2c954-0f6f0f0b86dbad-26011c51-144000-1967b01aa2c954%22%2C%22%24device_id%22%3A%20%221967b01aa2c954-0f6f0f0b86dbad-26011c51-144000-1967b01aa2c954%22%2C%22%24search_engine%22%3A%20%22google%22%2C%22%24initial_referrer%22%3A%20%22https%3A%2F%2Fwww.google.com%2F%22%2C%22%24initial_referring_domain%22%3A%20%22www.google.com%22%7D',
}

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
    'priority': 'u=0, i',
    'sec-ch-ua': '"Chromium";v="136", "Google Chrome";v="136", "Not.A/Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
    # 'cookie': '_gcl_au=1.1.2091965214.1745820429; _hjSessionUser_1114048=eyJpZCI6ImU3MWQ4ZDljLTlhODktNWFkZi1iNzU4LWU1ZTU5ODEwNzNhNiIsImNyZWF0ZWQiOjE3NDU4MjA0MzAyNzgsImV4aXN0aW5nIjp0cnVlfQ==; _fbp=fb.2.1745820430391.322218718713799742; _cs_c=0; _ga_N6H4CZJYHX=deleted; _pz_clickref=1110l3FEwJX; _gid=GA1.3.773063262.1748327058; _hjSession_1114048=eyJpZCI6IjE4ZTYzOTk2LWU3ODItNDVhZC04ZmY2LTA4ZWY2OThhMTBhZCIsImMiOjE3NDgzMjcwNTgzMjUsInMiOjEsInIiOjAsInNiIjowLCJzciI6MCwic2UiOjAsImZzIjowLCJzcCI6MH0=; dicbo_id=%7B%22dicbo_fetch%22%3A1748327059309%7D; _gat_UA-36272097-1=1; _ga=GA1.1.1830772252.1745820430; __kla_id=eyJjaWQiOiJOVFl4TW1VNE16Z3RZakJrTVMwME1tSm1MVGhqWlRNdFl6UTNOV1JtTnpabE9ERTUiLCIkcmVmZXJyZXIiOnsidHMiOjE3NDU4MjA0MzAsInZhbHVlIjoiaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8iLCJmaXJzdF9wYWdlIjoiaHR0cHM6Ly93d3cucGV0c3RvY2suY29tLmF1LyJ9LCIkbGFzdF9yZWZlcnJlciI6eyJ0cyI6MTc0ODMyNzMxOSwidmFsdWUiOiIiLCJmaXJzdF9wYWdlIjoiaHR0cHM6Ly93d3cucGV0c3RvY2suY29tLmF1L3Byb2R1Y3RzL2dyZWVuaWVzLW92ZW4tcm9hc3RlZC1jaGlja2VuLWZlbGluZS1kZW50YWwtY2F0LXRyZWF0cyJ9fQ==; _uetsid=37f677703ac311f0af109386294fbcca; _uetvid=0554900023f711f0a55daf9702a81ff8; cto_bundle=O8swzF9OelBxSnNsRkFKM2R0clJQVXh0TDclMkJwJTJGTyUyRnYzM1RSSk9mYnBnV0RJb1NJYUxtZWdteFNZc3gydk43c0Mxb1RYbUpPWXJ0VHZSd1ZnZWtSTnFyaDhsMEpxbUs0bXlPbW1OT2FqenJ1MHBobEdRc2IlMkYlMkZQTSUyRjBPU0JpQ2FFYWJCOGo5RUhMRVh2WDBHV1kwZHJ1TlhrOGQxbzZhRjFSTHpTTElncFJKa3dTTWp6OG5vdDlOUWJEaDZtbm5TaHlMMWdJSndHcDdzanpKTXNKN2t0dTZRdEIzN2s0NU5laWp3d2h6c2lzeGRZaHpuaVducDJjZ1klMkZtZU1uTCUyRnFOdHhOQmVXQk9kbk5CQ1BhbWRVUjlhWFJZSHdvampPSXN5OVB1SE5XWWhacnpXNHhKZFdXTzZwNVZwMzUwNW02RmIlMkJ6JTJC; _cs_id=3123ef53-1c04-acfd-8aab-3dc5479f0085.1745820431.16.1748327320.1748327061.1.1779984431701.1.x; _cs_s=2.0.0.9.1748329120117; _ga_N6H4CZJYHX=GS2.1.s1748327057$o12$g1$t1748327338$j39$l0$h1033483174$dV-upZGONDRINM3pMIA8T30G7I4ajPXWSIg; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A1967b01aa2c954-0f6f0f0b86dbad-26011c51-144000-1967b01aa2c954%22%2C%22%24device_id%22%3A%20%221967b01aa2c954-0f6f0f0b86dbad-26011c51-144000-1967b01aa2c954%22%2C%22%24search_engine%22%3A%20%22google%22%2C%22%24initial_referrer%22%3A%20%22https%3A%2F%2Fwww.google.com%2F%22%2C%22%24initial_referring_domain%22%3A%20%22www.google.com%22%7D',
}
sitemaps = [
       'https://petstock.com.au/sitemap-0.xml'
       # 'https://petstock.com.au/sitemap-1.xml',
       # 'https://petstock.com.au/sitemap-2.xml',
]

for sitemap_url in sitemaps:
    resp = requests.get(sitemap_url, headers=headers, cookies=cookies)
    print(f"{sitemap_url} → {resp.status_code}")
    if resp.status_code != 200:
        continue

    root = etree.fromstring(resp.content)
    namespaces = {'ns': 'http://www.sitemaps.org/schemas/sitemap/0.9'}
    loc_elements = root.xpath('//ns:loc', namespaces=namespaces)

    for loc in loc_elements:
        url = loc.text.strip()
        search_data.update_one(
            {"url": url},
            {"$set": {"url": url, "Status": "Pending"}},
            upsert=True
        )
        print(f"Inserted: {url}")
