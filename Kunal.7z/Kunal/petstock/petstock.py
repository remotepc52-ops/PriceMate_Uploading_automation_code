from concurrent.futures import ThreadPoolExecutor
import json
from urllib.parse import urlparse

import logging
from config import *


def get_id():
    import json
    import requests
    from scrapy.selector import Selector

    headers1 = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
        # 'cookie': '_gcl_au=1.1.485781165.1767343621; _cs_c=0; _ALGOLIA=anonymous-836ba19f-8d0e-4f2d-8bab-3e3f03707434; _gid=GA1.3.1837956183.1767343621; _tt_enable_cookie=1; _ttp=01KDYY7189628J6NGCCXMYKMX2_.tt.2; _hjSession_1114048=eyJpZCI6IjE1ZDVhOGFjLTJiYzYtNDNjOC1iOGI5LTA0NzM3ZDJmMjUzMyIsImMiOjE3NjczNDM2MjE0ODIsInMiOjAsInIiOjAsInNiIjowLCJzciI6MCwic2UiOjAsImZzIjoxLCJzcCI6MX0=; __kla_id=eyJjaWQiOiJZek15WmpBM1l6a3RNbU0xTVMwME9EazRMV0ppWmpVdFkyVTJZemN5TURsaFlUazMifQ==; _fbp=fb.2.1767343621954.43322550452247567; _hjSessionUser_1114048=eyJpZCI6ImQwNzM2OTFhLWIwYmUtNTEzZC1iOGIyLTM0Y2FkOTE3ODFkOSIsImNyZWF0ZWQiOjE3NjczNDM2MjE0NzksImV4aXN0aW5nIjp0cnVlfQ==; algolia_query_id=db517f38c9a2784329aa97462bdd0e07; _gat_UA-36272097-1=1; _ga_N6H4CZJYHX=GS2.1.s1767343621$o1$g1$t1767343935$j60$l0$h1661771164; _ga=GA1.1.216742820.1767343621; _uetsid=9afad840e7b711f0b528d5e6de2b61e8; _uetvid=9afafa20e7b711f082cb6bfa4cf69249; ttcsid=1767343621388::6DMH-br4FgbEjQd1rko1.1.1767343936541.0; ttcsid_C5RKPHAI9NEVD2IFVMA0=1767343621387::NHO_yb3Z2BoPMJqAAFNU.1.1767343936541.1; _cs_id=d09ec703-9a40-a369-a367-7b4313f20c7c.1767343620.1.1767343937.1767343620.1.1801507620654.1.x; _cs_s=7.0.U.9.1767345737483',
    }

    response = requests.get('https://www.petstock.com.au/', headers=headers1)
    if response.status_code == 200:
        data = Selector(text=response.text)
        script = data.xpath('.//script[@id="__NEXT_DATA__"]/text()').get()
        json_data = json.loads(script)
        buildId = json_data.get('buildId')
        return buildId
    else:
        print(response.status_code)


build_id = get_id()


def process_document(doc):
    global was_price_raw, buyone_offer, was_p, stock, breadcrumbs_string
    try:
        full_url = doc.get('url')
        doc_id = doc['_id']

        if not full_url:
            search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
            return

        parsed = urlparse(full_url)
        match = re.search(r'/products/(.*)', parsed.path)
        if not match:
            search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
            return

        product_path = match.group(1).strip('/')
        api_url = f"https://www.petstock.com.au/_next/data/{build_id}/en-AU/products/{product_path}.json"

        headers = {
            'accept': '*/*',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
            'x-nextjs-data': '1',
        }

        response = requests.get(api_url, headers=headers)
        if response.status_code != 200:
            logging.warning(f"Non-200 response for {full_url}: {response.status_code}")
            search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
            return

        data = response.json()
        product = data.get('pageProps', {}).get('product', {})
        product_id = product.get('id')
        product_main = product_id.split('/')[-1]

        if not product:
            logging.warning(f"No product data for {full_url}")
            search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
            return

        variants = data.get('pageProps', {}).get('product', {}).get('variants', [])
        if variants and isinstance(variants, list):
            sku = variants[0].get('sku')
        else:
            sku = None

        cookies = {
            '_gcl_au': '1.1.2091965214.1745820429',
            '_hjSessionUser_1114048': 'eyJpZCI6ImU3MWQ4ZDljLTlhODktNWFkZi1iNzU4LWU1ZTU5ODEwNzNhNiIsImNyZWF0ZWQiOjE3NDU4MjA0MzAyNzgsImV4aXN0aW5nIjp0cnVlfQ==',
            '_fbp': 'fb.2.1745820430391.322218718713799742',
            '_cs_c': '0',
            # '_ga_N6H4CZJYHX': 'deleted',
            '_gid': 'GA1.3.1442710934.1747206788',
            '_hjSession_1114048': 'eyJpZCI6ImNiOTk1MTYwLTMzMzktNDM4Zi1hM2RjLTc2NTFlYzk3NTE3MiIsImMiOjE3NDcyMDY3ODg3MjIsInMiOjEsInIiOjAsInNiIjowLCJzciI6MCwic2UiOjAsImZzIjowLCJzcCI6MH0=',
            'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A1967b01aa2c954-0f6f0f0b86dbad-26011c51-144000-1967b01aa2c954%22%2C%22%24device_id%22%3A%20%221967b01aa2c954-0f6f0f0b86dbad-26011c51-144000-1967b01aa2c954%22%2C%22%24search_engine%22%3A%20%22google%22%2C%22%24initial_referrer%22%3A%20%22https%3A%2F%2Fwww.google.com%2F%22%2C%22%24initial_referring_domain%22%3A%20%22www.google.com%22%7D',
            '_gat_UA-36272097-1': '1',
            '__kla_id': 'eyJjaWQiOiJOVFl4TW1VNE16Z3RZakJrTVMwME1tSm1MVGhqWlRNdFl6UTNOV1JtTnpabE9ERTUiLCIkcmVmZXJyZXIiOnsidHMiOjE3NDU4MjA0MzAsInZhbHVlIjoiaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8iLCJmaXJzdF9wYWdlIjoiaHR0cHM6Ly93d3cucGV0c3RvY2suY29tLmF1LyJ9LCIkbGFzdF9yZWZlcnJlciI6eyJ0cyI6MTc0NzIwOTAzNywidmFsdWUiOiJodHRwczovL3d3dy5nb29nbGUuY29tLyIsImZpcnN0X3BhZ2UiOiJodHRwczovL3d3dy5wZXRzdG9jay5jb20uYXUvP3Nyc2x0aWQ9QWZtQk9vcWo0bDRlOWpRWjcxN3RQNTVUYTBEd2traDBueVZhUVYyWXZnNkxrMk9uNWpUa0VTSmQifX0=',
            'dicbo_id': '%7B%22dicbo_fetch%22%3A1747209037644%7D',
            'cto_bundle': 'lYP0yl9OelBxSnNsRkFKM2R0clJQVXh0TDc3bFJkdVhQbVlXTDF5ZHoySkpCVGp1VGRnS3Jad1Y0TDZmQlRkTjZ3TUJjUTBpJTJGbnJHS2dXRVE2S2olMkJjeEVya0JUSlh6ekM3Q1dQclRsaHBrOUpJT28lMkJDSjNtQ1E3VU1yT1FlbTA3cTVqZ05pNzdTMFUySGt6czJOenF2TnI4dEdYejBXYXRESDVoOTFKdCUyQnp3NHlaaG1RYXVRR0YlMkJGTmdTM3NteTlpWVZ0WCUyQnBJNlVqY0pMZGlDSXpzbTg2S0dBJTNEJTNE',
            '_ga': 'GA1.3.1830772252.1745820430',
            '_cs_id': '3123ef53-1c04-acfd-8aab-3dc5479f0085.1745820431.10.1747209039.1747206791.1.1779984431701.1.x',
            '_cs_s': '3.0.0.9.1747210839339',
            '_uetsid': 'e38e7db0309211f08c3677891ad28461',
            '_uetvid': '0554900023f711f0a55daf9702a81ff8',
            '_ga_N6H4CZJYHX': 'GS2.1.s1747208901$o6$g1$t1747209040$j56$l0$h1450417118',
            '_pz_clickref': '1110l3FEwJX',
        }

        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
            'cache-control': 'max-age=0',
            # 'if-none-match': 'W/"et572tgg3u4k96"',
            'priority': 'u=0, i',
            'referer': 'https://www.google.com/',
            'sec-ch-ua': '"Chromium";v="136", "Google Chrome";v="136", "Not.A/Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
            # 'cookie': '_gcl_au=1.1.2091965214.1745820429; _hjSessionUser_1114048=eyJpZCI6ImU3MWQ4ZDljLTlhODktNWFkZi1iNzU4LWU1ZTU5ODEwNzNhNiIsImNyZWF0ZWQiOjE3NDU4MjA0MzAyNzgsImV4aXN0aW5nIjp0cnVlfQ==; _fbp=fb.2.1745820430391.322218718713799742; _cs_c=0; _ga_N6H4CZJYHX=deleted; _gid=GA1.3.1442710934.1747206788; _hjSession_1114048=eyJpZCI6ImNiOTk1MTYwLTMzMzktNDM4Zi1hM2RjLTc2NTFlYzk3NTE3MiIsImMiOjE3NDcyMDY3ODg3MjIsInMiOjEsInIiOjAsInNiIjowLCJzciI6MCwic2UiOjAsImZzIjowLCJzcCI6MH0=; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A1967b01aa2c954-0f6f0f0b86dbad-26011c51-144000-1967b01aa2c954%22%2C%22%24device_id%22%3A%20%221967b01aa2c954-0f6f0f0b86dbad-26011c51-144000-1967b01aa2c954%22%2C%22%24search_engine%22%3A%20%22google%22%2C%22%24initial_referrer%22%3A%20%22https%3A%2F%2Fwww.google.com%2F%22%2C%22%24initial_referring_domain%22%3A%20%22www.google.com%22%7D; _gat_UA-36272097-1=1; __kla_id=eyJjaWQiOiJOVFl4TW1VNE16Z3RZakJrTVMwME1tSm1MVGhqWlRNdFl6UTNOV1JtTnpabE9ERTUiLCIkcmVmZXJyZXIiOnsidHMiOjE3NDU4MjA0MzAsInZhbHVlIjoiaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8iLCJmaXJzdF9wYWdlIjoiaHR0cHM6Ly93d3cucGV0c3RvY2suY29tLmF1LyJ9LCIkbGFzdF9yZWZlcnJlciI6eyJ0cyI6MTc0NzIwOTAzNywidmFsdWUiOiJodHRwczovL3d3dy5nb29nbGUuY29tLyIsImZpcnN0X3BhZ2UiOiJodHRwczovL3d3dy5wZXRzdG9jay5jb20uYXUvP3Nyc2x0aWQ9QWZtQk9vcWo0bDRlOWpRWjcxN3RQNTVUYTBEd2traDBueVZhUVYyWXZnNkxrMk9uNWpUa0VTSmQifX0=; dicbo_id=%7B%22dicbo_fetch%22%3A1747209037644%7D; cto_bundle=lYP0yl9OelBxSnNsRkFKM2R0clJQVXh0TDc3bFJkdVhQbVlXTDF5ZHoySkpCVGp1VGRnS3Jad1Y0TDZmQlRkTjZ3TUJjUTBpJTJGbnJHS2dXRVE2S2olMkJjeEVya0JUSlh6ekM3Q1dQclRsaHBrOUpJT28lMkJDSjNtQ1E3VU1yT1FlbTA3cTVqZ05pNzdTMFUySGt6czJOenF2TnI4dEdYejBXYXRESDVoOTFKdCUyQnp3NHlaaG1RYXVRR0YlMkJGTmdTM3NteTlpWVZ0WCUyQnBJNlVqY0pMZGlDSXpzbTg2S0dBJTNEJTNE; _ga=GA1.3.1830772252.1745820430; _cs_id=3123ef53-1c04-acfd-8aab-3dc5479f0085.1745820431.10.1747209039.1747206791.1.1779984431701.1.x; _cs_s=3.0.0.9.1747210839339; _uetsid=e38e7db0309211f08c3677891ad28461; _uetvid=0554900023f711f0a55daf9702a81ff8; _ga_N6H4CZJYHX=GS2.1.s1747208901$o6$g1$t1747209040$j56$l0$h1450417118; _pz_clickref=1110l3FEwJX',
        }

        # params = {
        #     'queryID': 'ab0c9d50849bf7c94b1749597c77dcb1',
        # }

        html_filename = f"{product_main}_page.html"
        html_filepath = os.path.join(html_path, html_filename)

        response_html = obj.to_requests(url=full_url, headers=headers, html_path=html_filepath,
                                        should_be=['__NEXT_DATA__'], max_retry=3)  # proxies=proxies, verify=False,
        # print(response_html.status_code)
        if not response_html:
            print(f"getting wrong response:{full_url}")
            return None
        elif 'Result Not Found' in response_html or 'This product is invalid.' in response_html or 'This page could not be found' in response:
            search_data.update_one(
                {'_id': id}, {'$set': {'Status': "Not found"}})
            print("Status Updated...")
        elif response_html:

            selector = Selector(text=response_html)
            json_text = selector.xpath('//script[@id="__NEXT_DATA__"]/text()').get()

            if json_text:
                try:

                    data = json.loads(json_text)
                    props = data.get('props', {})
                    pageProps = props.get('pageProps', {})
                    product_page = pageProps.get('product')
                    variants_list = product_page.get('variants', [])
                    if len(variants_list) > 1:
                        variants_path = variants_list[1]
                    elif variants_list:
                        variants_path = variants_list[0]
                    else:
                        variants_path = {}
                    stock = variants_path.get("inStockInNetwork")

                except Exception as e:
                    print("JSON parsing failed:", e)
            else:
                print("Script tag with id='__NEXT_DATA__' not found.")

            all_name = selector.xpath('//div[@class="css-adpojs"]')

            # price_parts = all_name.xpath('.//p[@class="css-1b3zlyj"]/text()').getall()
            # autoship_price = price_parts[-1].strip() if price_parts else '' # Gets '4.80'
            # autoship_offer = all_name.xpath('//p[@id="autoship-price-label"]/text()').get()
            buyone_offer = all_name.xpath('//p[@id="buy-once-price-label"]/text()').get()
            # buyone_price_raw = all_name.xpath('//p[@class="css-kc6v00"]/text()').getall()
            # buyone_price = buyone_price_raw[-1].strip() if buyone_price_raw else ''
            # auto_promo = all_name.xpath('//div[@class="css-1th32rm"]//span/text()').get()
            try:
                was_price = all_name.xpath('//p[@class="css-vpb5qa"]/text()').getall()
                was_price_raw = was_price[-1].strip() if was_price else ''
            except Exception as e:
                print(f"was_price is not avaialable:{e}")
            try:
                was_p = float(was_price_raw.replace('$', '').replace(',', '').strip())
            except (ValueError, TypeError, AttributeError):
                was_p = 0.0

        if response.status_code == 200:
            # main_data = response_main.json()
            data = response.json()

            page_source = data.get('pageProps', {})
            product = page_source.get('product', {})
            name = product.get('title')
            variants = page_source.get('product', {}).get('variants', [])
            brand_name = product.get('vendor')
            for variant in variants:
                sku1 = variant.get('sku')
                discount = variant.get('discount')
                if discount:
                    price = discount['discountPrice']
                    # was_price = variant.get('price')
                    offer_info = discount.get('description')
                else:
                    offer_info = ''
                    price = variant.get('price')
                try:
                    main_price = float(str(price).replace('$', '').replace(',', '').strip())
                except (ValueError, TypeError, AttributeError):
                    main_price = 0.0
                    # was_price = ''

                selected_options = variant.get('selectedOptions', [])
                pack_size = selected_options[0].get('value') if selected_options else ''
                images = product.get('images')
                image_string = "|".join(images)
                breads = page_source.get('breadcrumbs')
                product_id = product.get('id')
                # Set file name based on product ID
                html_filename = f"{product_id}_page.html"
                html_filepath = os.path.join(html_path, html_filename)

                # rrp = was_price_raw if was_price_raw else  autoship_price
                rrp_buy = was_price_raw if was_price_raw else price
                try:
                    rrp = float(str(rrp_buy).replace('$', '').replace(',', '').strip())
                except (ValueError, TypeError, AttributeError):
                    rrp = 0.0
                product_id_numeric = product_id.split('/')[-1]

                if breads and isinstance(breads, list):
                    breadcrumb_names = [bread.get('name') for bread in breads if
                                        bread.get('name')]
                    breadcrumbs_string = " > ".join(breadcrumb_names)
                else:
                    print('')

                second_item = {
                    "Name": name,
                    "Promo_Type": offer_info,
                    "Price": main_price,
                    "per_unit_price": '',
                    "WasPrice": was_p,
                    "Offer_info": buyone_offer,
                    "Pack_size": pack_size,
                    "Barcode": '',
                    "is_available": stock,
                    "Images": image_string,
                    "ProductURL": full_url,
                    "ParentCode": '',
                    "ProductCode": product_id_numeric,
                    "retailer_name": "petstock",
                    "Category_Hierarchy": breadcrumbs_string,
                    "Brand": brand_name,
                    "RRP": rrp,
                    "Status": "Done",
                }
                product_data.insert_one(second_item)
                print(f"✅ Inserted: {sku1}")

            search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})

    except Exception as e:
        print(f"Error processing document {doc.get('_id')}: {e}")
        search_data.update_one({"_id": doc['_id']}, {"$set": {"Status": "No_data"}})


if __name__ == "__main__":
    docs = list(search_data.find({"Status": "Pending"}))
    with ThreadPoolExecutor(max_workers=50) as executor:
        executor.map(process_document, docs)
