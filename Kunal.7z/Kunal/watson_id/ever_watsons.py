import json
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse
from config import *

def extract_size(size_string):
    try:
        size_string = size_string.strip()

        # 1️⃣ Look for patterns like "Size: 200ml" or "Pack Size: 2kg"
        pattern1 = r'(?:Size|Pack Size)[:\s]*([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb|packs?|pack|tablets?|capsules?)'
        match = re.search(pattern1, size_string, re.IGNORECASE)
        if match:
            size_value = match.group(1)
            size_unit = match.group(2)
            return f"{size_value} {size_unit}"

        # 2️⃣ Look for things like "200ml", "2kg", "90g", etc.
        pattern2 = r'([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb|packs?|pack|tablets?|capsules?)'
        match = re.search(pattern2, size_string, re.IGNORECASE)
        if match:
            size_value = match.group(1)
            size_unit = match.group(2)
            return f"{size_value} {size_unit}"

        # 3️⃣ Look for patterns like "90g×2" or "200ml x 3"
        pattern3 = r'([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb)\s*[×xX]\s*(\d+)'
        match = re.search(pattern3, size_string, re.IGNORECASE)
        if match:
            size = f"{match.group(1)} {match.group(2)}"
            quantity = match.group(3)
            return f"{size} x {quantity}"

        # 4️⃣ Look for just quantity (like "24本入り" or "2個")
        pattern4 = r'(\d+)\s*(個|本入り|袋|本)'
        match = re.search(pattern4, size_string, re.IGNORECASE)
        if match:
            quantity = f"{match.group(1)} {match.group(2)}"
            return quantity

        # If nothing matched
        return ""

    except Exception as e:
        print(f"Error extracting size: {e}")
        return ""
def process_document(doc):
    referer_url = doc['url']
    doc_id = doc['_id']

    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
        'cache-control': 'max-age=0',
        'if-none-match': 'W/"797-5auQiYZDk+Xhi9RyInGuAKNLyho-gzip"',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Google Chrome";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
        'cookie': 'ROUTE=.jsapps-7fc5f597b7-pqbz7; AKA_A2=A; bm_sz=E948F7E2D3A16FE49C1BF029695755C9~YAAQrSQ+F8ol+SmbAQAAvF+hZB4Xvz4IBhK0R6TEQy0vqcXk80hQac/+syLuEcmPwKirqAfn7XlXuMQjG4+vbw/wNLm0J5CsoFEWeboF8DtLTLq9RviZe0ZhQvMjKDapYwL4UewvAd1ouAN36migg2CF160Ux2ORvmZlmYPZiXjABYVLlGrM/OA4k/L7kyLldLD/GqxBVLaHa7nP0QdiwgnGPt6t1KDZcyHsf2rx8g10ZT2rkBD3uCf8sEza9cwFfAmpecaocT2BvEnWvfZ4XGFsdJufPXcxHxeO/ZpVo4YKyg7E/M2b1FQfmmUOw6+ZGqZ9VoH1UiTmUbcV6Y8cbXKDGpExOTR2y2BPwKQ+YCQCIQVHcE18/rSmS9hIyg3asnFJ4eAd4NakZq7dxd9Zj2k=~4274225~3228470; PIM-SESSION-ID=ZMnRw88H6PIWERD1; e2-language=en_ID; language=en_ID; langcode=en; ak_bmsc=869D3BAB0E06AF0432245854DA31DD74~000000000000000000000000000000~YAAQRQNiaAJLfCabAQAAbHihZB7I6FG3pRgkKo2gnbSphtp+0oXPeNJC3N6jE0imqkUQKbp8Dlx4+W1Zrbw0l7QD+r5bszjW9sCLdIfv/rr/wDiDuoTvYNoygPfsPgZhKLyE0mL799Gb0JPkuZCfBMaTa8YRO8S6SUtshKIBiG1CB3Sfz+YyPP+tSNPgKsJTko1BAt9mkg7wmwUgrFjAvVLlRTyGuIFzeFwuEChMtTs2ONNC+OToIjP2Oo1SEIqScnQSrNj505NnHYEq0p1euTixH6GjHIBheCdcfI3dtuyCIFbWXjLD+N3eHZQ7kTsqDEG62c9DRSi/YSV8ApkUE5bjOoz1+64IaerU+QAh9FqUErh0VdDnrUzRAIUe/rP4jMsMYTh3XcPMe5zmaTarSDBsCy9Z5/3FxJ9UD3eXzzb46OnmOkN+Em/jcEZdZh4zWDBxsb1a4TVqqvj9; bm_sv=616B335F5C058462C5CBCAA1D276BB99~YAAQRQNiaPtRfCabAQAAi8KhZB4/vI2TF7uMkpjeO/54PB5E8m8ZVx/dugSbKIxZBS97m52LyJzI/rIjk6aJ+yd8nbk+8crmQxvC8GP1y5N5N3FIeHE4lKMvvMCQe8RwZmsZ+HTdQOoHQ/jF2MKJhvcoGuXfB8KqjziGvzNW+YPOpP0gf2D8A7sDfcatI9RA9w8dB/9F4g33o0bG1ltGkD+WY5wnNyxCuM/r8+nGN+7e+KLUgekeU6i0S/OyjU2LLeVt~1; _abck=39E896A3699A6D24861B7582D54FDADB~0~YAAQrSQ+F4Uo+SmbAQAAVeOhZA//6d16i7J1o1BgBIv+ZON8CLcd2d1bxNzSubK1mf3rchTO5y4+CELgORmK6v+OSioXrqmFA6iJGNsa0d6Mp/iJTh1l3m7j8akxLbFJLlkb9u1t7tOchqWFgOJX5RCCPmUQIyf7m6nnai9KBJQVfPg4pzbQ2bedRvSQD1zEst960XFaEAL7dtgPd5LqKSNZnwtFRFPJx18RM+/ZaW/Lbt7LG+wMCbw0vej/Bh2s4XniK5CM0hiVHTcOQAv7BbdJ+Hveh446ape8hMyb4PYIEq9QO2ws5Bv6GQPLWdOsL1elyRHBGw6HFMfADWyRUSF6rIxairy2E/eTYXord2dqcfXOBCGrU3/rvzUqkNwUDk9zMXP3Uz35cATz6VmL5MMHb4eUL5yjSd1R6oc1vtMw7qlRHMI2EDkUaxVWTZZQXN+UzmPCBR6IR7SFn8kSmlKcT1jLD9xexq5XZfjoRtUSRWQcgjWbG2A8q7unolDWUthjir4rAeh01xeVlc1c+kfJHJzEi8PXGz5sBBPan0uxvLHhTtw3RQuy4bo7EyCsKzUCCMxZwXlN9SuGFf6UPWcqhmkrUbNX6MAs4cft6QcdSxbdKF7TXlkoxfY57yayYbXDFbE=~-1~-1~-1~AAQAAAAE%2f%2f%2f%2f%2f0kk0xMLUM8aGUcjdAAKI8Rp8bH274QZiaxbdxfSjLaPhgNrh2s3Nw9WmkuQNVQsV1489iAsR52gucXsozjRG+gTFHQMQR4OFtEz~-1',
    }
    parsed_url = urlparse(referer_url)

    product_slug = parsed_url.path.strip('/').split('/')[-1]
    # print("Product slug:", product_slug)
    html_filename = f"{product_slug}_page.html"
    html_filepath = os.path.join(html_path, html_filename)
    # main = 'https://www.bigpharmacy.com.my/product/ego-qv-cream-50g'

    # apikey = '21ed11ef5c872bc7727680a52233027db4578a0e'
    # params = {
    #     'url': f"{referer_url}",
    #     'apikey': apikey,
    #     'custom_headers': 'true',
    #     'js_render': 'true',
    #
    # }

    # address_main_response = obj_to.request('https://api.zenrows.com/v1/', params=params, headers=headers)
    # response = obj.to_requests(url='https://api.zenrows.com/v1/', headers=headers, params=params,
    #                            html_path=html_filepath,
    #                            should_be=['wtcmy-state','wtcsg-state'], max_retry=3)
    # proxy = "http://21ed11ef5c872bc7727680a52233027db4578a0e:@api.zenrows.com:8001"
    #
    # proxies = {"http": proxy, "https": proxy}
    # current_proxy = '2c6ea6e6d8c14216a62781b8f850cd5b'
    #
    # proxy_host = "api.zyte.com"
    # proxy_port = "8011"
    # proxy_auth = f"{current_proxy}:"
    #
    # proxies = {
    #     "http": "https://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port),
    #     "https": "http://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port)
    # }
    response = obj.to_requests(url=referer_url, headers=headers, html_path=html_filepath,
                               should_be=["wtcid-state"], max_retry=3,proxies=proxies1, verify=False)# proxies=proxies, verify=False,
    if not response:
        response = obj.to_requests(url=referer_url, headers=headers, html_path=html_filepath,
                                   should_be=['wtcmy-state'], max_retry=3,proxies=proxies1, verify=False)
    if not response:
        response = obj.to_requests(url = referer_url, headers=headers, html_path=html_filepath,
                                   should_be=['wtcid-state'], max_retry=3,proxies=proxies1, verify=False)
    if not response:
        print(f"getting wrong response:{referer_url}")
        return None
    elif 'Result Not Found' in response or 'This product is invalid.' in response or 'This page could not be found' in response:
        search_data.update_one(
            {'_id': id}, {'$set': {'Status': "Not found"}})
        print("Status Updated...")
    elif response:

        product_id = urlparse(referer_url).path.split('/')[-1].replace("BP_", "").strip()


        selector = Selector(text=response)



        json_text = selector.xpath('//script[@id="wtcid-state"]/text()').get()

        data = None
        if json_text:
            data = json.loads(json_text)
        try:
            stock_status = data['cx-state']['product']['details']['entities'][str(product_id)]['variants']['value']['baseOptions'][0]['options'][
                0][
                'stock']['stockLevelStatus']
        except Exception as e:
            stock_status = data['cx-state']['product']['details']['entities'][str(product_id)]['variants']['value']['baseOptions'][0][
                'options'][
                0][
                'stock']['stockLevelStatus']
            print(e)
        if stock_status == "inStock":
            stock = True
        else:
            stock = False

        product = selector.xpath('//div[@class="ProductSummaryGroup"]')
        name = product.xpath('//div[@class="product-name"]/text()').get()
        brand = product.xpath('//h2[@class="product-brand"]/a/text()').get()
        if brand:
            brand = brand.title()
        main_price = product.xpath('//span[@class="price"]/text()').get()

        if main_price:
            price_value = float(main_price)
            # price_value = int(main_price)

            price = int(price_value) if price_value.is_integer() else round(price_value, 2)
        else:
            price = None

        compare_price = product.xpath('//span[@class="retail-price"]/text()').get()

        if compare_price:
            try:

                cleaned_compare_price = compare_price.replace('Rp','').replace('RM', '').replace('S$', '').replace(',', '').strip()
                was_price_value = float(cleaned_compare_price)
                was_price = int(was_price_value) if was_price_value.is_integer() else round(was_price_value, 2)
            except Exception as e:
                print(e)
        else:
            was_price = None

        print(was_price)
        image_urls = product.xpath('//div[@class="ProductImages"]//img/@src').getall()
        main_offer = product.xpath('//span[@class="discount ng-star-inserted"]/text()').get() or ""
        offer = main_offer.strip()
        main_product_id = selector.xpath('//div[@class="info-container"]//div[@class="value"]/text()').get()
        joined_urls = '|'.join(image_urls)
        breadcrumbs = selector.xpath(
            '//span[@itemprop="itemListElement"]//span[contains(@itemprop, "name")]/text()').getall()
        breads = ' > '.join(item.strip() for item in breadcrumbs if item.strip())

        main_promo = selector.xpath('//div[@class="container-title"]/text()').get() or ""
        promo = main_promo.strip()
        if not was_price or price == was_price:
            rrp_price = price
            was_price = ''
        else:
            rrp_price = was_price
        pack_size = extract_size(name)

        Items = {"Name": name, "Promo_Type": promo, "Price": price, "per_unit_price": "",
                 "WasPrice": was_price,
                 "Offer_info": offer, "Pack_size": pack_size, "Barcode": "",
                 "Images": joined_urls,
                 "ProductURL": referer_url, "is_available": stock,
                 "Status": "Done", "ParentCode": "", "ProductCode": main_product_id,
                 "retailer_name": "Watson",
                 "Category_Hierarchy": breads, "Brand": brand, "RRP": rrp_price}
        try:
                product_data.insert_one(Items)
                print("product inserted")
                search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
        except Exception as e:
            print(e)

        print(Items)

if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=50) as executor:
        docs = list(search_data.find({"Status": "Pending"}))
        executor.map(process_document, docs)


