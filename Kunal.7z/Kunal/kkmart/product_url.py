import json
import requests
from concurrent.futures import ThreadPoolExecutor
from config import *
def slug_process(doc):
    main_slug = doc['Slug']
    url = "https://api.kkemart.my/graphql"
    page = 1

    while True:
        # Build the GraphQL query string dynamically with current page and slug
        query = f"""
        query {{
            category(slug: "{main_slug}") {{
                id
                name
                slug
                products_count
            }}
            products(
                first: 24
                page: {page}
                category_slugs: "{main_slug}"
                show_available: true
                where: {{ column: PRODUCT_TYPE, operator: NEQ, value: "voucher" }}
                featuredOrdering: {{ category_slugs: "{main_slug}", is_featured: true }}
            ) {{
                data {{
                    id
                    name
                    slug
                    barcode
                }}
                paginatorInfo {{
                    currentPage
                    hasMorePages
                }}
            }}
        }}
        """

        payload = json.dumps({"query": query})
        headers = {
            'Authorization': 'd12f37ed-1af5-413c-b2b3-8c4907395b3c',
            'Content-Type': 'application/json',
            'User-Agent': 'Mozilla/5.0',
        }
        resp = requests.post(url, headers=headers, data=payload)


        if resp.status_code != 200:
            print("❌ Request failed:", resp.status_code, resp.text)
            break

        resp_json = resp.json()
        prod_section = resp_json.get("data", {}).get("products", {})
        products = prod_section.get("data", [])
        has_more = prod_section.get("paginatorInfo", {}).get("hasMorePages", False)

        print(f"→ Got {len(products)} products; has_more={has_more}")

        if not products:
            break

        for p in products:
            product_slug = p.get("slug")
            barcode = p.get("barcode") or ""

            doc_ins = {
                "product_url": f"https://api.kkemart.my/products/{product_slug}?_details=1",
                "Barcode": barcode,
                "Slug": main_slug,
                "Status": "Pending"
            }
            try:
                main_url.insert_one(doc_ins)
                print("Inserted:", product_slug, barcode)
            except Exception as e:
                print("Insert failed:", e)

        if has_more:
            page += 1
        else:
            break

if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=20) as executor:
        docs = list(search_data.find({"Status": "Pending"}))
        executor.map(slug_process, docs)
