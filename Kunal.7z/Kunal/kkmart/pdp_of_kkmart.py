from concurrent.futures import ThreadPoolExecutor


from  config import *

def extract_size(size_string):
    try:
        # Updated regex pattern
        size_pattern = r'\b(?:Size|Pack Size):\s*(\d+(\.\d+)?)\s*(ml|mL|L|g|kg|oz|lb|m|cm|mm|packs?|tablets?|capsules?)?\b'

        # Search for size
        size_match = re.search(size_pattern, size_string, re.IGNORECASE)

        # Extract the size and unit
        if size_match:
            size_value = size_match.group(1)  # The number
            size_unit = size_match.group(3) if size_match.group(3) else ""  # The unit (if available)
            if not size_unit:
                return None

            print(f"Extracted Size: {size_value} {size_unit}".strip())
            Product_Size = f"{size_value} {size_unit}".strip()
        else:
            # print("No size found in first try...")

            # Regular expression pattern to match size and quantity like "90g×1本"
            size_quantity_pattern = r'(\d+(\.\d+)?(?:g|kg|ml|l|oz|lb))\s*×\s*(\d+個|袋|本)'
            size_quantity_match = re.search(size_quantity_pattern, size_string.lower())
            # Regex pattern to extract size details

            if size_quantity_match:
                # Extract size and quantity from the match
                size = size_quantity_match.group(1)
                quantity = size_quantity_match.group(3)
                # Combine size and quantity in the format "size (quantity)"
                Product_Size = f"{size}×{quantity}"

            else:
                # Regular expression pattern to match sizes only (e.g., 90g, 200ml)
                size_pattern = r'\b\d+(\.\d+)?\s*(ml|mL|l|g|kg|oz|lb|m|cm|mm|packs|pack|tablets|tablet|capsules)\b'
                size_match = re.search(size_pattern, size_string.lower())

                # Regular expression pattern to match quantities only (e.g., 24本入り)
                # quantity_pattern = r'\(\d+\s*本入り\)'
                quantity_pattern = r'\(\d+\s*本入り\)|(\d+\s*個)'
                quantity_match = re.search(quantity_pattern, size_string.lower())

                # Extract the size and quantity separately
                if size_match:
                    size = size_match.group()
                else:
                    size = ""

                if quantity_match:
                    quantity = quantity_match.group()
                else:
                    quantity = ""

                # Combine size and quantity if both are present
                if size and quantity:
                    Product_Size = f"{size} {quantity}"
                else:
                    Product_Size = size or quantity

                if not Product_Size:
                    # Regular expression pattern to match sizes only (e.g., 90g, 200ml)
                    size_pattern = r'\b(lozenges|packs|pack|tablets|tablet|capsules|m|cm|mm)?\s*\d+(\.\d+)?\b'
                    size_match = re.search(size_pattern, size_string.lower())

                    # Regular expression pattern to match quantities only (e.g., 24本入り)
                    # quantity_pattern = r'\(\d+\s*本入り\)'
                    quantity_pattern = r'\(\d+\s*本入り\)|(\d+\s*個)'
                    quantity_match = re.search(quantity_pattern, size_string.lower())

                    # Extract the size and quantity separately
                    if size_match:
                        size = size_match.group()
                    else:
                        size = ""

                    if quantity_match:
                        quantity = quantity_match.group()
                    else:
                        quantity = ""

                    # Combine size and quantity if both are present
                    if size and quantity:
                        Product_Size = f"{size} {quantity}"
                    else:
                        Product_Size = size or quantity


    except Exception as e:
        Product_Size = ""

    return Product_Size


def process_document(doc):
    refrel_url = doc['product_url']
    barcode = doc['Barcode']
    doc_id = doc['_id']


    payload = {}
    headers = {
        'accept': 'application/json',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
        'authorization': '7a4c500b-6988-4f01-aef5-dd2d7081694e',
        'origin': 'https://kkemart.my',
        'priority': 'u=1, i',
        'referer': 'https://kkemart.my/',
        'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="139", "Chromium";v="139"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',
        'x-platform': 'web',
        'x-session': 'gmMsmcqGU8XgXK0k546KFGmTgcdi1PKzlg5Gu21g',
        # 'cookie': '_ga=GA1.1.1352615474.1751450786; _fbp=fb.1.1751450786029.882888542592965820; _ga_3S43Z19BND=GS2.1.s1756268074$o2$g1$t1756268395$j39$l0$h0; kk_mart_session=wA6dY6qvWy3F5zWgcSpek52gsJ1LoanQlDlytdHL; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A197ab6ca410d83-0f1d15d4dda5e08-26011e51-144000-197ab6ca410d83%22%2C%22%24device_id%22%3A%20%22197ab6ca410d83-0f1d15d4dda5e08-26011e51-144000-197ab6ca410d83%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',

    }

    response = requests.get(refrel_url, headers=headers)

    if response.status_code == 200:
        data = response.json()
        product_id = data.get("id")
        product_name = data.get("name")
        stock = data.get("in_stock")
        if stock == 0:
            is_available = False
        else:
            is_available = True
        raw_was_price = data.get("price") or None
        try:
            was_price = float(data.get("price"))
        except Exception as e:
            was_price = None

        main_price = data.get("min_price")
        price = float(main_price)
        image = data.get("image").get("original")
        if not was_price or price == was_price:
            rrp_price = price
            was_price = ''
        else:
            rrp_price = was_price
        size_text = extract_size(product_name)
        if not size_text:
            size_text = ''

        Items = {"Name": product_name, "Promo_Type": "", "Price": price, "per_unit_price": "",
                 "WasPrice": was_price,
                 "Offer_info": "", "Pack_size": size_text, "Barcode": barcode,
                 "Images": image,
                 "ProductURL": refrel_url, "is_available": is_available,
                 "Status": "Done", "ParentCode": "", "ProductCode": product_id,
                 "retailer_name": "KK_mart",
                 "Category_Hierarchy": "", "Brand": "", "RRP": rrp_price}
        print(Items)
        try:
            product_data.insert_one(Items)
            print(f"Inserted ProductCode: {product_name}")
            main_url.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})

        except Exception as e:
            print(f"Insert failed for: {e}")
        print(Items)


if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=10) as executor:
        docs = list(main_url.find({"Status": "Pending"}))
        executor.map(process_document, docs)

