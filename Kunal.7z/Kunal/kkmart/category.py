from config import *

url = "https://api.kkemart.my/fetch-nav-category?search=&searchJoin=and&limit=30"

payload = {}
headers = {
  'Accept': 'application/json',
  'Accept-Encoding': 'gzip, deflate, br, zstd',
  'Accept-Language': 'en-US,en;q=0.9',
  'Authorization': 'd12f37ed-1af5-413c-b2b3-8c4907395b3c',
  'Connection': 'keep-alive',
  'Host': 'api.kkemart.my',
  'Origin': 'http://localhost',
  'Referer': 'http://localhost/',
  'sec-ch-ua': '"Android WebView";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
  'sec-ch-ua-mobile': '?1',
  'sec-ch-ua-platform': '"Android"',
  'Sec-Fetch-Dest': 'empty',
  'Sec-Fetch-Mode': 'cors',
  'Sec-Fetch-Site': 'cross-site',
  'User-Agent': 'Mozilla/5.0 (Linux; Android 9; A5010 Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/137.0.7151.115 Mobile Safari/537.36',
  'X-Platform': 'android',
  'X-Requested-With': 'my.kkmart.app',
  'x-session': 'u8AhaAStRL9AxIAKB48RTrAJntg9p8wdrGxqQQtx',
  'Cookie': 'kk_mart_session=u8AhaAStRL9AxIAKB48RTrAJntg9p8wdrGxqQQtx'
}

response = requests.request("GET", url, headers=headers, data=payload,)

print(response.text)
if response.status_code == 200:
    data = response.json()
    for item in data:
        slug = item.get('slug')
        main_slug = {
            "Slug": slug,
            "Status":"Pending"
        }
        if main_slug:
            search_data.insert_one(main_slug)
            print("Slug Inserted")
            print(slug)
