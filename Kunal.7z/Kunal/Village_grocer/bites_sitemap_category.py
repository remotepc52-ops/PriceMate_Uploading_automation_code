from lxml import etree
from config import  *

cookies = {
    '_shopify_y': 'C2BB0801-7f96-41D7-ba69-2d44391cadf4',
    '_tracking_consent': '3.AMPS_AUNSW_f_f_HHvwz3r7Ss2dxwCgQFIihA',
    '_orig_referrer': '',
    '_landing_page': '%2F',
    '_ga': 'GA1.1.895329153.1750240867',
    '_fbp': 'fb.2.1750240870929.190863712762028983',
    '_gcl_au': '1.1.1514359769.1750240868.1438142986.1750240970.1750240970',
    'localization': 'MY',
    'postcode': '43200',
    'show-postcode-popup': '0',
    'cart': 'Z2NwLWFzaWEtc291dGhlYXN0MTowMUpZMTg0REZBOTZHUzhGMFo1RE5TRVcyRg%3Fkey%3D22280bcd90cdc4b34ef7f57fdcb4adb3',
    'cart_sig': '16744c62265308f104363b92a268647c',
    '_shopify_s': 'F1B8443B-ec05-4AF9-a250-8d30c24314dc',
    'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A197827c358314f0-08863f81da24a28-26011e51-144000-197827c358314f0%22%2C%22%24device_id%22%3A%20%22197827c358314f0-08863f81da24a28-26011e51-144000-197827c358314f0%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
    '_ga_K6GBPYCR9Z': 'GS2.1.s1750240867$o1$g1$t1750241355$j56$l0$h0',
    '_ga_DZHT9Y5KVS': 'GS2.1.s1750240867$o1$g1$t1750241355$j56$l0$h0',
    'keep_alive': 'eyJ2IjoyLCJ0cyI6MTc1MDI0MTM2OTEyNywiZW52Ijp7IndkIjowLCJ1YSI6MSwiY3YiOjEsImJyIjoxfSwiYmh2Ijp7Im1hIjoyNCwiY2EiOjAsImthIjowLCJzYSI6MCwidGEiOjAsImtiYSI6MCwidCI6MTY1LCJubSI6MSwibXMiOjAuMTMsIm1qIjoxLjEsIm1zcCI6MC44MSwidmMiOjAsImNwIjowLCJyYyI6MCwia2oiOjAsImtpIjowLCJzcyI6MCwic2oiOjAsInNzbSI6MCwic3AiOjAsInRzIjowLCJ0aiI6MCwidHAiOjAsInRzbSI6MH0sInNlcyI6eyJwIjoyLCJzIjoxNzUwMjQwOTczOTMxLCJkIjozNzd9fQ%3D%3D',
}

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
    'cache-control': 'max-age=0',
    'if-none-match': '"cacheable:3b35161dbddee8d9f34028a9fa377de5"',
    'priority': 'u=0, i',
    'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    # 'cookie': '_shopify_y=C2BB0801-7f96-41D7-ba69-2d44391cadf4; _tracking_consent=3.AMPS_AUNSW_f_f_HHvwz3r7Ss2dxwCgQFIihA; _orig_referrer=; _landing_page=%2F; _ga=GA1.1.895329153.1750240867; _fbp=fb.2.1750240870929.190863712762028983; _gcl_au=1.1.1514359769.1750240868.1438142986.1750240970.1750240970; localization=MY; postcode=43200; show-postcode-popup=0; cart=Z2NwLWFzaWEtc291dGhlYXN0MTowMUpZMTg0REZBOTZHUzhGMFo1RE5TRVcyRg%3Fkey%3D22280bcd90cdc4b34ef7f57fdcb4adb3; cart_sig=16744c62265308f104363b92a268647c; _shopify_s=F1B8443B-ec05-4AF9-a250-8d30c24314dc; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A197827c358314f0-08863f81da24a28-26011e51-144000-197827c358314f0%22%2C%22%24device_id%22%3A%20%22197827c358314f0-08863f81da24a28-26011e51-144000-197827c358314f0%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; _ga_K6GBPYCR9Z=GS2.1.s1750240867$o1$g1$t1750241355$j56$l0$h0; _ga_DZHT9Y5KVS=GS2.1.s1750240867$o1$g1$t1750241355$j56$l0$h0; keep_alive=eyJ2IjoyLCJ0cyI6MTc1MDI0MTM2OTEyNywiZW52Ijp7IndkIjowLCJ1YSI6MSwiY3YiOjEsImJyIjoxfSwiYmh2Ijp7Im1hIjoyNCwiY2EiOjAsImthIjowLCJzYSI6MCwidGEiOjAsImtiYSI6MCwidCI6MTY1LCJubSI6MSwibXMiOjAuMTMsIm1qIjoxLjEsIm1zcCI6MC44MSwidmMiOjAsImNwIjowLCJyYyI6MCwia2oiOjAsImtpIjowLCJzcyI6MCwic2oiOjAsInNzbSI6MCwic3AiOjAsInRzIjowLCJ0aiI6MCwidHAiOjAsInRzbSI6MH0sInNlcyI6eyJwIjoyLCJzIjoxNzUwMjQwOTczOTMxLCJkIjozNzd9fQ%3D%3D',
}

params = {
    'from': '439173611804',
    'to': '497381474588',
}

sitemaps = [
'https://vec.bites.com.my/sitemap_collections_1.xml'
]

for sitemap_url in sitemaps:
    try:
        resp = requests.get(sitemap_url, headers=headers, cookies=cookies,params=params, proxies=proxies, verify=False)
        print(f"{sitemap_url} → {resp.status_code}")

        if resp.status_code != 200:
            print(f"Skipping: {sitemap_url} (status code {resp.status_code})")
            continue

        root = etree.fromstring(resp.content)
        namespaces = {'ns': 'http://www.sitemaps.org/schemas/sitemap/0.9'}
        loc_elements = root.xpath('//ns:loc', namespaces=namespaces)

        for loc in loc_elements:
            url = loc.text.strip()
            search_data.update_one(
                {"url": url},
                {"$set": {"url": url, "Status": "Pending"}},
                upsert=True
            )
            print(f"inserted: {url}")

    except Exception as e:
        print(f"Error processing sitemap {sitemap_url}: {e}")