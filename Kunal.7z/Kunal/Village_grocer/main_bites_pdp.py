from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse

from  config import *
def extract_size(size_string):
    try:
        size_string = size_string.strip()

        # 1️⃣ Look for patterns like "Size: 200ml" or "Pack Size: 2kg"
        pattern1 = r'(?:Size|Pack Size)[:\s]*([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb|packs?|pack|tablets?|capsules?)'
        match = re.search(pattern1, size_string, re.IGNORECASE)
        if match:
            size_value = match.group(1)
            size_unit = match.group(2)
            return f"{size_value} {size_unit}"

        # 2️⃣ Look for things like "200ml", "2kg", "90g", etc.
        pattern2 = r'([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb|packs?|pack|tablets?|capsules?)'
        match = re.search(pattern2, size_string, re.IGNORECASE)
        if match:
            size_value = match.group(1)
            size_unit = match.group(2)
            return f"{size_value} {size_unit}"

        # 3️⃣ Look for patterns like "90g×2" or "200ml x 3"
        pattern3 = r'([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb)\s*[×xX]\s*(\d+)'
        match = re.search(pattern3, size_string, re.IGNORECASE)
        if match:
            size = f"{match.group(1)} {match.group(2)}"
            quantity = match.group(3)
            return f"{size} x {quantity}"

        # 4️⃣ Look for just quantity (like "24本入り" or "2個")
        pattern4 = r'(\d+)\s*(個|本入り|袋|本)'
        match = re.search(pattern4, size_string, re.IGNORECASE)
        if match:
            quantity = f"{match.group(1)} {match.group(2)}"
            return quantity

        # If nothing matched
        return ""

    except Exception as e:
        print(f"Error extracting size: {e}")
        return ""
def process_document(doc):
    product_url = doc['ProductUrl']
    doc_id = doc['_id']
    cookies = {
        '_shopify_y': 'C2BB0801-7f96-41D7-ba69-2d44391cadf4',
        '_tracking_consent': '3.AMPS_AUNSW_f_f_HHvwz3r7Ss2dxwCgQFIihA',
        '_orig_referrer': '',
        '_landing_page': '%2F',
        '_ga': 'GA1.1.895329153.1750240867',
        '_fbp': 'fb.2.1750240870929.190863712762028983',
        '_gcl_au': '1.1.1514359769.1750240868.1438142986.1750240970.1750240970',
        'localization': 'MY',
        'postcode': '43200',
        'show-postcode-popup': '0',
        'cart': 'Z2NwLWFzaWEtc291dGhlYXN0MTowMUpZMTg0REZBOTZHUzhGMFo1RE5TRVcyRg%3Fkey%3D22280bcd90cdc4b34ef7f57fdcb4adb3',
        'cart_sig': '16744c62265308f104363b92a268647c',
        '_shopify_s': 'F1B8443B-ec05-4AF9-a250-8d30c24314dc',
        '_ga_DZHT9Y5KVS': 'GS2.1.s1750240867$o1$g1$t1750244283$j25$l0$h0',
        'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A197827c358314f0-08863f81da24a28-26011e51-144000-197827c358314f0%22%2C%22%24device_id%22%3A%20%22197827c358314f0-08863f81da24a28-26011e51-144000-197827c358314f0%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
        '_ga_K6GBPYCR9Z': 'GS2.1.s1750240867$o1$g1$t1750244284$j24$l0$h0',
        'keep_alive': 'eyJ2IjoyLCJ0cyI6MTc1MDI0NDMxMzIxMCwiZW52Ijp7IndkIjowLCJ1YSI6MSwiY3YiOjEsImJyIjoxfSwiYmh2Ijp7Im1hIjoxMSwiY2EiOjAsImthIjowLCJzYSI6MCwidGEiOjAsImtiYSI6MCwidCI6MzAsIm5tIjoxLCJtcyI6MC4zOCwibWoiOjAuNDIsIm1zcCI6MC4yMiwidmMiOjAsImNwIjowLCJyYyI6MCwia2oiOjAsImtpIjowLCJzcyI6MCwic2oiOjAsInNzbSI6MCwic3AiOjAsInRzIjowLCJ0aiI6MCwidHAiOjAsInRzbSI6MH0sInNlcyI6eyJwIjo3LCJzIjoxNzUwMjQwOTczOTMxLCJkIjozMjc3fX0%3D',
    }

    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
        'cache-control': 'max-age=0',
        'if-none-match': '"cacheable:22d82b09e03d6ae345d26ed2157a7ee9"',
        'priority': 'u=0, i',
        'referer': 'https://vec.bites.com.my/',
        'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-site',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
        # 'cookie': '_shopify_y=63fc3805-b5f9-4002-964f-6dd7f2a5615d; localization=MY; _fbp=fb.2.1759738029518.597191906336341440; _shopify_essential=:AZm4j1SMAAEAmWPmUn_frkRKZ4TYqaaHbtiDNSzphIKmLfZYGMCmyssvXKZIT8-B8S658yA9CcrzScsfG0isrCl0I_CUMU3-LrqXS6WqR8aYL1slQMmMc6tyQc9QPBfsvFEA-rpTbvJjWDygLslusW98KYjCY60FU0ieyL4U7RotaU1mQtmnVvY5XSqNgqIwlKnXJwfZSKIjWJdREDz43BF7kh7vuMuJUbLX6oF8HUM0D9vbiGxmVRfEt7l1V-zX1nRswpJVh9s1L8RgOgjsKimtBpcbHltFCw_ur1svpth8sd5it_1atj2E4Idi6oUFX2IBPPL674-3KoODefAmSN8EU-XqNls:; _shopify_analytics=:AZm4j1X3AAEA6Ud5B7TMW_lqjrbE96dPImYsDJfeVIYZJF_A8U851SLnfhu1qntjx8RFq4wmwi5fbSNIfjQCAj3VPAl5FocHAebQoLmdSL3USIfgsgXYnUropTBxWd9gW1F7FGI8-ZO9wAV4ofhyAfDGFxgToNifMT2ZaXUnTMo4vZM6VbLFDtolFyLeFK_k-WSQidOfWIM1:; _shopify_s=de843933-664d-457c-8902-6dc545c46d45; postcode=50000; show-postcode-popup=0; keep_alive=eyJ2IjoyLCJ0cyI6MTc2MjQ5ODU2MDM3MSwiZW52Ijp7IndkIjowLCJ1YSI6MSwiY3YiOjEsImJyIjoxfSwiYmh2Ijp7Im1hIjoyLCJjYSI6MCwia2EiOjAsInNhIjowLCJrYmEiOjAsInRhIjowLCJ0IjoyMSwibm0iOjAsIm1zIjowLCJtaiI6MCwibXNwIjowLCJ2YyI6MCwiY3AiOjAsInJjIjowLCJraiI6MCwia2kiOjAsInNzIjowLCJzaiI6MCwic3NtIjowLCJzcCI6MCwidHMiOjAsInRqIjowLCJ0cCI6MCwidHNtIjowfSwic2VzIjp7InAiOjEsInMiOjE3NjI0OTg1Mzg0MzMsImQiOjIwfX0%3D',
    }

    parsed_url = urlparse(product_url)

    # Get the last part of the path (slug)
    product_slug = parsed_url.path.strip('/').split('/')[-1]

    html_filename = f"{product_slug}_page.html"
    html_filepath = os.path.join(html_path, html_filename)

    response = obj.to_requests(url=product_url, headers=headers, html_path=html_filepath,
                               should_be=['product_title entry-title'], max_retry=3, proxies=proxies, verify=False)
    main_json = []
    if not response:
        print(f"getting wrong response:{product_url}")
        main_data_url.update_one(
            {'_id': doc_id}, {'$set': {'Status': "Not found"}})
        return None
    elif 'Result Not Found' in response or 'This product is invalid.' in response or 'This page could not be found' in response:
        search_data.update_one(
            {'_id': doc_id}, {'$set': {'Status': "Not found"}})
        print("Status Updated...")
    elif response:

        selector = Selector(text=response)
        name = selector.xpath('//h1[@class="product_title entry-title"]/text()').get()
        name = name.strip()
        raw_price = selector.xpath('//p[@class="price"]//ins/text()').get()
        if not raw_price:
            raw_price = selector.xpath('//p[@class="price"]/text()').get()
        price = raw_price.replace("RM", "").strip() if raw_price else None
        float_price = float(price)
        raw_was_price = selector.xpath('//p[@class="price"]//del/text()').get() or ""
        was_price = raw_was_price.replace("RM","").strip() if raw_price else None
        if was_price:
            was_price = float(was_price)
        else:
            was_price = None
        brand = selector.xpath('//span[@class="vendor value"]/a/text()').get()
        availlable = selector.xpath('//span[@class="available_wrapper"]//span[@class="js_in_stock "]/text()').get()
        if availlable == "In Stock":
            item_avail = True
        else:
            item_avail = False
        breadcrumbs = selector.xpath('//nav[@class="sp-breadcrumb"]/a/text()').getall()
        breadcrumb_str = ' > '.join([b.strip() for b in breadcrumbs if b.strip()])

        # print(breadcrumb_str)
        product_id = selector.xpath('//input[@name="product-id"]/@value').get()
        if not was_price or float_price == was_price:
            rrp_price = float_price
            was_price = ''
        else:
            rrp_price = was_price
        if rrp_price:
            rrp_price = float(rrp_price)
        image = selector.xpath('//meta[@name="twitter:image"]/@content').get()
        pack_size = extract_size(name)

        if float_price == 0:
            main_data_url.update_one({"_id": doc_id}, {'$set': {'Status': "Not found"}})
            print("Price Not Found...")
            return

        Items = {"Name": name, "Promo_Type": "", "Price": float_price, "per_unit_price": "",
                 "WasPrice": was_price,
                 "Offer_info": "", "Pack_size": pack_size, "Barcode": "",
                 "Images": image,
                 "ProductURL": product_url, "is_available": item_avail,
                 "Status": "Done", "ParentCode": "", "ProductCode": product_id,
                 "retailer_name": "villagegrocer",
                 "Category_Hierarchy": breadcrumb_str, "Brand": brand, "RRP": rrp_price}
        try:
            product_data.insert_one(Items)
            print(f"Product inserted :{product_id}")

            main_data_url.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
        except Exception as e:
            print(e)
if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=20) as executor:
        docs = list(main_data_url.find({"Status": "Pending"}))
        executor.map(process_document, docs)




