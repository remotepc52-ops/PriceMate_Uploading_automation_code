from concurrent.futures import ThreadPoolExecutor

from config import *

def main_process(doc):
    referer_url = doc['url']
    doc_id = doc['_id']
    page = 1

    cookies = {
        '_shopify_y': 'C2BB0801-7f96-41D7-ba69-2d44391cadf4',
        '_tracking_consent': '3.AMPS_AUNSW_f_f_HHvwz3r7Ss2dxwCgQFIihA',
        '_orig_referrer': '',
        '_landing_page': '%2F',
        '_ga': 'GA1.1.895329153.1750240867',
        '_fbp': 'fb.2.1750240870929.190863712762028983',
        '_gcl_au': '1.1.1514359769.1750240868.1438142986.1750240970.1750240970',
        'localization': 'MY',
        'postcode': '43200',
        'show-postcode-popup': '0',
        'cart': 'Z2NwLWFzaWEtc291dGhlYXN0MTowMUpZMTg0REZBOTZHUzhGMFo1RE5TRVcyRg%3Fkey%3D22280bcd90cdc4b34ef7f57fdcb4adb3',
        'cart_sig': '16744c62265308f104363b92a268647c',
        '_shopify_s': 'F1B8443B-ec05-4AF9-a250-8d30c24314dc',
        'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A197827c358314f0-08863f81da24a28-26011e51-144000-197827c358314f0%22%2C%22%24device_id%22%3A%20%22197827c358314f0-08863f81da24a28-26011e51-144000-197827c358314f0%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
        'keep_alive': 'eyJ2IjoyLCJ0cyI6MTc1MDI0MTgzMjAzNiwiZW52Ijp7IndkIjowLCJ1YSI6MSwiY3YiOjEsImJyIjoxfSwiYmh2Ijp7Im1hIjo0NCwiY2EiOjEsImthIjowLCJzYSI6OCwidGEiOjAsImtiYSI6MCwidCI6NTcyLCJubSI6MSwibXMiOjAuMTMsIm1qIjowLjM4LCJtc3AiOjAuMzgsInZjIjowLCJjcCI6MCwicmMiOjAsImtqIjowLCJraSI6MCwic3MiOjAuNTQsInNqIjowLjY4LCJzc20iOjAuODMsInNwIjoyLCJ0cyI6MCwidGoiOjAsInRwIjowLCJ0c20iOjB9LCJzZXMiOnsicCI6MiwicyI6MTc1MDI0MDk3MzkzMSwiZCI6ODM4fX0%3D',
        '_ga_DZHT9Y5KVS': 'GS2.1.s1750240867$o1$g1$t1750241838$j59$l0$h0',
        '_ga_K6GBPYCR9Z': 'GS2.1.s1750240867$o1$g1$t1750241839$j58$l0$h0',
    }

    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
        'cache-control': 'max-age=0',
        'priority': 'u=0, i',
        'referer': 'https://vec.bites.com.my/',
        'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
        # 'cookie': '_shopify_y=C2BB0801-7f96-41D7-ba69-2d44391cadf4; _tracking_consent=3.AMPS_AUNSW_f_f_HHvwz3r7Ss2dxwCgQFIihA; _orig_referrer=; _landing_page=%2F; _ga=GA1.1.895329153.1750240867; _fbp=fb.2.1750240870929.190863712762028983; _gcl_au=1.1.1514359769.1750240868.1438142986.1750240970.1750240970; localization=MY; postcode=43200; show-postcode-popup=0; cart=Z2NwLWFzaWEtc291dGhlYXN0MTowMUpZMTg0REZBOTZHUzhGMFo1RE5TRVcyRg%3Fkey%3D22280bcd90cdc4b34ef7f57fdcb4adb3; cart_sig=16744c62265308f104363b92a268647c; _shopify_s=F1B8443B-ec05-4AF9-a250-8d30c24314dc; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A197827c358314f0-08863f81da24a28-26011e51-144000-197827c358314f0%22%2C%22%24device_id%22%3A%20%22197827c358314f0-08863f81da24a28-26011e51-144000-197827c358314f0%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; keep_alive=eyJ2IjoyLCJ0cyI6MTc1MDI0MTgzMjAzNiwiZW52Ijp7IndkIjowLCJ1YSI6MSwiY3YiOjEsImJyIjoxfSwiYmh2Ijp7Im1hIjo0NCwiY2EiOjEsImthIjowLCJzYSI6OCwidGEiOjAsImtiYSI6MCwidCI6NTcyLCJubSI6MSwibXMiOjAuMTMsIm1qIjowLjM4LCJtc3AiOjAuMzgsInZjIjowLCJjcCI6MCwicmMiOjAsImtqIjowLCJraSI6MCwic3MiOjAuNTQsInNqIjowLjY4LCJzc20iOjAuODMsInNwIjoyLCJ0cyI6MCwidGoiOjAsInRwIjowLCJ0c20iOjB9LCJzZXMiOnsicCI6MiwicyI6MTc1MDI0MDk3MzkzMSwiZCI6ODM4fX0%3D; _ga_DZHT9Y5KVS=GS2.1.s1750240867$o1$g1$t1750241838$j59$l0$h0; _ga_K6GBPYCR9Z=GS2.1.s1750240867$o1$g1$t1750241839$j58$l0$h0',
    }

    while True:
        paged_url = f"{referer_url}?page={page}"

        # proxies = f"https://{proxy_auth}@{proxy_host}:{proxy_port}"

        response = requests.get(paged_url, cookies=cookies, headers=headers, proxies=proxies, verify=False)

        if response.status_code != 200:
            print(f"Failed to fetch page {page} of {referer_url}")
            break

        selector = Selector(response.text)
        urls = selector.xpath('//div[@class="product-info mt__15"]//a//@href').getall()

        if not urls:
            print(f"No more products found on page {page}. Stopping.")
            # search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Not Found"}})
            break

        for relative_url in urls:
            product_url = f"https://vec.bites.com.my{relative_url}"
            print(product_url)
            main_list = {
                "ProductUrl": product_url,
                "Status": "Pending"
            }
            try:
                main_data_url.update_one(
                    {"ProductUrl": product_url},
                    {"$setOnInsert": main_list},
                    upsert=True
                )
                search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
                print(f"Upserted: {product_url}")
            except Exception as e:
                print(f"Failed to upsert {product_url}: {e}")
                search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Not Found"}})


        print(f"Page {page} processed. {len(urls)} products found.")
        page += 1
if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=20) as executor:
        docs = list(search_data.find({"Status":"Pending"}))
        executor.map(main_process, docs)

