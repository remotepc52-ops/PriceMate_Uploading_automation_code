from concurrent.futures import ThreadPoolExecutor
from config import *


current_proxy = '2c6ea6e6d8c14216a62781b8f850cd5b'

proxy_host = "api.zyte.com"
proxy_port = "8011"
proxy_auth = f"{current_proxy}:"

proxies = {
    "http": "https://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port),
    "https": "http://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port)
}
def process_store(doc):
    store_url = doc["url"]
    source_id = doc['source_id']
    doc_id = doc["_id"]
    cookies = {
        'session-id': '358-5919384-7710302',
        'i18n-prefs': 'AUD',
        'lc-acbau': 'en_AU',
        'ubid-acbau': '358-4434860-4235313',
        'session-id-time': '2082787201l',
        'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A19840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24device_id%22%3A%20%2219840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
        'csm-hit': 'tb:R7XY6HHKNQQPKG4XGTYX+s-J0YZJTQ23VRS7NH61WKR|1763718062655&t:1763718062655&adb:adblk_no',
        'session-token': '"+u2S3oiIsosbwYNp/HtA/YL9wIY7qs/ysXBu77iVchOQV7rnEuBwahxbYcCpqgqhPIOjY08m6blcEtXGjolZHLoOhqNNx2lXmARHAqGNbmLa1M8TSzWyZSXnGzP3wPhLdDiZvrAxMgCY+JImtHiyM345VjItAuKV2Ixl+JbNhr2N7fqUmM3Au9xeBYg2Q50yNOK85orN61HpmzIfSNEkiD/DzujSTCtdanmE5wYMVGUPFZ/EHegrPV0uLmVq3y44bVEjMclbLJtlSY6yZ/4TDPhXHuGxuojVOTAvwJ5SHtU/LSdQWJIe72eceVn3VfEs6r1BcZ3qX/S8UfJfJSNjH+CeE52bidST1LUZ+L7lAyk="',
        'rxc': 'AKdQD/dJTUrJYCZx00s',
    }

    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
        'cache-control': 'max-age=0',
        'device-memory': '8',
        'downlink': '1.4',
        'dpr': '1.25',
        'ect': '3g',
        'priority': 'u=0, i',
        'referer': store_url,
        'rtt': '550',
        'sec-ch-device-memory': '8',
        'sec-ch-dpr': '1.25',
        'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-ch-ua-platform-version': '"19.0.0"',
        'sec-ch-viewport-width': '1536',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
        'viewport-width': '1536',
        # 'cookie': 'session-id=358-5919384-7710302; i18n-prefs=AUD; lc-acbau=en_AU; ubid-acbau=358-4434860-4235313; session-id-time=2082787201l; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A19840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24device_id%22%3A%20%2219840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; csm-hit=tb:R7XY6HHKNQQPKG4XGTYX+s-J0YZJTQ23VRS7NH61WKR|1763718062655&t:1763718062655&adb:adblk_no; session-token="+u2S3oiIsosbwYNp/HtA/YL9wIY7qs/ysXBu77iVchOQV7rnEuBwahxbYcCpqgqhPIOjY08m6blcEtXGjolZHLoOhqNNx2lXmARHAqGNbmLa1M8TSzWyZSXnGzP3wPhLdDiZvrAxMgCY+JImtHiyM345VjItAuKV2Ixl+JbNhr2N7fqUmM3Au9xeBYg2Q50yNOK85orN61HpmzIfSNEkiD/DzujSTCtdanmE5wYMVGUPFZ/EHegrPV0uLmVq3y44bVEjMclbLJtlSY6yZ/4TDPhXHuGxuojVOTAvwJ5SHtU/LSdQWJIe72eceVn3VfEs6r1BcZ3qX/S8UfJfJSNjH+CeE52bidST1LUZ+L7lAyk="; rxc=AKdQD/dJTUrJYCZx00s',
    }

    print(f"[STORE] Processing {store_url}")

    try:
        response = requests.get(store_url,cookies=cookies,proxies=proxies,verify='zyte-ca.crt', headers=headers)
    except Exception as e:
        print("[ERROR] Store fetch failed:", e)
        pending.update_one({"_id": doc_id}, {"$set": {"Status": "Pending"}})
        return

    if response.status_code != 200:
        print("[ERROR] Bad response", response.status_code)
        pending.update_one({"_id": doc_id}, {"$set": {"Status": "Pending"}})
        return

    selector = Selector(response.text)

    # Try all category selectors
    category_urls = selector.xpath(
        '//nav[contains(@aria-label, "Navigation Bar")]//li[@data-testid="nav-item"]/a/@href'
    ).getall()

    if not category_urls:
        category_urls = selector.xpath('//li[@class="Navigation__navItem__bakjf"]//a/@href').getall()

    if category_urls:
        print(f"[STORE] Found {len(category_urls)} categories")

        full_urls = [f"https://www.amazon.com.au{u}" for u in category_urls]


        for url in full_urls:
            cat_url.insert_one({
                "cat_url": url,
                "source_id": source_id,
                "STORE_URL": store_url,
                "Status": "Pending"
            })

        pending.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
        return

    # ---------------- No categories found → fallback ----------------
    print("[STORE] No categories found → store->product fallback")

    cat_url.insert_one({
        "cat_url": store_url,
        "source_id": source_id,
        "STORE_URL": store_url,
        "Status": "Pending",
        "fallback": True
    })
    if not category_urls:
        print("[STORE] No categories found — store has direct product URLs")

        # Extract products directly from store page
        extract_products_from_store(store_url, source_id, doc_id)

        # Mark store as fallback+done
        pending.update_one({"_id": doc_id},
                           {"$set": {"Status": "Pending"}})

        return

def extract_products_from_store(store_url,source_id, doc_id):
    print("[STORE-FALLBACK] Extracting products directly from:", store_url)
    cookies2 = {
        'session-id': '358-5919384-7710302',
        'i18n-prefs': 'AUD',
        'lc-acbau': 'en_AU',
        'ubid-acbau': '358-4434860-4235313',
        'session-id-time': '2082787201l',
        'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A19840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24device_id%22%3A%20%2219840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
        'csm-hit': 'tb:R7XY6HHKNQQPKG4XGTYX+s-J0YZJTQ23VRS7NH61WKR|1763718062655&t:1763718062655&adb:adblk_no',
        'session-token': '"+u2S3oiIsosbwYNp/HtA/YL9wIY7qs/ysXBu77iVchOQV7rnEuBwahxbYcCpqgqhPIOjY08m6blcEtXGjolZHLoOhqNNx2lXmARHAqGNbmLa1M8TSzWyZSXnGzP3wPhLdDiZvrAxMgCY+JImtHiyM345VjItAuKV2Ixl+JbNhr2N7fqUmM3Au9xeBYg2Q50yNOK85orN61HpmzIfSNEkiD/DzujSTCtdanmE5wYMVGUPFZ/EHegrPV0uLmVq3y44bVEjMclbLJtlSY6yZ/4TDPhXHuGxuojVOTAvwJ5SHtU/LSdQWJIe72eceVn3VfEs6r1BcZ3qX/S8UfJfJSNjH+CeE52bidST1LUZ+L7lAyk="',
        'rxc': 'AKdQD/dJTUrJYCZx00s',
    }

    headers2 = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
        'cache-control': 'max-age=0',
        'device-memory': '8',
        'downlink': '1.4',
        'dpr': '1.25',
        'ect': '3g',
        'priority': 'u=0, i',
        'referer': store_url,
        'rtt': '550',
        'sec-ch-device-memory': '8',
        'sec-ch-dpr': '1.25',
        'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-ch-ua-platform-version': '"19.0.0"',
        'sec-ch-viewport-width': '1536',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
        'viewport-width': '1536',
        # 'cookie': 'session-id=358-5919384-7710302; i18n-prefs=AUD; lc-acbau=en_AU; ubid-acbau=358-4434860-4235313; session-id-time=2082787201l; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A19840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24device_id%22%3A%20%2219840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; csm-hit=tb:R7XY6HHKNQQPKG4XGTYX+s-J0YZJTQ23VRS7NH61WKR|1763718062655&t:1763718062655&adb:adblk_no; session-token="+u2S3oiIsosbwYNp/HtA/YL9wIY7qs/ysXBu77iVchOQV7rnEuBwahxbYcCpqgqhPIOjY08m6blcEtXGjolZHLoOhqNNx2lXmARHAqGNbmLa1M8TSzWyZSXnGzP3wPhLdDiZvrAxMgCY+JImtHiyM345VjItAuKV2Ixl+JbNhr2N7fqUmM3Au9xeBYg2Q50yNOK85orN61HpmzIfSNEkiD/DzujSTCtdanmE5wYMVGUPFZ/EHegrPV0uLmVq3y44bVEjMclbLJtlSY6yZ/4TDPhXHuGxuojVOTAvwJ5SHtU/LSdQWJIe72eceVn3VfEs6r1BcZ3qX/S8UfJfJSNjH+CeE52bidST1LUZ+L7lAyk="; rxc=AKdQD/dJTUrJYCZx00s',
    }
    try:
        response = requests.get(store_url, headers=headers2,cookies=cookies2,proxies=proxies,verify='zyte-ca.crt')
    except Exception as e:
        print("[ERROR] Store fallback request failed:", e)
        return

    if response.status_code != 200:
        print("[ERROR] Bad store fallback response:", response.status_code)
        return

    selector = Selector(response.text)

    asin_list = []

    # 1) Extract ASIN via JSON script
    scripts = selector.xpath('//script[contains(text(),"ASIN")]/text()').getall()
    for s in scripts:
        matches = re.findall(r'"asin"\s*:\s*"([A-Z0-9]{10})"', s)
        asin_list.extend(matches)

    # 2) Extract ASIN via product grid HTML
    product_urls = selector.xpath('//a[contains(@href,"/dp/")]/@href').getall()

    for url in product_urls:
        m = re.search(r'/dp/([A-Z0-9]{10})', url)
        if m:
            asin_list.append(m.group(1))

    asin_list = list(set(asin_list))

    if not asin_list:
        print("[STORE-FALLBACK] No ASIN found on store page")
        pending.update_one({"_id": doc_id}, {"$set": {"Status": "No ASIN"}})
        return


    # Insert products
    for asin in asin_list:
        product_url = f"https://www.amazon.com.au/dp/{asin}"

        try:
            search_data.insert_one({
                "Product_url": product_url,
                "source_id": source_id,
                "cat_url": store_url,
                "Status": "Pending"
            })
            print("[STORE-FALLBACK] Inserted:", product_url)
        except Exception as e:
            print("[ERROR] Insert failed:", e)

    # pending.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
# ---------------------------------------------------------
# STEP 2: Process category URL → extract ASINs
# ---------------------------------------------------------
def process_category(doc):
    cat = doc["cat_url"]
    source_id = doc['source_id']
    doc_id = doc["_id"]

    print(f"[CATEGORY] Processing {cat}")

    next_url = cat
    cookies1 = {
        'session-id': '358-5919384-7710302',
        'i18n-prefs': 'AUD',
        'lc-acbau': 'en_AU',
        'ubid-acbau': '358-4434860-4235313',
        'session-id-time': '2082787201l',
        'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A19840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24device_id%22%3A%20%2219840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
        'csm-hit': 'tb:R7XY6HHKNQQPKG4XGTYX+s-J0YZJTQ23VRS7NH61WKR|1763718062655&t:1763718062655&adb:adblk_no',
        'session-token': '"+u2S3oiIsosbwYNp/HtA/YL9wIY7qs/ysXBu77iVchOQV7rnEuBwahxbYcCpqgqhPIOjY08m6blcEtXGjolZHLoOhqNNx2lXmARHAqGNbmLa1M8TSzWyZSXnGzP3wPhLdDiZvrAxMgCY+JImtHiyM345VjItAuKV2Ixl+JbNhr2N7fqUmM3Au9xeBYg2Q50yNOK85orN61HpmzIfSNEkiD/DzujSTCtdanmE5wYMVGUPFZ/EHegrPV0uLmVq3y44bVEjMclbLJtlSY6yZ/4TDPhXHuGxuojVOTAvwJ5SHtU/LSdQWJIe72eceVn3VfEs6r1BcZ3qX/S8UfJfJSNjH+CeE52bidST1LUZ+L7lAyk="',
        'rxc': 'AKdQD/dJTUrJYCZx00s',
    }

    headers1 = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
        'cache-control': 'max-age=0',
        'device-memory': '8',
        'downlink': '1.4',
        'dpr': '1.25',
        'ect': '3g',
        'priority': 'u=0, i',
        'referer': cat,
        'rtt': '550',
        'sec-ch-device-memory': '8',
        'sec-ch-dpr': '1.25',
        'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-ch-ua-platform-version': '"19.0.0"',
        'sec-ch-viewport-width': '1536',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
        'viewport-width': '1536',
        # 'cookie': 'session-id=358-5919384-7710302; i18n-prefs=AUD; lc-acbau=en_AU; ubid-acbau=358-4434860-4235313; session-id-time=2082787201l; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A19840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24device_id%22%3A%20%2219840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; csm-hit=tb:R7XY6HHKNQQPKG4XGTYX+s-J0YZJTQ23VRS7NH61WKR|1763718062655&t:1763718062655&adb:adblk_no; session-token="+u2S3oiIsosbwYNp/HtA/YL9wIY7qs/ysXBu77iVchOQV7rnEuBwahxbYcCpqgqhPIOjY08m6blcEtXGjolZHLoOhqNNx2lXmARHAqGNbmLa1M8TSzWyZSXnGzP3wPhLdDiZvrAxMgCY+JImtHiyM345VjItAuKV2Ixl+JbNhr2N7fqUmM3Au9xeBYg2Q50yNOK85orN61HpmzIfSNEkiD/DzujSTCtdanmE5wYMVGUPFZ/EHegrPV0uLmVq3y44bVEjMclbLJtlSY6yZ/4TDPhXHuGxuojVOTAvwJ5SHtU/LSdQWJIe72eceVn3VfEs6r1BcZ3qX/S8UfJfJSNjH+CeE52bidST1LUZ+L7lAyk="; rxc=AKdQD/dJTUrJYCZx00s',
    }
    while next_url:
        try:
            response = requests.get(next_url,proxies=proxies,verify='zyte-ca.crt',cookies=cookies1, headers=headers1)
        except:
            print("[ERROR] Category request failed")
            break

        if response.status_code != 200:
            print("[ERROR] Bad status", response.status_code)
            break

        selector = Selector(response.text)

        # Extract ASINs via multiple methods
        asin_list = []

        # 1) Try JSON-based ASIN extraction
        scripts = selector.xpath('//script[contains(text(), "ASINList")]/text()').getall()
        for s in scripts:
            found = re.findall(r'"ASINList":\s*\[(.*?)\\]', s)
            for f in found:
                asin_list.extend(re.findall(r'"([A-Z0-9]{10})"', f))

        # 2) Fallback ASIN extraction via HTML
        if not asin_list:
            urls = selector.xpath('//a[contains(@href,"/dp/")]/@href').getall()
            for u in urls:
                m = re.search(r"/dp/([A-Z0-9]{10})", u)
                if m:
                    asin_list.append(m.group(1))

        asin_list = list(set(asin_list))

        if not asin_list:
            print("[CATEGORY] No ASINs found.")
            cat_url.update_one({"_id": doc_id}, {"$set": {"Status": "No ASIN"}})
            return

        # Insert product URLs
        for asin in asin_list:
            full_url = f"https://www.amazon.com.au/dp/{asin}"
            try:
                search_data.insert_one({
                    "Product_url": full_url,
                    "source_id": source_id,
                    "cat_url": cat,
                    "Status": "Pending"
                })
                print("Inserted:", full_url)
            except Exception as e:
                print("Insert error:", e)

        # Pagination
        next_page = selector.xpath(
            '//a[contains(@class,"s-pagination-next")]/@href'
        ).get()

        if next_page:
            next_url = "https://www.amazon.com.au" + next_page
            print("[CATEGORY] Next:", next_url)
        else:
            next_url = None

    cat_url.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})


# ---------------------------------------------------------
# MAIN SCHEDULER LOOP
# ---------------------------------------------------------
def run_pipeline():
    print("\n===== RUN PIPELINE =====")

    # Step 1: process pending STORE URLs
    store_docs = list(pending.find({"Status": "Pending"}))
    if store_docs:
        print("[CATEGORY] Pending docs found.",len(store_docs))
        with ThreadPoolExecutor(max_workers=10) as ex:
            ex.map(process_store, store_docs)

    cat_docs = list(cat_url.find({"Status": "Pending"}))
    if cat_docs:
        print("[CATEGORY] Next:", len(cat_docs))
        with ThreadPoolExecutor(max_workers=10) as ex:
            ex.map(process_category, cat_docs)


if __name__ == "__main__":
    run_pipeline()
    print("✔ All tasks completed. Script finished.")  # <-- Scheduler interval
