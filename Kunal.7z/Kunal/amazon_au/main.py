import json
from concurrent.futures import ThreadPoolExecutor
from config import *
current_proxy = '2c6ea6e6d8c14216a62781b8f850cd5b'

proxy_host = "api.zyte.com"
proxy_port = "8011"
proxy_auth = f"{current_proxy}:"

proxies = {
    "http": "https://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port),
    "https": "http://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port)
}
def extract_size(size_string):
    try:
        size_string = size_string.strip()

        # 1️⃣ Look for patterns like "Size: 200ml" or "Pack Size: 2kg"
        pattern1 = r'(?:Size|Pack Size)[:\s]*([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb|packs?|pack|tablets?|capsules?)'
        match = re.search(pattern1, size_string, re.IGNORECASE)
        if match:
            size_value = match.group(1)
            size_unit = match.group(2)
            return f"{size_value} {size_unit}"

        # 2️⃣ Look for things like "200ml", "2kg", "90g", etc.
        pattern2 = r'([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb|packs?|pack|tablets?|capsules?)'
        match = re.search(pattern2, size_string, re.IGNORECASE)
        if match:
            size_value = match.group(1)
            size_unit = match.group(2)
            return f"{size_value} {size_unit}"

        # 3️⃣ Look for patterns like "90g×2" or "200ml x 3"
        pattern3 = r'([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb)\s*[×xX]\s*(\d+)'
        match = re.search(pattern3, size_string, re.IGNORECASE)
        if match:
            size = f"{match.group(1)} {match.group(2)}"
            quantity = match.group(3)
            return f"{size} x {quantity}"

        # 4️⃣ Look for just quantity (like "24本入り" or "2個")
        pattern4 = r'(\d+)\s*(個|本入り|袋|本)'
        match = re.search(pattern4, size_string, re.IGNORECASE)
        if match:
            quantity = f"{match.group(1)} {match.group(2)}"
            return quantity

        # If nothing matched
        return ""

    except Exception as e:
        print(f"Error extracting size: {e}")
        return ""

def process_document(doc):
    product_url = doc['Product_url']
    # main_price = doc['Price']
    asin = product_url.split("/dp/")[1].split("/")[0]
    doc_id = doc['_id']
    source_id = doc['source_id']
    html_filename = f"{asin}_page.html"
    html_filepath = os.path.join(html_path, html_filename)
    cookies = {
        'session-id': '358-5919384-7710302',
        'i18n-prefs': 'AUD',
        'lc-acbau': 'en_AU',
        'ubid-acbau': '358-4434860-4235313',
        'session-token': '"5Dv1cbq5XDeo4vfO+I7jubiL3VyMofz0qgDBpM6opIQfu+Oh1H1rFpOTSZnteyLpwpZ9GjcgxjRKfuvfk+a6lH6QoFi84Da2TtXwNgYHrxQd9GX7pzSZ9Ed9nWdgHUNsFqF0auw0EWe3rgzbhdyfKLSkvIs9TQmeY+uRdr3lZCFR5+7kkfi8GITtkeDxcw26ZftljLxDozztGF4zCoCvnDNrczo13pilihhKh2ZjilooIbQWk7t+rcQFNcGnErB5ycjdwVJMt8wQYKHvRBQB4f1GMAP77w29G1+DwYZ71LRoKTjqbbfj55NmCndXEVV3scDTqva6upXyYlq+FviMOqrQSNP6Cagt7f1EON/GCJQ="',
        'csm-hit': 'tb:s-EVK90P7KZ16CBVYYRZ3Y|1763721076081&t:1763721077485&adb:adblk_no',
        'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A19840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24device_id%22%3A%20%2219840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
        'session-id-time': '2082787201l',
        'rxc': 'AKdQD/d3QUrJYCZx00s',
    }

    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
        'cache-control': 'max-age=0',
        'device-memory': '8',
        'downlink': '1.4',
        'dpr': '1.25',
        'ect': '3g',
        'priority': 'u=0, i',
        'referer': 'https://www.amazon.com.au/stores/page/C6513743-DAD5-41DA-A49D-188AF53440A4',
        'rtt': '450',
        'sec-ch-device-memory': '8',
        'sec-ch-dpr': '1.25',
        'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-ch-ua-platform-version': '"19.0.0"',
        'sec-ch-viewport-width': '1536',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
        'viewport-width': '1536',
        'cookie': 'session-id=358-5919384-7710302; i18n-prefs=AUD; lc-acbau=en_AU; ubid-acbau=358-4434860-4235313; session-token="5Dv1cbq5XDeo4vfO+I7jubiL3VyMofz0qgDBpM6opIQfu+Oh1H1rFpOTSZnteyLpwpZ9GjcgxjRKfuvfk+a6lH6QoFi84Da2TtXwNgYHrxQd9GX7pzSZ9Ed9nWdgHUNsFqF0auw0EWe3rgzbhdyfKLSkvIs9TQmeY+uRdr3lZCFR5+7kkfi8GITtkeDxcw26ZftljLxDozztGF4zCoCvnDNrczo13pilihhKh2ZjilooIbQWk7t+rcQFNcGnErB5ycjdwVJMt8wQYKHvRBQB4f1GMAP77w29G1+DwYZ71LRoKTjqbbfj55NmCndXEVV3scDTqva6upXyYlq+FviMOqrQSNP6Cagt7f1EON/GCJQ="; csm-hit=tb:s-EVK90P7KZ16CBVYYRZ3Y|1763721076081&t:1763721077485&adb:adblk_no; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A19840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24device_id%22%3A%20%2219840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; session-id-time=2082787201l; rxc=AKdQD/d3QUrJYCZx00s',
    }

    params = {
        'ref_': 'ast_sto_dp',
    }

    response = obj.to_requests(url=product_url, headers=headers,params=params, html_path=html_filepath,
                               should_be=["productTitle"], max_retry=3,proxies=proxies,verify='zyte-ca.crt'
                               )
    if not response:
        print(f"getting wrong response:{product_url}")
        search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Not Found"}})

        return None
    elif 'Result Not Found' in response or 'This product is invalid.' in response or 'This page could not be found' in response:
        search_data.update_one(
            {'_id': id}, {'$set': {'Status': "Not found"}})
        print("Status Updated...")
    elif response:

        selector = Selector(text=response)
        name = selector.xpath('//h1[@id="title"]/span//text()').get()
        if name:
            name = name.strip()
            print(name)
        stock = selector.xpath('//div[@id="availability"]/span//span/text()').get()
        if not stock:
            stock = selector.xpath('//div[@id="availability"]/span/text()').get()

        if stock:
            stock = stock.strip()
        else:
            stock = ""
        cleaned_price= []

        main_price = selector.xpath('//input[@id="twister-plus-price-data-price"]/@value').get()
        if not main_price:
            main_price = selector.xpath('//input[@name="items[0.base][customerVisiblePrice][amount]"]/@value').get()
        if not main_price:
            main_price = selector.xpath('//div[@data-price]/@data-price').get()

        if main_price:
            main_price = main_price.strip()

            cleaned_price = main_price.replace(",", "")  # only remove comma for float conversion
            main_price = float(cleaned_price)

        if ("Currently unavailable" in stock) or ("Temporarily out of stock" in stock):
            stock = False
        else:
            stock = True

        scripts = selector.xpath("//script[@type='text/javascript']/text()").getall()
        data_json_text = None
        for script in scripts:
            if 'var data =' in script:
                pattern = re.compile(r"var data\s*=\s*({.*?});\s*A\.trigger", re.DOTALL)
                match = pattern.search(script)
                if match:
                    data_json_text = match.group(1)
                    break

        final_string = ""
        if data_json_text:
            data_json_text = re.sub(r'Date\.now\(\)', '0', data_json_text)
            data_json_text = re.sub(r"'", '"', data_json_text)
            data_json_text = re.sub(r",(\s*[}\]])", r'\1', data_json_text)
            try:
                data = json.loads(data_json_text)
                images = data.get('colorImages', {}).get('initial', [])
                hi_res_urls = [img.get('hiRes') for img in images if img.get('hiRes')]
                final_string = '|'.join(hi_res_urls)
                print(final_string)
            except json.JSONDecodeError as e:
                print(f"JSON parsing error: {e}")
        else:
            print("❌ Could not find var data block")
        product_id = selector.xpath('//input[@id="ASIN"]/@value').get()
        if not product_id:
            product_id = asin
        print(product_id)
        breadcrumbs = selector.xpath(
            '//ul[contains(@class, "a-unordered-list") and contains(@class, "a-horizontal")]/li//a/text()').getall()

        breadcrumbs_clean = [crumb.strip() for crumb in breadcrumbs if crumb.strip() and 'Flash Player' not in crumb]
        breadcrumbs_joined = ' > '.join(breadcrumbs_clean)
        # was_price_text = selector.xpath('//span[contains(@class, "basisPrice")]//span[@class="a-offscreen"]//text').get() or ""
        was_price_text = selector.xpath(
            '//span[contains(@class, "basisPrice")]//span[@class="a-offscreen"]/text()').get()

        was_price = None
        if was_price_text:
            match = re.search(r"[\d,.]+", was_price_text)
            if match:
                raw = match.group()  # keep commas
                value = float(raw.replace(",", ""))  # float conversion
                was_price = value
        if not was_price or main_price == was_price:
            rrp_price = main_price
            was_price = ''
        else:
            rrp_price = was_price
        pack_size = extract_size(name)
        if pack_size:
            pack_size = pack_size
        else:
            pack_size = ''

        per_unitprice = selector.xpath('//span[@class="aok-relative"]//span[contains(@class, "a-size-mini aok-offscreen")]/text()').get() or ""
        brand = selector.xpath('//tr[@class="a-spacing-small po-brand"]//span[@class="a-size-base po-break-word"]//text()').get()
        offer = selector.xpath('//span[contains(@class, "savingPriceOverride") and contains(@class, "savingsPercentage")]//text()').get()

        if pack_size == ". G":
            pack_size = ""
        else:
            pack_size = pack_size
        Items = {"source_id": source_id,"Name": name, "Promo_Type": "", "Price": main_price, "per_unit_price": per_unitprice,
                 "WasPrice": was_price,
                 "Offer_info": offer, "Pack_size": pack_size, "Barcode": "",
                 "Images": final_string,
                 "ProductURL": product_url, "is_available": stock,
                 "Status": "Done", "ParentCode": "", "ProductCode": product_id,
                 "retailer_name": "amazon-au",
                 "Category_Hierarchy": breadcrumbs_joined, "Brand": brand, "RRP": rrp_price}
        print(Items)
        if main_price:
            try:
                product_data.insert_one(Items)
                print("Product Inserted")
                search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
            except Exception as e:
                print("Insert error:", e)
                search_data.update_one({"_id": doc_id}, {"$set": {"Status": f"Insert error: {str(e)}"}})
        else:
            print("Skipping insert: Missing Price or item data")
            search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Item Not Found"}})

            # search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Item Not Found"}})

if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=50) as executor:
        docs = list(search_data.find({"Status": "Pending"}))
        executor.map(process_document, docs)