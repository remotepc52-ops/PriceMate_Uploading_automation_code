from concurrent.futures import ThreadPoolExecutor


from config import *
cookies = {
    'session-id': '358-5919384-7710302',
    'i18n-prefs': 'AUD',
    'lc-acbau': 'en_AU',
    'ubid-acbau': '358-4434860-4235313',
    'session-id-time': '2082787201l',
    'rxc': 'AKi2CaROvY8K/nCQsEk',
    'session-token': 'geSJfXBIVk9aIpB8jM31MyfTd7bh1Xj0/fu1l0cJrgA8nxWCntSJnRzxYQFXF3lgDW8mvtUM+RxvuExDjU/bvD78bE8shPvAaBF8cOnY/zibnFGo2oDkny7LtAjKH97LAtuRQ+3sQQO/84VDKg7lrr2PnCz9fMpcYmJurNJSJ3Mr5n/YL22esaXHwgkv1p436fkYCv5/7fsNyurL7lZ1/AMq2OynZWmXCqJvTF6crk9BNZ8Z8Aloasux0Dq/vunkL57v/OiHKWk+LltjAQOduO/fjuVNUYQLuzxaetG7wZzR8QUj53CPMQUvPV4S2Q/GpOsjVJc/VXv2cY4nKBja3mMDn8fSGLkl',
    'csm-hit': 'tb:s-DXE25HZPNSK7R5B4FMJ0|1765265964718&t:1765265965176&adb:adblk_no',
    'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A19840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24device_id%22%3A%20%2219840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
}

headers = {
    'accept': 'text/html,*/*',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
    'device-memory': '8',
    'downlink': '10',
    'dpr': '1.25',
    'ect': '4g',
    'priority': 'u=1, i',
    # 'referer': 'https://www.amazon.com.au/stores/page/8923D3CF-FADF-4881-B402-E0E2E768E866/',
    'rtt': '50',
    'sec-ch-device-memory': '8',
    'sec-ch-dpr': '1.25',
    'sec-ch-ua': '"Google Chrome";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-ch-ua-platform-version': '"19.0.0"',
    'sec-ch-viewport-width': '1536',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
    'viewport-width': '1536',
    'x-amz-amabot-click-attributes': 'disable',
    'x-requested-with': 'XMLHttpRequest',
    # 'cookie': 'session-id=358-5919384-7710302; i18n-prefs=AUD; lc-acbau=en_AU; ubid-acbau=358-4434860-4235313; session-id-time=2082787201l; rxc=AKi2CaROvY8K/nCQsEk; session-token=geSJfXBIVk9aIpB8jM31MyfTd7bh1Xj0/fu1l0cJrgA8nxWCntSJnRzxYQFXF3lgDW8mvtUM+RxvuExDjU/bvD78bE8shPvAaBF8cOnY/zibnFGo2oDkny7LtAjKH97LAtuRQ+3sQQO/84VDKg7lrr2PnCz9fMpcYmJurNJSJ3Mr5n/YL22esaXHwgkv1p436fkYCv5/7fsNyurL7lZ1/AMq2OynZWmXCqJvTF6crk9BNZ8Z8Aloasux0Dq/vunkL57v/OiHKWk+LltjAQOduO/fjuVNUYQLuzxaetG7wZzR8QUj53CPMQUvPV4S2Q/GpOsjVJc/VXv2cY4nKBja3mMDn8fSGLkl; csm-hit=tb:s-DXE25HZPNSK7R5B4FMJ0|1765265964718&t:1765265965176&adb:adblk_no; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A19840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24device_id%22%3A%20%2219840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
}
def cat_process(doc):

    cat_url = doc['cat_url']
    source_id = doc['source_id']
    doc_id = doc['_id']

    m = re.search(r'/stores/page/([A-Z0-9\-]+)/?', cat_url, re.I)
    page_id = m.group(1) if m else None
    cookies2 = {
        'session-id': '358-5919384-7710302',
        'i18n-prefs': 'AUD',
        'lc-acbau': 'en_AU',
        'ubid-acbau': '358-4434860-4235313',
        'session-id-time': '2082787201l',
        'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A19840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24device_id%22%3A%20%2219840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
        'csm-hit': 'tb:R7XY6HHKNQQPKG4XGTYX+s-J0YZJTQ23VRS7NH61WKR|1763718062655&t:1763718062655&adb:adblk_no',
        'session-token': '"+u2S3oiIsosbwYNp/HtA/YL9wIY7qs/ysXBu77iVchOQV7rnEuBwahxbYcCpqgqhPIOjY08m6blcEtXGjolZHLoOhqNNx2lXmARHAqGNbmLa1M8TSzWyZSXnGzP3wPhLdDiZvrAxMgCY+JImtHiyM345VjItAuKV2Ixl+JbNhr2N7fqUmM3Au9xeBYg2Q50yNOK85orN61HpmzIfSNEkiD/DzujSTCtdanmE5wYMVGUPFZ/EHegrPV0uLmVq3y44bVEjMclbLJtlSY6yZ/4TDPhXHuGxuojVOTAvwJ5SHtU/LSdQWJIe72eceVn3VfEs6r1BcZ3qX/S8UfJfJSNjH+CeE52bidST1LUZ+L7lAyk="',
        'rxc': 'AKdQD/dJTUrJYCZx00s',
    }

    headers2 = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
        'cache-control': 'max-age=0',
        'device-memory': '8',
        'downlink': '1.4',
        'dpr': '1.25',
        'ect': '3g',
        'priority': 'u=0, i',
        'referer': cat_url,
        'rtt': '550',
        'sec-ch-device-memory': '8',
        'sec-ch-dpr': '1.25',
        'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-ch-ua-platform-version': '"19.0.0"',
        'sec-ch-viewport-width': '1536',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
        'viewport-width': '1536',
        # 'cookie': 'session-id=358-5919384-7710302; i18n-prefs=AUD; lc-acbau=en_AU; ubid-acbau=358-4434860-4235313; session-id-time=2082787201l; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A19840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24device_id%22%3A%20%2219840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; csm-hit=tb:R7XY6HHKNQQPKG4XGTYX+s-J0YZJTQ23VRS7NH61WKR|1763718062655&t:1763718062655&adb:adblk_no; session-token="+u2S3oiIsosbwYNp/HtA/YL9wIY7qs/ysXBu77iVchOQV7rnEuBwahxbYcCpqgqhPIOjY08m6blcEtXGjolZHLoOhqNNx2lXmARHAqGNbmLa1M8TSzWyZSXnGzP3wPhLdDiZvrAxMgCY+JImtHiyM345VjItAuKV2Ixl+JbNhr2N7fqUmM3Au9xeBYg2Q50yNOK85orN61HpmzIfSNEkiD/DzujSTCtdanmE5wYMVGUPFZ/EHegrPV0uLmVq3y44bVEjMclbLJtlSY6yZ/4TDPhXHuGxuojVOTAvwJ5SHtU/LSdQWJIe72eceVn3VfEs6r1BcZ3qX/S8UfJfJSNjH+CeE52bidST1LUZ+L7lAyk="; rxc=AKdQD/dJTUrJYCZx00s',
    }
    response_store = requests.get(cat_url, headers=headers2, cookies=cookies2, proxies=proxies, verify='zyte-ca.crt')
    if response_store.status_code == 200:
        main_selector = Selector(response_store.text)
        response_id = main_selector.xpath("//div[contains(@class, 'stores-widget-btf')]/@id").getall()

        valid_response = None
        valid_main_id = None

        # --------------------------------------
        # 1) FIND FIRST main_id THAT RETURNS 200
        # --------------------------------------
        for main_ids in response_id:

            params = {
                'slashargs': '/',
                'pageId': f'{page_id}'
            }

            response = requests.get(
                f'https://www.amazon.com.au/stores/slot/{main_ids}',
                params=params,
                proxies=proxies,
                verify='zyte-ca.crt',
                cookies=cookies,
                headers=headers
            )

            if response.status_code == 200:
                print(f"[FOUND] Valid store slot: {main_ids}")
                valid_response = response
                valid_main_id = main_ids
                break  # <<< STOP HERE (do NOT check other IDs)

            else:
                print(f"[TRY NEXT] store slot {main_ids} returned {response.status_code}")

        # ----------------------------------------------------
        # 2) IF NO VALID RESPONSE FOUND → Nothing to process
        # ----------------------------------------------------
        if not valid_response:
            print("[FAIL] No store slot returned 200")
            pending.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
            return

        # ----------------------------------------------------
        # 3) PROCESS the FIRST valid (200) store slot
        # ----------------------------------------------------
        selector = Selector(valid_response.text)
        asin_list = []

        # JSON ASINs
        scripts = selector.xpath('//script[contains(text(),"ASIN")]/text()').getall()
        for s in scripts:
            matches = re.findall(r'"asin"\s*:\s*"([A-Z0-9]{10})"', s)
            asin_list.extend(matches)

        # HTML ASINs
        product_urls = selector.xpath('//a[contains(@href,"/dp/")]/@href').getall()
        for url in product_urls:
            m = re.search(r'/dp/([A-Z0-9]{10})', url)
            if m:
                asin_list.append(m.group(1))

        asin_list = list(set(asin_list))

        if not asin_list:
            print("[STORE] No ASIN found")

        # Insert into DB
        for asin in asin_list:
            product_url = f"https://www.amazon.com.au/dp/{asin}"
            try:
                search_data.insert_one({
                    "Product_url": product_url,
                    "cat_url": cat_url,
                    "source_id": source_id,
                    "Status": "Pending"
                })
                print("[STORE] Inserted:", product_url)
            except Exception as e:
                print("[ERROR] Insert failed:", e)

        pending.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
def main_process(doc):

    store_url = doc['url']
    source_id = doc['source_id']
    doc_id = doc['_id']

    m = re.search(r'/stores/page/([A-Z0-9\-]+)/?', store_url, re.I)
    page_id = m.group(1) if m else None
    cookies2 = {
        'session-id': '358-5919384-7710302',
        'i18n-prefs': 'AUD',
        'lc-acbau': 'en_AU',
        'ubid-acbau': '358-4434860-4235313',
        'session-id-time': '2082787201l',
        'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A19840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24device_id%22%3A%20%2219840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
        'csm-hit': 'tb:R7XY6HHKNQQPKG4XGTYX+s-J0YZJTQ23VRS7NH61WKR|1763718062655&t:1763718062655&adb:adblk_no',
        'session-token': '"+u2S3oiIsosbwYNp/HtA/YL9wIY7qs/ysXBu77iVchOQV7rnEuBwahxbYcCpqgqhPIOjY08m6blcEtXGjolZHLoOhqNNx2lXmARHAqGNbmLa1M8TSzWyZSXnGzP3wPhLdDiZvrAxMgCY+JImtHiyM345VjItAuKV2Ixl+JbNhr2N7fqUmM3Au9xeBYg2Q50yNOK85orN61HpmzIfSNEkiD/DzujSTCtdanmE5wYMVGUPFZ/EHegrPV0uLmVq3y44bVEjMclbLJtlSY6yZ/4TDPhXHuGxuojVOTAvwJ5SHtU/LSdQWJIe72eceVn3VfEs6r1BcZ3qX/S8UfJfJSNjH+CeE52bidST1LUZ+L7lAyk="',
        'rxc': 'AKdQD/dJTUrJYCZx00s',
    }

    headers2 = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
        'cache-control': 'max-age=0',
        'device-memory': '8',
        'downlink': '1.4',
        'dpr': '1.25',
        'ect': '3g',
        'priority': 'u=0, i',
        'referer': store_url,
        'rtt': '550',
        'sec-ch-device-memory': '8',
        'sec-ch-dpr': '1.25',
        'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-ch-ua-platform-version': '"19.0.0"',
        'sec-ch-viewport-width': '1536',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
        'viewport-width': '1536',
        # 'cookie': 'session-id=358-5919384-7710302; i18n-prefs=AUD; lc-acbau=en_AU; ubid-acbau=358-4434860-4235313; session-id-time=2082787201l; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A19840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24device_id%22%3A%20%2219840f4ea1c374-08e35b33c63c348-26011151-144000-19840f4ea1c374%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; csm-hit=tb:R7XY6HHKNQQPKG4XGTYX+s-J0YZJTQ23VRS7NH61WKR|1763718062655&t:1763718062655&adb:adblk_no; session-token="+u2S3oiIsosbwYNp/HtA/YL9wIY7qs/ysXBu77iVchOQV7rnEuBwahxbYcCpqgqhPIOjY08m6blcEtXGjolZHLoOhqNNx2lXmARHAqGNbmLa1M8TSzWyZSXnGzP3wPhLdDiZvrAxMgCY+JImtHiyM345VjItAuKV2Ixl+JbNhr2N7fqUmM3Au9xeBYg2Q50yNOK85orN61HpmzIfSNEkiD/DzujSTCtdanmE5wYMVGUPFZ/EHegrPV0uLmVq3y44bVEjMclbLJtlSY6yZ/4TDPhXHuGxuojVOTAvwJ5SHtU/LSdQWJIe72eceVn3VfEs6r1BcZ3qX/S8UfJfJSNjH+CeE52bidST1LUZ+L7lAyk="; rxc=AKdQD/dJTUrJYCZx00s',
    }
    response_store = requests.get(store_url, headers=headers2, cookies=cookies2, proxies=proxies, verify='zyte-ca.crt')
    if response_store.status_code == 200:
        main_selector = Selector(response_store.text)
        response_id = main_selector.xpath("//div[contains(@class, 'stores-widget-btf')]/@id").getall()

        valid_response = None
        valid_main_id = None

        # --------------------------------------
        # 1) FIND FIRST main_id THAT RETURNS 200
        # --------------------------------------
        for main_ids in response_id:

            params = {
                'slashargs': '/',
                'pageId': f'{page_id}'
            }

            response = requests.get(
                f'https://www.amazon.com.au/stores/slot/{main_ids}',
                params=params,
                proxies=proxies,
                verify='zyte-ca.crt',
                cookies=cookies,
                headers=headers
            )

            if response.status_code == 200:
                print(f"[FOUND] Valid store slot: {main_ids}")
                valid_response = response
                valid_main_id = main_ids
                break  # <<< STOP HERE (do NOT check other IDs)

            else:
                print(f"[TRY NEXT] store slot {main_ids} returned {response.status_code}")

        # ----------------------------------------------------
        # 2) IF NO VALID RESPONSE FOUND → Nothing to process
        # ----------------------------------------------------
        if not valid_response:
            print("[FAIL] No store slot returned 200")
            pending.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
            return

        # ----------------------------------------------------
        # 3) PROCESS the FIRST valid (200) store slot
        # ----------------------------------------------------
        selector = Selector(valid_response.text)
        asin_list = []

        # JSON ASINs
        scripts = selector.xpath('//script[contains(text(),"ASIN")]/text()').getall()
        for s in scripts:
            matches = re.findall(r'"asin"\s*:\s*"([A-Z0-9]{10})"', s)
            asin_list.extend(matches)

        # HTML ASINs
        product_urls = selector.xpath('//a[contains(@href,"/dp/")]/@href').getall()
        for url in product_urls:
            m = re.search(r'/dp/([A-Z0-9]{10})', url)
            if m:
                asin_list.append(m.group(1))

        asin_list = list(set(asin_list))

        if not asin_list:
            print("[STORE] No ASIN found")

        # Insert into DB
        for asin in asin_list:
            product_url = f"https://www.amazon.com.au/dp/{asin}"
            try:
                search_data.insert_one({
                    "Product_url": product_url,
                    "cat_url": store_url,
                    "source_id": source_id,
                    "Status": "Pending"
                })
                print("[STORE] Inserted:", product_url)
            except Exception as e:
                print("[ERROR] Insert failed:", e)

        pending.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})

def run_pipeline():
    print("\n===== RUN PIPELINE =====")

    # Step 1: process pending STORE URLs
    store_docs = list(pending.find({"Status": "Pending"}))
    if store_docs:
        with ThreadPoolExecutor(max_workers=10) as ex:
            ex.map(main_process, store_docs)

    cat_docs = list(cat_url.find({"Status": "No ASIN"}))
    if cat_docs:
        with ThreadPoolExecutor(max_workers=10) as ex:
            ex.map(cat_process, cat_docs)

if __name__ == "__main__":
    run_pipeline()
    print("✔ All tasks completed. Script finished.")