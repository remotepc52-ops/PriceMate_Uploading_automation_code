import random
from concurrent.futures import ThreadPoolExecutor
from config import *
from parsel import Selector
import re
def extract_size(size_string):
    try:
        size_string = size_string.strip()

        # 1️⃣ Look for patterns like "Size: 200ml" or "Pack Size: 2kg"
        pattern1 = r'(?:Size|Pack Size)[:\s]*([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb|packs?|pack|tablets?|capsules?)'
        match = re.search(pattern1, size_string, re.IGNORECASE)
        if match:
            size_value = match.group(1)
            size_unit = match.group(2)
            return f"{size_value} {size_unit}"

        # 2️⃣ Look for things like "200ml", "2kg", "90g", etc.
        pattern2 = r'([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb|packs?|pack|tablets?|capsules?)'
        match = re.search(pattern2, size_string, re.IGNORECASE)
        if match:
            size_value = match.group(1)
            size_unit = match.group(2)
            return f"{size_value} {size_unit}"

        # 3️⃣ Look for patterns like "90g×2" or "200ml x 3"
        pattern3 = r'([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb)\s*[×xX]\s*(\d+)'
        match = re.search(pattern3, size_string, re.IGNORECASE)
        if match:
            size = f"{match.group(1)} {match.group(2)}"
            quantity = match.group(3)
            return f"{size} x {quantity}"

        # 4️⃣ Look for just quantity (like "24本入り" or "2個")
        pattern4 = r'(\d+)\s*(個|本入り|袋|本)'
        match = re.search(pattern4, size_string, re.IGNORECASE)
        if match:
            quantity = f"{match.group(1)} {match.group(2)}"
            return quantity

        # If nothing matched
        return ""

    except Exception as e:
        print(f"Error extracting size: {e}")
        return ""
def process_document(doc):
    referer_url = doc['product_url']
    doc_id = doc['_id']
    product_slug = generate_hash_id(referer_url)
    html_filename = f"{product_slug}_page.html"
    html_filepath = os.path.join(html_path, html_filename)
    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,/;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-US,en;q=0.9,hi;q=0.8',
        'referer': referer_url,
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',
        'cookie': '_fbp=fb.2.1764688101500.94971518067636590; PEAKHOUR_VISIT=695e820c9e8456b400007939a13199d0; OCSESSID=40dcf7fed3274a4f7264f1fb42; language=en-gb; currency=AUD',
    }
    current_proxy = '2c6ea6e6d8c14216a62781b8f850cd5b'

    proxy_host = "api.zyte.com"
    proxy_port = "8011"
    proxy_auth = f"{current_proxy}:"

    proxies1 = {
        "http": "https://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port),
        "https": "http://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port)
    }

    response = obj.to_requests(url=referer_url, headers=headers, html_path=html_filepath,
                               should_be=["product-name"], max_retry=3,proxies=proxies1
                               ,verify=False)
    if not response:
        print(f"getting wrong response:{referer_url}")
        search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})

        return None
    elif 'Result Not Found' in response or 'This product is invalid.' in response or 'This page could not be found' in response:
        search_data.update_one(
            {'_id': id}, {'$set': {'Status': "Not found"}})
        print("Status Updated...")
    elif response:


        selector = Selector(text=response)
        name = selector.xpath('//h1[@class="product-name"]//text()').get()
        categories = selector.xpath('//td[text()="Categories: "]/following-sibling::td[@class="product-info-value"]//a/text()').getall()

        categories = [c.strip() for c in categories if c.strip()]
        category_path = " > ".join(categories)
        product_id  = selector.xpath('//td[normalize-space(text())="Product Code:"]/following-sibling::td[@class="product-info-value"]/text()').get()
        available = selector.xpath('//td[normalize-space(text())="Availability:"]/following-sibling::td[@class="product-info-value"]/text()').get()
        brand = selector.xpath('//td[normalize-space(text())="Brand:"]/following-sibling::td[@class="product-info-value"]/a//text()').get()

        if "In Stock" in available:
            available = True
        else:
            available = False
        price = selector.xpath('//span[@class="price"]/span[@class="price-new"]//text()').get()
        if not price:
            price = selector.xpath('//li[@class="price"]/span[@id="price-display"]//text()').get()
        main_price = float(price.replace("$","").strip())
        was_price = selector.xpath('//span[@class="price"]/span[@class="price-old"]//text()').get()
        if was_price:
            was_price = was_price.replace("$", "")
            new_was_price = was_price.strip()
            main_was_price = float(new_was_price)
        else:
            main_was_price = None
        if not main_was_price or main_price == main_was_price:
            rrp_price = main_price
            main_was_price = ''
        else:
            rrp_price = main_was_price
        pack_size = extract_size(name)
        offer = selector.xpath('string(//span[@class="badge badge-block badge-save"])').get()
        offer = " ".join(offer.split()) if offer else ""
        image = selector.xpath('//div[@class="product-image"]/a/@href').get()

        Items = {"Name": name, "Promo_Type": "", "Price": main_price, "per_unit_price": "",
                 "WasPrice": main_was_price,
                 "Offer_info": offer, "Pack_size": pack_size, "Barcode": "",
                 "Images": image,
                 "ProductURL": referer_url, "is_available": available,
                 "Status": "Done", "ParentCode": "", "ProductCode": product_id,
                 "retailer_name": "Chempro",
                 "Category_Hierarchy": category_path, "Brand": brand, "RRP": rrp_price}
        try:
            product_data.insert_one(Items)
            print("product inserted")
            search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
        except Exception as e:
            print(e)
            search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Not Found"}})




if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=5) as executor:
        docs = list(search_data.find({"Status": "Pending"}))
        executor.map(process_document, docs)

