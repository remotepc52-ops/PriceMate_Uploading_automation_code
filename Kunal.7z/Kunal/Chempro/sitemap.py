from rsa.cli import verify

from config import *
import xml.etree.ElementTree as ET

cookies = {
    'PEAKHOUR_VISIT': '68ec8f709e8456b400002b7aa335cae3',
    '__rp_ch': '68ec8f719e8456b400002b7aa335caf6:EH6tLBIPLKQiKW4gTMp6_Izt683pnzVHAC0nwFhMRqreDemXqla1xafHIh3miJttfbRdqr2UKdmshFXw0A',
    'language': 'en-gb',
    'currency': 'AUD',
    'OCSESSID': '2a2dce21dd405ee6e8565d2319',
    '_fbp': 'fb.2.1760333685370.519159343291817008',
    'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A199dc1052d8b44-0af1d197c5375d-26061851-144000-199dc1052d8b44%22%2C%22%24device_id%22%3A%20%22199dc1052d8b44-0af1d197c5375d-26061851-144000-199dc1052d8b44%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
}

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
    'cache-control': 'max-age=0',
    'downlink': '1.45',
    'dpr': '1.25',
    'ect': '3g',
    'priority': 'u=0, i',
    'rtt': '500',
    'sec-ch-ua': '"Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',
    'viewport-width': '1536',
    # 'cookie': 'PEAKHOUR_VISIT=68ec8f709e8456b400002b7aa335cae3; __rp_ch=68ec8f719e8456b400002b7aa335caf6:EH6tLBIPLKQiKW4gTMp6_Izt683pnzVHAC0nwFhMRqreDemXqla1xafHIh3miJttfbRdqr2UKdmshFXw0A; language=en-gb; currency=AUD; OCSESSID=2a2dce21dd405ee6e8565d2319; _fbp=fb.2.1760333685370.519159343291817008; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A199dc1052d8b44-0af1d197c5375d-26061851-144000-199dc1052d8b44%22%2C%22%24device_id%22%3A%20%22199dc1052d8b44-0af1d197c5375d-26061851-144000-199dc1052d8b44%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
}

sitemap_urls = [
    "https://www.chempro.com.au/sitemap-product-1.xml",
    "https://www.chempro.com.au/sitemap-product-2.xml"
]
product_urls = []

for sitemap_url in sitemap_urls:
    print(f"Fetching {sitemap_url} ...")
    response = requests.get(sitemap_url, headers=headers, cookies=cookies, proxies=proxies, verify=False)
    response.raise_for_status()

    root = ET.fromstring(response.content)
    for url_tag in root.findall("{http://www.sitemaps.org/schemas/sitemap/0.9}url"):
        loc = url_tag.find("{http://www.sitemaps.org/schemas/sitemap/0.9}loc")
        if loc is not None and loc.text:
            product_url = loc.text.strip()
            product_urls.append(product_url)


print(f"Inserting {len(product_urls)} product URLs into MongoDB...")

for url in product_urls:
    if not search_data.find_one({"product_url": url}):
        record = {"product_url": url, "Status": "Pending"}
        search_data.insert_one(record)

print("✅ All product URLs inserted successfully!")