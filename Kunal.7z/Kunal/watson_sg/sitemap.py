import requests
from lxml import etree
from rsa.cli import verify

from config import *

cookies = {
    'gaUserId': '841c9511-559c-4e18-bf4d-6281db83fe7f',
    '_gcl_au': '1.1.223475166.1749446789',
    'FPID': 'FPID2.3.l6LHFbWHktBb1Kp4bj%2FtBFFkMNLAD9YBF%2FVBbJ9qYEE%3D.1749446789',
    '_atrk_siteuid': 'Kc4f39qwOyO2Ax6L',
    '_tt_enable_cookie': '1',
    '_ttp': '01JX9JF2S9CWDHES38GS2FHZGJ_.tt.2',
    '_fbp': 'fb.3.1749446789865.1386455679',
    'superuser': '7afe20df-1468-4764-8577-96bf2520119a',
    'page_refreshed': 'true',
    'OptanonAlertBoxClosed': '2025-06-09T05:27:22.811Z',
    'dot_v_2416': 'YWFiZDBhYjI5YzAwY2ZhZjYyM2IzYjRiMDhhOGU2YjRjNWFhZWIwMmM3YzE1NDExYjA4ODE2YTM0NjRlODBmZjo6clNCcVRLdjZzSWxqZXZUa2tObkY5RlJoTHdlUUtQbUJrenV3TmVLTEJPYz0=',
    '_ga_MK3DWTMMGQ': 'deleted',
    'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A19753277cae922-06cda604015d05-26011e51-144000-19753277caf922%22%2C%22%24device_id%22%3A%20%2219753277cae922-06cda604015d05-26011e51-144000-19753277caf922%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
    '_ga': 'GA1.3.641459402.1749446789',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Jun+24+2025+17%3A20%3A15+GMT%2B0530+(India+Standard+Time)&version=202411.2.0&browserGpcFlag=0&isIABGlobal=false&hosts=&consentId=c9811122-4cda-4dd5-abc7-0e848a6e1cd0&interactionCount=2&isAnonUser=1&landingPath=NotLandingPage&groups=C0001%3A1%2CC0003%3A1%2CC0009%3A1&intType=3&geolocation=SG%3B&AwaitingReconsent=false',
    'ttcsid': '1750765816566::WcjkvxATjZkzwwGAMqL6.12.1750765816566',
    'supersession': '3644920',
    'ttcsid_CFIA2EBC77U1MMAF3CM0': '1750765816565::EdQ4K2sCoNsc-Ey4l-fp.12.1750765816808',
    '_ga_MK3DWTMMGQ': 'GS2.1.s1750765815$o12$g1$t1750765837$j38$l0$h351782369',
    'ROUTE': '.jsapps-57db5b68fc-b6v8b',
    'AKA_A2': 'A',
    '_abck': 'CDC5FCECAF2814E95712D3880C7B8707~0~YAAQjPzTF4qgpbCXAQAAb8Jfyg4Rr0OPrJBUVNltFOdcakPmoMC/SYEcIDM/V8LoEhLitolqcJicwin946D93C7BomTLBXGOmUER5+l8jMnqLdaNeYj0lN6PDtP4D0HCWuyRg7owAWhppXqzr8Co9JhZPJr9CWVy7wNLQq5KQi0iiu/eAFMnIMSxh3aZvUqb0HADf3pK7fZmjYZZJHGiIHlveydjQGzE+R4IvcfYhyNT7qv4uIXcur2vYIy1CxO52rj7ZGLs/Hh4Jtb0KETXbIzdGhJCzIY7MHZWDgr85oXetuOhazvL7VKBFtTB4GGGE4N5Q+S4Qu5C+SeIhzIjZEoBlVz6m0I6Jm+HjBEMhAppUH7IyHb+wadz679uibCnmlFTUKaARerzSsUkb36MCwLZSr1WFOdhX/MX33FQk6pO8nWR+U1emP0tJw4VtKr7mvj3QMpw6nfvQ4pnZF7WN/SsaZ+dLiCLOTvrAtlSNfjpic+QwDecHyR+ylDj1BRamHgKYGhvpMgYIhzETmL8YR7sxxn9/oco3x78treeMMs67JGCpMPamnwda4iAIEkg7yVC+ovKqmXQXF53mzIlyXZvkyVRESAKuvt2ePlSk5LJKYaB4sdhmivosTk/0G+Krg8=~-1~-1~-1',
    'bm_sz': '22C9190DE95E91056056D674CF4CD163~YAAQjPzTF4ugpbCXAQAAb8JfyhwSo50x2ygTPsj+tzUm/5psIFW+jev9mPoT59otSK248+NN04gGwFBY38wz7xRqMBwQ/aaWGPB6IEI6s60EIrZbdgFvZ9C7E+tDuAcbEDFSTnQqKe2MgBh+2/fKcfgL8eOHowQfHUv4hbM9SzCOpFqE3Xtm/fuJ7P6y9lcubL+XV0K09eEi5WlrhT5DASe1amU2HxLMUeU/SI03TWdLWXXohRFHe2pUhMyljZAXT6QCaUw6GTKxp7SwL9jz58C1FEtXpU3ouPHFhf+JghQPhS3sGJepY6xbNp4KC0/ji0k/T3NyV3Q14tsLxby/OR3KqG+9pC0jd56IDxfcVITOzB9BMVL3okgUniYVtZ7g8EtppggKaK9m0azvvIH6reOCtA==~3159095~3163206',
}

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
    'cache-control': 'max-age=0',
    # 'if-none-match': '"08552a1ebcdc36538be3e658c4ad865a8-gzip"',
    'priority': 'u=0, i',
    'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    # 'cookie': 'gaUserId=841c9511-559c-4e18-bf4d-6281db83fe7f; _gcl_au=1.1.223475166.1749446789; FPID=FPID2.3.l6LHFbWHktBb1Kp4bj%2FtBFFkMNLAD9YBF%2FVBbJ9qYEE%3D.1749446789; _atrk_siteuid=Kc4f39qwOyO2Ax6L; _tt_enable_cookie=1; _ttp=01JX9JF2S9CWDHES38GS2FHZGJ_.tt.2; _fbp=fb.3.1749446789865.1386455679; superuser=7afe20df-1468-4764-8577-96bf2520119a; page_refreshed=true; OptanonAlertBoxClosed=2025-06-09T05:27:22.811Z; dot_v_2416=YWFiZDBhYjI5YzAwY2ZhZjYyM2IzYjRiMDhhOGU2YjRjNWFhZWIwMmM3YzE1NDExYjA4ODE2YTM0NjRlODBmZjo6clNCcVRLdjZzSWxqZXZUa2tObkY5RlJoTHdlUUtQbUJrenV3TmVLTEJPYz0=; _ga_MK3DWTMMGQ=deleted; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A19753277cae922-06cda604015d05-26011e51-144000-19753277caf922%22%2C%22%24device_id%22%3A%20%2219753277cae922-06cda604015d05-26011e51-144000-19753277caf922%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; _ga=GA1.3.641459402.1749446789; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Jun+24+2025+17%3A20%3A15+GMT%2B0530+(India+Standard+Time)&version=202411.2.0&browserGpcFlag=0&isIABGlobal=false&hosts=&consentId=c9811122-4cda-4dd5-abc7-0e848a6e1cd0&interactionCount=2&isAnonUser=1&landingPath=NotLandingPage&groups=C0001%3A1%2CC0003%3A1%2CC0009%3A1&intType=3&geolocation=SG%3B&AwaitingReconsent=false; ttcsid=1750765816566::WcjkvxATjZkzwwGAMqL6.12.1750765816566; supersession=3644920; ttcsid_CFIA2EBC77U1MMAF3CM0=1750765816565::EdQ4K2sCoNsc-Ey4l-fp.12.1750765816808; _ga_MK3DWTMMGQ=GS2.1.s1750765815$o12$g1$t1750765837$j38$l0$h351782369; ROUTE=.jsapps-57db5b68fc-b6v8b; AKA_A2=A; _abck=CDC5FCECAF2814E95712D3880C7B8707~0~YAAQjPzTF4qgpbCXAQAAb8Jfyg4Rr0OPrJBUVNltFOdcakPmoMC/SYEcIDM/V8LoEhLitolqcJicwin946D93C7BomTLBXGOmUER5+l8jMnqLdaNeYj0lN6PDtP4D0HCWuyRg7owAWhppXqzr8Co9JhZPJr9CWVy7wNLQq5KQi0iiu/eAFMnIMSxh3aZvUqb0HADf3pK7fZmjYZZJHGiIHlveydjQGzE+R4IvcfYhyNT7qv4uIXcur2vYIy1CxO52rj7ZGLs/Hh4Jtb0KETXbIzdGhJCzIY7MHZWDgr85oXetuOhazvL7VKBFtTB4GGGE4N5Q+S4Qu5C+SeIhzIjZEoBlVz6m0I6Jm+HjBEMhAppUH7IyHb+wadz679uibCnmlFTUKaARerzSsUkb36MCwLZSr1WFOdhX/MX33FQk6pO8nWR+U1emP0tJw4VtKr7mvj3QMpw6nfvQ4pnZF7WN/SsaZ+dLiCLOTvrAtlSNfjpic+QwDecHyR+ylDj1BRamHgKYGhvpMgYIhzETmL8YR7sxxn9/oco3x78treeMMs67JGCpMPamnwda4iAIEkg7yVC+ovKqmXQXF53mzIlyXZvkyVRESAKuvt2ePlSk5LJKYaB4sdhmivosTk/0G+Krg8=~-1~-1~-1; bm_sz=22C9190DE95E91056056D674CF4CD163~YAAQjPzTF4ugpbCXAQAAb8JfyhwSo50x2ygTPsj+tzUm/5psIFW+jev9mPoT59otSK248+NN04gGwFBY38wz7xRqMBwQ/aaWGPB6IEI6s60EIrZbdgFvZ9C7E+tDuAcbEDFSTnQqKe2MgBh+2/fKcfgL8eOHowQfHUv4hbM9SzCOpFqE3Xtm/fuJ7P6y9lcubL+XV0K09eEi5WlrhT5DASe1amU2HxLMUeU/SI03TWdLWXXohRFHe2pUhMyljZAXT6QCaUw6GTKxp7SwL9jz58C1FEtXpU3ouPHFhf+JghQPhS3sGJepY6xbNp4KC0/ji0k/T3NyV3Q14tsLxby/OR3KqG+9pC0jd56IDxfcVITOzB9BMVL3okgUniYVtZ7g8EtppggKaK9m0azvvIH6reOCtA==~3159095~3163206',
}
region = "sg"

sitemaps = [
        # 'https://www.watsons.com.my/sitemap_prd_en_01.xml'
        f'https://www.watsons.com.sg/sitemap_prd_en_01.xml'
    ]
namespaces = {'ns': 'http://www.sitemaps.org/schemas/sitemap/0.9'}

for sitemap_url in sitemaps:
    response = requests.get(sitemap_url, cookies=cookies, headers=headers,proxies=proxies,verify=False)
    print(f"Fetching {sitemap_url} → {response.status_code}")

    if response.status_code == 200:
        root = etree.fromstring(response.content)

        loc_elements = root.xpath('//ns:loc', namespaces=namespaces)

        for loc in loc_elements:
            url = loc.text.strip()
            search_data.update_one(
                {"url": url},
                {"$set": {"url": url, "Status": "Pending"}},
                upsert=True
            )
            print(f"Inserted: {url}")
    else:
        print(f"Failed to fetch sitemap {sitemap_url}. Status code: {response.status_code}")