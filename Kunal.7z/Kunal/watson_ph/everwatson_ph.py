import json
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse

from config import *
def extract_size(size_string):
    try:
        size_string = size_string.strip()

        # 1️⃣ Look for patterns like "Size: 200ml" or "Pack Size: 2kg"
        pattern1 = r'(?:Size|Pack Size)[:\s]*([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb|packs?|pack|tablets?|capsules?)'
        match = re.search(pattern1, size_string, re.IGNORECASE)
        if match:
            size_value = match.group(1)
            size_unit = match.group(2)
            return f"{size_value} {size_unit}"

        # 2️⃣ Look for things like "200ml", "2kg", "90g", etc.
        pattern2 = r'([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb|packs?|pack|tablets?|capsules?)'
        match = re.search(pattern2, size_string, re.IGNORECASE)
        if match:
            size_value = match.group(1)
            size_unit = match.group(2)
            return f"{size_value} {size_unit}"

        # 3️⃣ Look for patterns like "90g×2" or "200ml x 3"
        pattern3 = r'([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb)\s*[×xX]\s*(\d+)'
        match = re.search(pattern3, size_string, re.IGNORECASE)
        if match:
            size = f"{match.group(1)} {match.group(2)}"
            quantity = match.group(3)
            return f"{size} x {quantity}"

        # 4️⃣ Look for just quantity (like "24本入り" or "2個")
        pattern4 = r'(\d+)\s*(個|本入り|袋|本)'
        match = re.search(pattern4, size_string, re.IGNORECASE)
        if match:
            quantity = f"{match.group(1)} {match.group(2)}"
            return quantity

        # If nothing matched
        return ""

    except Exception as e:
        print(f"Error extracting size: {e}")
        return ""
def process_document(doc):
    referer_url = doc['url']
    doc_id = doc['_id']

    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
        'cache-control': 'max-age=0',
        'if-none-match': 'W/"b9f36-APDcwXQw7Vb97hIzTuU1Ypk89Xs-gzip"',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        'cookie': 'AKA_A2=A; bm_ss=ab8e18ef4e; PIM-SESSION-ID=QPSBatfrCBQWeokH; ak_bmsc=501C5DA729B5F30C8FAE45B820A0DEC7~000000000000000000000000000000~YAAQTAA9F8Xs3+qYAQAAFJPyCRzKd9t+dId0hoKjbZWq3rkkE+zF4N7o2psiUHz6wzpNgqpxNM45mZIg20rVqW488UpuKO+bst0JagHqRZwqBGK/KcFG3mriRXycYH8aHrDF+1DecPgAtfBq+eNPRdG1MFvHcj+ichlwIW1My/vzH9pwIs/PV7wWapujMDDjtronOGYfqVe8t6OwtCzaXuNIs/+nT1/nB5uT3eouroyjXRqK0NXUf4fD4AQ+SnDG9xcbnW8S0YsxChd3OKDe108bQnNXLohqu9Fn0nBGNKMmPuVRoF3zsYrxtuGF0Hy5Hx7OCdYT4EFoeTvMBxkebQHE4+DRv0tf1wNIJRByCqHIQEaYDuyJ0V6sqBpPiUJGZWqiqbfqVbWWXuqTNmcPEhsmmy2BxRXpRF7Tmj5JdKLDErURaB1IRWJS6ucBkxCxkJlRZlv8C0x+X1Jl2jZ7dv8=; _gcl_au=1.1.1109200806.1756808514; gaUserId=c381b21e-9a99-4d19-97af-0fadb1ed8c69; _gid=GA1.3.1973147860.1756808515; _fbp=fb.2.1756808515112.852997408774012067; user_id_t=a9f2c410-4334-4f5f-b3a0-d5728c9c40b6; FPLC=IFFDBEwSPHZtYjySlwjN3IIGF7d0d2DwGPm%2FcZcJlNxn2WXFgAujbWVA%2FJ5JSdfn%2Fua9W4K7OPKQxTNNKZufaFOSTd2x8I%2BJbdjT4KqNHmsu5nfb6gcRxZMIPiE0Hg%3D%3D; superuser=33248570-d22b-41a1-9ffe-25055009dd06; page_refreshed=true; FPID=FPID2.3.dCI%2BaCfRZYxYiRB9KTUD5bwHUpeburigmV2Ue%2FQ9rLY%3D.1756808515; ROUTE=.jsapps-67b9c94d98-zfv9r; _abck=3E1B02826A2C9738F1F0C4D8A5F0B09B~0~YAAQTAA9F5zx3+qYAQAA6OnzCQ4xJEZ0XB/QAziebh4KYt8K7fcDqnGksNFSd3MDnzlXaXemtRGR2FEnKeTjtIwWlzClG4mbKP+BINpRLK5baJsJwBYsZiONGEy6o5Nwnjq0tZqXV0zBN5g6rfti9xIGcj3pbTtYK/sD12alww9MNSZxfQy0ypgXq0VaVg0k/WeuTK53byWwSlDAhs+1ph4H7YBLqj3f5PVTFlZOx3QuiGUTmteIGVeebAVDI6wdaY6hTOhgdLeX8LTKbsCjS+T+VK4MFbjs+Zy6tlFBwPyF8GqfFyr57rmrp8Opb5pFv1RtyXq3gIk06GXprehR51uhid03ZY0mjpW+2Txy9D6PEcP90I8ssLam5G82j77nuBtHXRKDoFaO0dcIiM8fmKeihx6QeALJC/GNQWLHX6vs8BMkRM8YRg9gKk/ESzMNv3AEDA07CKnoFljjirCgU1QdqdR2El0QgSLkJISQfZLTUqlR6RmLU0z1Ql3MWTUpsIBYjmOVmQdb5rMp6XUB7dQjxCCScrgSpTzCbXbbS725MSKvbBuONTPcs2iMQLcY+1o9v08QlMDQYuz+i1fv2I337+N8KdcrSFT4dbjBG+4Vka8clp//U852PaY0CbOoOcYE38E=~-1~-1~-1~~; e2-language=en_ID; language=en_ID; langcode=en; supersession=111375094; bm_s=YAAQTAA9F4X33+qYAQAAsW/1CQQyB1O6H/E6annbTV3YSeKwatceyQPOOzIIsdi4/DdgTaVLytUJn1FFUaxnyb7IfMJxMZLb5cgvZ0w8RKIbkBDxiay/TnqzxurxD48bszQ9tc3UkmHKRbVnQiYFX6AbdrWHLUOQCWkOk8unE+Az7RiF4o41djwSk3v7oC1FYdywZGfKmcxtx3uq3dUg4pH5dXmfpzUi1SAXMdwusaFwp32SXlGSbTQi9b0ht5mxYJY9s+rrP2/rOG51MYI3VpSLvhmXMhkXJtJt3PIS+REh4nArgQTKbCrYj+d4eeu9EIR+b8uHBufEDhjNRo+Si4HvHq7v8Cjx3PMn8a0odzjrGu8K2yGhNPtlRwPLlY09EFEXQsf4GS2ajFS/43ZGVQenac/Jz4RzTT7AYf+Qpz9901LXtvp80dKiGoUdNoK4X4MkZHArructFznJbe6ipVtNwMZtPqVzPzDr12LkIKC1BqKxVJSseqT9y+Wkamx7Jii6kkhxYX0bHpPEF5A15SZRoIA9+8JN/2vsfrrWdhpU/WYbBMzzL77VP6h2itrsxt3TzXmQ; bm_so=719EE3491D26A1CFFDA1F9A52A991AA168B4EA386876EE9B83FF6F98A199A4DD~YAAQTAA9F4b33+qYAQAAsW/1CQQFlwfdv3WdW8gu/xaVEqDGmXbjshS9XjabONdw7QfG/YkhY7ecBrdXFGolQ1wE7AlGQ2bmtNt92QxQea7t64R2+HznKPZbi2q4H6rx+HSiVZqdGD4q4gh3PSeG+CSaKpGdCAnQ4OvWxUiZvWppY1qPaVRrB7OmtX2XNGbBvp0DtuB3qdFJ+/tTg5WLHnXpYKlO9o99TOBSmBHMesEo7RVWk2q9rhl5Q9JTCQTtw3Dl/1WiYY7ZFONhFTPxulLQvYmTuD8D9QxGzJuXQGw1pw4r7p8qyxmbBQYgN7a15unMxEYF6JnM7wgypFkMdETLc7EG9EY+6rlX/bW4pOu1rQwQbzZel4AZFbntBudnrRWcxYxpMig8bzNUBW+8Lz8OuQq+ilVgWeLD9wNbu6/A+7kl1je6pb1NrFc6n/MFGIZOkQSXonDwOfcad8z7Rw==; bm_sz=B9BACBF64242938C4E11EA29626288D5~YAAQTAA9F4j33+qYAQAAsW/1CRwK1nk9xZzzPu98a/ivrh61/YWP0CtSDfdVJkC28XoWuP1xINyfpTwcf2AM+pEO5Y2LhQm8+ZoU1giK2U9fivWyWW/nF4CPttwGpf5HnEAOFWx+YDU8ex8eDXQUsQVkLLz8WSfiJ3dChtWSZHVkMZNsk7l84p97lmIcNKIZ+mlEQtXTpYzSE2FiGvOWqGRJgzc8BnG+l9BigWKu5bsPuScgJKl8ogHcZPB7wbwLvQ51u9mm7YKZyg302Q3J7cboF2XllxwZELfIot9zpvvi4eUWq2+o6pJp7C2K6r15eRQ1tRXuf7ooJjJ5A/lmwjPRqBbOJLOeJsBbfsXG8OWmOsd9LETrURcuYbwmA2GjdIwrYuKxwCdDgGsvqKq6xcsQjCCh5wQhNFQ4HEK6SXK8/cqRGFP0zA==~3225136~4600387; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A19909f2847e8bf-01de29516c0d7a-26011051-144000-19909f2847e8bf%22%2C%22%24device_id%22%3A%20%2219909f2847e8bf-01de29516c0d7a-26011051-144000-19909f2847e8bf%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; bm_lso=719EE3491D26A1CFFDA1F9A52A991AA168B4EA386876EE9B83FF6F98A199A4DD~YAAQTAA9F4b33+qYAQAAsW/1CQQFlwfdv3WdW8gu/xaVEqDGmXbjshS9XjabONdw7QfG/YkhY7ecBrdXFGolQ1wE7AlGQ2bmtNt92QxQea7t64R2+HznKPZbi2q4H6rx+HSiVZqdGD4q4gh3PSeG+CSaKpGdCAnQ4OvWxUiZvWppY1qPaVRrB7OmtX2XNGbBvp0DtuB3qdFJ+/tTg5WLHnXpYKlO9o99TOBSmBHMesEo7RVWk2q9rhl5Q9JTCQTtw3Dl/1WiYY7ZFONhFTPxulLQvYmTuD8D9QxGzJuXQGw1pw4r7p8qyxmbBQYgN7a15unMxEYF6JnM7wgypFkMdETLc7EG9EY+6rlX/bW4pOu1rQwQbzZel4AZFbntBudnrRWcxYxpMig8bzNUBW+8Lz8OuQq+ilVgWeLD9wNbu6/A+7kl1je6pb1NrFc6n/MFGIZOkQSXonDwOfcad8z7Rw==^1756808702054; _ga=GA1.3.457951192.1756808515; retuser_id_ct=8; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Sep+02+2025+15%3A55%3A04+GMT%2B0530+(India+Standard+Time)&version=202411.2.0&browserGpcFlag=0&isIABGlobal=false&hosts=&consentId=35cc323f-777d-49c3-9ef3-af7e8f674d17&interactionCount=0&isAnonUser=1&landingPath=NotLandingPage&groups=C0001%3A1%2CC0003%3A1%2CC0009%3A1&AwaitingReconsent=false; _ga_JJRD05R0VJ=GS2.1.s1756808514$o1$g1$t1756810172$j30$l0$h1984077674; bm_sv=E38FF6BE23C2D2B1B9F24E7E58B13A21~YAAQ1aTBF4a50+uYAQAAqkwkChyQOXvfxOsh9EJ5LCbe1EG5K2QQciYscxEMakyiXDoFLuY/ctLQ3dvWBPQYUMl6dWwxROSe1FM3AGbsnVg1OoRKAjf0qp2/BuRIyLTBBypX1IRbbEoXeb8v0Pq8vISMekfvB99SWyNHj37A4WMu56NfPz3bNCXvjIS3j5pXN3MlxGIC4aSMr2uFD/z4sh/7his4LYxW9fAfZ6El0nZV++qj+eYqjprWWK2rL2zY4viXyA==~1',
    }

    parsed_url = urlparse(referer_url)

    product_slug = parsed_url.path.strip('/').split('/')[-1]
    print("Product slug:", product_slug)
    html_filename = f"{product_slug}_page.html"
    html_filepath = os.path.join(html_path, html_filename)

    response = obj.to_requests(url=referer_url, headers=headers, html_path=html_filepath,
                               should_be=["wtcph-state"], max_retry=3,proxies=proxies, verify=False)# proxies=proxies, verify=False,
    if not response:
        response = obj.to_requests(url=referer_url, headers=headers, html_path=html_filepath,
                                   should_be=['wtcph-state'], max_retry=3,proxies=proxies, verify=False)
    if not response:
        response = obj.to_requests(url = referer_url, headers=headers, html_path=html_filepath,
                                   should_be=['wtcph-state'], max_retry=3,proxies=proxies, verify=False)
    if not response:
        print(f"getting wrong response:{referer_url}")
        return None
    elif 'Result Not Found' in response or 'This product is invalid.' in response or 'This page could not be found' in response:
        search_data.update_one(
            {'_id': id}, {'$set': {'Status': "Not found"}})
        print("Status Updated...")
    elif response:

        product_id = urlparse(referer_url).path.split('/')[-1].replace("BP_", "").strip()

        selector = Selector(text=response)

        json_text = selector.xpath('//script[@id="wtcph-state"]/text()').get()

        if not json_text:
            json_text = selector.xpath('//script[@id="wtcsg-state"]/text()').get()

        if not json_text:
            json_text = selector.xpath('//script[@id="wtcid-state"]/text()').get()

        data = None
        if json_text:
            data = json.loads(json_text)
        try:
            stock_status = data['cx-state']['product']['details']['entities'][str(product_id)]['variants']['value']['baseOptions'][0]['options'][
                0][
                'stock']['stockLevelStatus']
        except Exception as e:
            stock_status = data['cx-state']['product']['details']['entities'][str(product_id)]['variants']['value']['baseOptions'][0][
                'options'][
                0][
                'stock']['stockLevelStatus']
            print(e)
        if stock_status == "inStock":
            stock = True
        else:
            stock = False

        product = selector.xpath('//div[@class="ProductSummaryGroup"]')
        name = product.xpath('//div[@class="product-name"]/text()').get()
        brand = product.xpath('//h2[@class="product-brand"]/a/text()').get()
        main_price = product.xpath('//span[@class="price"]/text()').get()

        if main_price:
            price_value = float(main_price)

            price = int(price_value) if price_value.is_integer() else round(price_value, 2)

        compare_price = product.xpath('//span[@class="retail-price"]/text()').get()
        was_price=None
        if compare_price:
            try:

                cleaned_compare_price = compare_price.replace('Rp','').replace('RM', '').replace('S$', '').replace(',', '').replace('₱', '').strip()
                was_price_value = float(cleaned_compare_price)
                was_price = int(was_price_value) if was_price_value.is_integer() else round(was_price_value, 2)
            except Exception as e:
                print(e)
        else:
            was_price = None

        image_urls = selector.xpath('.//div[@class="ProductImages"]//img/@src').getall()
        main_offer = product.xpath('//span[@class="discount ng-star-inserted"]/text()').get() or ""
        offer = main_offer.strip()
        main_product_id = selector.xpath('//div[@class="info-container"]//div[@class="value"]/text()').get()
        joined_urls = ' | '.join(image_urls)
        breadcrumbs = selector.xpath(
            '//span[@itemprop="itemListElement"]//span[contains(@itemprop, "name")]/text()').getall()
        breads = ' > '.join(item.strip() for item in breadcrumbs if item.strip())

        main_promo = selector.xpath('//div[@class="container-title"]/text()').get() or ""
        promo = main_promo.strip()
        if not was_price or price == was_price:
            rrp_price = price
            was_price = ''
        else:
            rrp_price = was_price
        pack_size = extract_size(name)

        Items = {"Name": name, "Promo_Type": promo, "Price": price, "per_unit_price": "",
                 "WasPrice": was_price,
                 "Offer_info": offer, "Pack_size": pack_size, "Barcode": "",
                 "Images": joined_urls,
                 "ProductURL": referer_url, "is_available": stock,
                 "Status": "Done", "ParentCode": "", "ProductCode": main_product_id,
                 "retailer_name": "Watson",
                 "Category_Hierarchy": breads, "Brand": brand, "RRP": rrp_price}
        try:
                product_data.insert_one(Items)
                print("product inserted")
                search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
        except Exception as e:
            print(e)

        print(Items)

if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=20) as executor:
        docs = list(search_data.find({"Status": "Pending"}))
        executor.map(process_document, docs)


