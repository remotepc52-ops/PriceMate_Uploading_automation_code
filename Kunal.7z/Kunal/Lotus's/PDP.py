import json
from threading import Thread
from time import sleep
from config import *

def fetch_data(start, end):
    data_list = product_data.find({"Status": "Pending"}).skip(int(start)).limit(int(end))
    # data_list = product_data.find({ "ProductURL": { "$regex": "6748" } })
    for cat_item in data_list:
        ID = cat_item['_id']
        ProductURL = str(cat_item['ProductURL'])

        data_extraction(ID, ProductURL)


def data_extraction(ID, url):
    try:
        product_code = url.split("/product/")[-1].split("/")[0]

        filename = f'PDP_{product_code}.html'
        path = os.path.join(html_path, filename)
        full_path = path.replace("\\", "/")


        headers = {
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'en',
            'channel': 'web',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36'
        }

        api_url = f"https://api-o2o.lotuss.com.my/lotuss-mobile-bff/product/v1/products/detail?urlKey={product_code}&websiteCode=malaysia_hy"
        current_proxy = '2c6ea6e6d8c14216a62781b8f850cd5b'

        proxy_host = "api.zyte.com"
        proxy_port = "8011"
        proxy_auth = f"{current_proxy}:"

        proxies = {
            "http": "https://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port),
            "https": "http://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port)
        }
        response = obj.to_requests(url=api_url, headers=headers,proxies=proxies,
                                   html_path=full_path, should_be=['stockStatus'], max_retry=5)

        if not response:    
            print("❌Getting blank response..... ❌", url)
            product_data.update_one({'_id': ID}, {'$set': {"Status": "Not Found"}})
            return None

        elif 'VerifyHuman' in response:
            print("❌ Captcha Not Resolved after all retries executed..❌")

        elif 'Result Not Found' in response or 'Sorry, the product you  are looking for' in response or 'This page could not be found' in response:
            product_data.update_one({'_id': ID}, {'$set': {'Status': "Not found"}})
            print("✅ Status updated as Result ℹ️ Not Found...")

        elif response:
            print("📊 Analyzing retrieved 🛒 product data...")
            res_json = json.loads(response)
            Product = res_json['data']

            try:
                abbreviation = Product.get('unitOfQuantity', "") or ""
                PackageSize = f"{abbreviation}".strip()
            except:
                PackageSize = ""

            try:
                Promotion = Product["promotions"]
                Promo = []
                for p in Promotion:
                    text = p['offerText']
                    Promo.append(text)

                PreText = "|".join(Promo)

            except:
                PreText = ""

            try:
                brand = Product['links']['brand']['name']
                brand = brand.title()
            except:
                brand = ""

            try:
                product_images = []
                #data.mediaGallery[0].url
                for i in Product['mediaGallery']:
                    image_url = i['url']
                    product_images.append(image_url)

                product_images = "|".join(product_images)

            except:
                print("No Image Available...continue", url)
                return

            # data.breadcrumb[0].name
            breadcrumbs = [i['name'] for i in Product['breadcrumb']]
            breadcrumbs = " > ".join(breadcrumbs)

            available = Product['stockStatus']
            if available == 'IN_STOCK':
                is_available = True
            else:
                is_available = False

            ProductCode = Product['sku']
            producttitle = Product['name'].strip()

            # .finalPrice.value
            price_data = Product['priceRange']['minimumPrice']

            WasPrice = price_data.get("regularPrice").get('value')
            Price = price_data.get("finalPrice").get('value')
            if not Price and WasPrice or WasPrice == Price:
                Price = WasPrice
                WasPrice = None

            elif not WasPrice:
                print("Price should not be blank....")
                return None

            if not Price and not WasPrice:
                return None


            if not Price and not WasPrice:
                product_data.update_one({'_id': ID}, {'$set': {'Status': "Done_1"}})
                print("✅ Status updated as Result ℹ️ Done...")
                return None

            Items = {"Name": producttitle, "Promo_Type": "", "Price": Price, "per_unit_price": "",
                     "WasPrice": WasPrice,
                     "Offer_info": PreText, "Pack_size": PackageSize, "Barcode": "",
                     "Images": product_images,
                     "ProductURL": url,
                     "is_available": is_available,
                     "Status": "Done",   "ProductCode": ProductCode, "retailer_name": "lotus's",
                     "Category_Hierarchy": breadcrumbs, "Brand": brand, "RRP": WasPrice if WasPrice else Price}

            try:
                product_data.update_one({'_id': ID}, {'$set': Items})
                print("✅ Status updated as Result ℹ️ Done...")

            except Exception as e:
                if 'duplicate key error' not in str(e):
                    print("❌ Error: Unable to save data to database.", e)

        else:
            print("Somthing Went Wrong in Requests...")


    except Exception as e:
        print(f"Error in Main Data Extraction function ", e)

if __name__ == '__main__':
    print("🚀 Starting data scraping...")
    retry = 0
    while True and retry <= 5:
        retry += 1

        total_count = product_data.count_documents({'Status': 'Pending'})
        if not total_count:
            print("All Done...")
            break

        print("Total Pending....", total_count)
        if total_count > 1:
            variable_count = total_count // 20
        else:
            variable_count = total_count // total_count

        if variable_count == 0:
            variable_count = total_count ** 2

        count = 1
        threads = [Thread(target=fetch_data, args=(i, variable_count)) for i in
                   range(0, total_count, variable_count)]

        for th in threads:
            th.start()

        for th in threads:
            th.join()

        print(f"--------- Thread Ends ----------- ")
        sleep(5)

    if product_data.count_documents({'Status': 'Pending'}) == 0:
        print("🎉 Finished processing all records!")
