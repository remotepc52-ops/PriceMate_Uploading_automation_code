import requests

headers = {
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'en',
    'channel': 'web',
    'key': 'SeiRQmEDnaZXOlpfKhCjV4Bo2y6vAcW99QKmzifsgP2uCMN7wF3ahRXex84kH6qUVIWoY5Dp0GEljdAvS1JytOZcLbnBTr',
    'origin': 'https://www.lotuss.com.my',
    'priority': 'u=1, i',
    'referer': 'https://www.lotuss.com.my/',
    'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    'x-request-id': 'ee1d53b6-114d-41e6-81f1-e5ab700d8c0d',
}

params = {
    'urlKey': 'life-thai-chilli-sauce-360g-668974',
    'websiteCode': 'malaysia_hy',
}
api_url = f"https://api-o2o.lotuss.com.my/lotuss-mobile-bff/product/v1/products/detail?urlKey={product_code}&websiteCode=malaysia_hy"
response = requests.get(
    'https://api-o2o.lotuss.com.my/lotuss-mobile-bff/product/v1/products/detail',
    params=params,
    headers=headers,
)