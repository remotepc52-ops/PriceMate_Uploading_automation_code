# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import pymongo
import datetime
import pymongo
import datetime

class MongoPipeline:

    def process_item(self, item, spider):
        item["Crawled_At"] = datetime.datetime.now()
        # Use ProductURL or Barcode as unique key
        # query = {"ProductCode": item["ProductCode"]}
        # existing = spider.product_table.find_one(query)
        #
        # if existing:
        #     # Update price, availability, offer info only
        #     update_fields = {
        #         "Price": item["Price"],
        #         "WasPrice": item.get("WasPrice"),
        #         "is_available": item["is_available"],
        #         "Offer_info": item.get("Offer_info"),
        #         "Crawled_At": item["Crawled_At"]
        #     }
        #     spider.product_table.update_one(query, {"$set": update_fields})
        #
        #     legacy_items = {
        #         "last_seen": item["Crawled_At"],
        #         "active": True
        #     }
        #
        #     spider.legacy_urls.update_one(query, {"$set": legacy_items})

        try:
            legacy_items = {
                "ProductCode": item["ProductCode"],
                "ProductURL": item["ProductURL"],
                "last_seen": item["Crawled_At"],
                "added_on": item["Crawled_At"],
                "active": True
            }

            spider.legacy_urls.insert_one(legacy_items)
            spider.product_table.insert_one(dict(item))
        except:
            pass

        return item

