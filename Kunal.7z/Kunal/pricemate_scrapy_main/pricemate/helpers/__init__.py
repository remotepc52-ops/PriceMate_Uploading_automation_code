from datetime import datetime, timedelta

def should_refresh_product(last_updated_time, threshold_days=7):
    return (datetime.utcnow() - last_updated_time).days > threshold_days
