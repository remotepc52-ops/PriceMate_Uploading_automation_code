# File: pricemate/exports/export_utils.py (update this)

import pandas as pd
import os
from datetime import datetime
from pymongo import MongoClient

MONGO_URI = "mongodb://localhost:27017/"
EXPORT_PATH = "./exports/output"
TODAY = datetime.now().strftime("%Y-%m-%d")

def export_data_to_excel_and_json(retailer_name, db_name="pricemate", status_filter="Done", columns=None):
    client = MongoClient(MONGO_URI)
    db = client[db_name]
    collection = db[retailer_name]
    crawl_status = db["crawl_status"]

    os.makedirs(EXPORT_PATH, exist_ok=True)

    default_columns = [
        "ProductURL", "ProductCode", "Name", "Price",
        "WasPrice", "RRP", "Offer_info", "per_unit_price",
        "Pack_size", "Barcode", "Category_Hierarchy",
        "Brand", "Promo_Type", "is_available"
    ]
    export_columns = columns if columns else default_columns

    # Fetch data
    data = list(collection.find({"Status": status_filter}))
    if not data:
        print(f"No records found with status '{status_filter}' for {retailer_name}")
        return

    df = pd.DataFrame(data)
    df = df[[col for col in export_columns if col in df.columns]]
    df.insert(0, '#', range(1, len(df) + 1))
    df.insert(1, 'Id', range(1, len(df) + 1))
    if '_id' in df.columns:
        df.drop(columns=['_id'], inplace=True)

    excel_file = os.path.join(EXPORT_PATH, f"{retailer_name}_{TODAY}.xlsx")
    json_file = os.path.join(EXPORT_PATH, f"{retailer_name}_{TODAY}.json")
    df.to_excel(excel_file, index=False)
    df.to_json(json_file, orient='records', lines=True)

    # Insert crawl summary
    crawl_status.insert_one({
        "retailer": retailer_name,
        "date": TODAY,
        "record_count": len(df),
        "excel_file": excel_file,
        "json_file": json_file,
        "status": "exported",
        "ts": datetime.utcnow()
    })

    print(f"[✓] Excel: {excel_file}\n[✓] JSON: {json_file}\n[✓] Crawl status recorded")
