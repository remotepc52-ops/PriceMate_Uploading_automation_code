from export_utils import export_data_to_excel_and_json

if __name__ == '__main__':
    export_data_to_excel_and_json("woolworths_au")  # Replace with any retailer
