from pymongo import MongoClient
import re

mongo_uri = "mongodb://localhost:27017/"
db = MongoClient(mongo_uri)["PriceMate_amazon_sg"]  # change db name if needed
collection = db["url_pyt_test"]

seen_asins = set()
duplicates = []

for doc in collection.find({}, {"_id": 1, "url": 1}):
    url = doc["url"]
    match = re.search(r"/dp/([A-Z0-9]{10})", url)
    if match:
        asin = match.group(1)
        if asin in seen_asins:
            duplicates.append(doc["_id"])   # mark as duplicate
        else:
            seen_asins.add(asin)

if duplicates:
    collection.delete_many({"_id": {"$in": duplicates}})
    print(f"Deleted {len(duplicates)} duplicate URLs")
else:
    print("No duplicates found")
