# from typing import Union
# import scrapy
# from datetime import datetime
# from Common_Modual.common_functionality import *
# from pymongo import MongoClient
# from scrapy import Spider
# from twisted.internet.defer import Deferred
# from dateutil.relativedelta import relativedelta, TU
#
# next_tuesday = (datetime.today() + relativedelta(weekday=TU(0))).date()
#
# headers = {
#     'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
#     'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
#     'priority': 'u=0, i',
#     'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"',
#     'sec-ch-ua-mobile': '?0',
#     'sec-ch-ua-platform': '"Windows"',
#     'sec-fetch-dest': 'document',
#     'sec-fetch-mode': 'navigate',
#     'sec-fetch-site': 'none',
#     'sec-fetch-user': '?1',
#     'upgrade-insecure-requests': '1',
#     'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
#     'cookie': '_ga=GA1.1.983790201.1752042524; _ALGOLIA=anonymous-5d7dfac8-cdf3-420d-a95a-4e0b7ae0ab8e; _tt_enable_cookie=1; _ttp=01JZPXYKWT0V6JRDV97D0V2J4R_.tt.2; _gcl_au=1.1.1023804681.1752042525; _fbp=fb.2.1752042524875.853936467496842354; ab.storage.deviceId.d0f42a9f-65bc-4252-afb4-b08638f19fca=g%3Adeb2037f-6a04-64a9-e702-22a79aa41c2f%7Ce%3Aundefined%7Cc%3A1752042534446%7Cl%3A1752042534446; SL_C_23361dd035530_SID={"f17bb4f2fac1a827f5d1373c6651e4b9f7af80b0":{"sessionId":"VymjUaL6QoYdyKNU1YWzT","visitorId":"1OcCF7CmmTpLfRFcepku8"}}; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A197eddf500eced-08e48406d238ac8-26011151-144000-197eddf500eced%22%2C%22%24device_id%22%3A%20%22197eddf500eced-08e48406d238ac8-26011151-144000-197eddf500eced%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; AWSALB=Qdizqhokoegg/6TDjspT1bEztcNbuw7LekwREw75eb2wBxN+BCk5BXc+eRH6i7LDtu38ApleMGBKBDZEZtLiaZiZol3OUmIbHcUVxTlRo73FSTSeBjnskWplvSs+; _uetsid=f66278e05c8d11f08814290c2ab5a4d0; _uetvid=f66292005c8d11f09857ebff6a055a7b; ttcsid_CR7ADRJC77UDRITC2LG0=1752051491325::MjTjh2NoOdDR50o34UVx.2.1752051731885; ttcsid=1752051491326::IW8JE8UMkgC3HeTKyg9r.2.1752051731886; _ga_1QJMQEPBBB=GS2.1.s1752051489$o2$g1$t1752051732$j60$l0$h0; ph_phc_71Wc9tuY5KP32wp2jUlys7A0RTx4GI0yAk99FQ5KdIw_posthog=%7B%22distinct_id%22%3A%220197eddf-4f0c-7869-9a37-851442dce2d7%22%2C%22%24sesid%22%3A%5B1752051735973%2C%220197ee6b-cab6-7b27-a9ba-1817b4f3353e%22%2C1752051731126%5D%2C%22%24initial_person_info%22%3A%7B%22r%22%3A%22%24direct%22%2C%22u%22%3A%22https%3A%2F%2Fpetdirect.co.nz%2F%22%7D%7D',
# }
#
#
#
#
#
#
# class PetDirectSpider(scrapy.Spider):
#     name = "petdirect_category"
#
#     # allowed_domains = ["woolworths.com.au"]
#
#     # start_urls = ["https://www.woolworths.com.au/shop/browse"]
#
#     def __init__(self, retailer, region, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         self.retailer = retailer
#         self.region = region
#         self.today = next_tuesday.strftime("%Y_%m_%d")
#
#         # One-time Mongo connection
#         mongo_uri = "mongodb://localhost:27017"
#         db_name = f"PriceMate_{retailer}_{region}"
#
#         self.mongo_client = MongoClient(mongo_uri)
#         self.db = self.mongo_client[db_name]
#         self.category_input = self.db["category_urls"]
#
#         coll_list = self.db.list_collection_names()
#         if f'product_data_{self.today}' not in coll_list:
#             self.category_input.update_many({}, {"$set": {"Status": "Pending"}})
#
#         self.product_table = self.db[f"product_data_{self.today}"]
#
#         self.product_table.create_index("ProductCode", unique=True)
#         self.category_input.create_index("ProductUrl", unique=True)
#         proxy = "http://21ed11ef5c872bc7727680a52233027db4578a0e:@api.zenrows.com:8001"
#
#         proxies = {"http": proxy, "https": proxy}
#
#     def start_requests(self):
#         proxy = "http://21ed11ef5c872bc7727680a52233027db4578a0e:@api.zenrows.com:8001"
#
#         proxies = {"http": proxy, "https": proxy}
#         yield scrapy.Request(
#             "https://petdirect.co.nz/",
#             headers=headers,
#             callback=self.get_all_category,
#             meta = {"proxy": proxies['http']}
#         )
#
#     def get_all_category(self, response):
#         selector = Selector(response.text)
#         cat_urls = selector.xpath('//ul[@class="sub-menu"]/li/a/@href').getall()
#         proxy = "http://21ed11ef5c872bc7727680a52233027db4578a0e:@api.zenrows.com:8001"
#
#         proxies = {"http": proxy, "https": proxy}
#         for category in cat_urls:
#             base_url = f"https://petdirect.co.nz{category}"
#             yield scrapy.Request(
#                 url=base_url,
#                 headers=headers,
#                 callback=self.parse_category_pages,
#                 meta={"base_url": base_url, "page": 1,"proxy": proxies['http']}
#             )
#
#     def parse_category_pages(self, response):
#         selector = Selector(response.text)
#         base_url = response.meta["base_url"]
#         page = response.meta["page"]
#
#         product_links = selector.xpath('//h2[@class="product-card-name"]/a/@href').getall()
#
#         if not product_links:
#             self.logger.info(f"No more products found on page {page} of {base_url}")
#             return
#
#         for p_url in product_links:
#             main_url =  {
#                 "ProductUrl": p_url,
#                 "Status": "Pending"
#             }
#             print(main_url)
#             try:
#                 self.category_input.update_one(
#                     {"ProductUrl": p_url},
#                     {"$setOnInsert": main_url},
#                     upsert=True
#                 )
#             except Exception as e:
#                 self.logger.error(f"Error inserting {p_url}: {e}")
#
#         next_page = page + 1
#         next_url = f"{base_url}?page={next_page}"
#
#         yield scrapy.Request(
#             url=next_url,
#             headers=headers,
#             callback=self.parse_category_pages,
#             meta={"base_url": base_url, "page": next_page}
#         )
#
#
#
#
#
#     def close(spider: Spider, reason: str) -> Union[Deferred, None]:
#         print("Spider Closing....")
#
#
# if __name__ == '__main__':
#     # process = CrawlerProcess(get_project_settings())
#     # process.crawl(WoolworthsSpider)
#     # process.start()
#     from scrapy.cmdline import execute
#
#     execute('scrapy crawl petdirect_category -a retailer=PetDirect -a region=nz'.split())
#
