# File: pricemate/pricemate/spiders/woolworths_au_category.py
import json
import os
import time
from typing import Union

import pymongo
import scrapy
from datetime import datetime
from urllib.parse import urljoin
# from pricemate.items import ProductItem
from Common_Modual.common_functionality import *
from pymongo import MongoClient
from scrapy import Spider
from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
from twisted.internet.defer import Deferred
from datetime import datetime
from dateutil.relativedelta import relativedelta, TU
from dateutil.relativedelta import relativedelta, MO
# next_tuesday = (datetime.today() + relativedelta(weekday=TU(0))).date()
# Today1 = (datetime.today() + relativedelta(weekday=MO(1))).date()
Today1 = datetime.today().date()
headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
    'cache-control': 'max-age=0',
    # 'if-none-match': 'W/"4f3231567a8da80dbef764977a1715fe"',
    'priority': 'u=0, i',
    'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
    'cookie': '_ga=GA1.1.1913311790.1750656117; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A1979b3c6814ff0-0c6a504b3d4f488-26011e51-144000-1979b3c6815ff0%22%2C%22%24device_id%22%3A%20%221979b3c6814ff0-0c6a504b3d4f488-26011e51-144000-1979b3c6815ff0%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; _ga_T49B3XEG45=GS2.1.s1752140206$o10$g0$t1752140206$j60$l0$h0; _session_id=7P%2F7IiU6tLkpR8%2FGrvgAoasaSkwOn3xfETdHvyFe27m%2BE6dlI2WaAHneXTZUh%2FfIKvheJTki%2Fq7RPOu1jI6coW0TNLPdMAbdTktk8zas9G4V%2FV97wqqy7l7uuJSgfRC44s1TNrm1D%2F%2BJYVQTYZyYga%2FPS334E69EKkvDHW46kwaeyNNXVOUa0mb5%2F3RBfLuXCCjhExGyRR8tQ6bROA30M9BundKqdPkl36ArVdXUfjReGougs4S57WcGDfnRCZRIqUhlSxvLNJObG69xeo14Auww3oQA5MhdEb0VlCrQktzMUIAopSFwLYyfnNf5iCTC7ARsCCv6jRreg4lFcjkg1dA%3D--oH1d2Y4b29sAWYEx--qges4y6vsVbHzMO7K5ZRFg%3D%3D; _ga_B86HYM34PP=GS2.1.s1752140207$o10$g0$t1752140207$j60$l0$h0',
}






class RitchieSpider(scrapy.Spider):
    name = "ritchie_category"

    # allowed_domains = ["woolworths.com.au"]

    # start_urls = ["https://www.woolworths.com.au/shop/browse"]

    def __init__(self, retailer, region, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.retailer = retailer
        self.region = region
        self.today = Today1.strftime("%Y_%m_%d")

        # One-time Mongo connection
        mongo_uri = "mongodb://localhost:27017/"
        db_name = f"pricemate_eshop_ritchies_au"

        self.mongo_client = MongoClient(mongo_uri)
        self.db = self.mongo_client[db_name]
        self.legacy_urls = self.db[f"legacy_urls_{self.today}"]
        self.category_input = self.db[f"category_urls_{self.today}"]

        coll_list = self.db.list_collection_names()
        if f'Product_Data_{self.today}' not in coll_list:
            self.category_input.update_many({}, {"$set": {"Status": "Pending"}})

        self.product_table = self.db[f"Product_Data_{self.today}"]

        self.legacy_urls.create_index("ProductUrl", unique=True)
        self.product_table.create_index("ProductCode", unique=True)
        self.category_input.create_index("category_url", unique=True)

    def start_requests(self):
        yield scrapy.Request(
            "https://dtgxwmigmg3gc.cloudfront.net/sidebar/64ee945f0268574dd36df003/3-1748908289-2956.json?customer_group%5B%5D=64ee94600268574dd36df029&frontend_type=ecommerce_frontend&price_level%5B%5D=64ee94600268574dd36df01f",
            headers=headers,
            callback=self.get_all_category
        )

    def get_all_category(self, response):

        data = json.loads(response.text)
        departments = data.get("departments", [])

        for department in departments:
            slug = department.get("slug")
            page = 1
            main_list ={
                "category_url": slug,
                "Status": "Pending",
            }
            try:
                self.category_input.insert_one(main_list)
            except pymongo.errors.DuplicateKeyError:
                pass

            slug_url = f'https://ringwoodeast.shop.ritchies.com.au/category/{slug}?page={page}'
            proxy = "http://21ed11ef5c872bc7727680a52233027db4578a0e:@api.zenrows.com:8001"

            proxies = {"http": proxy, "https": proxy}
            yield scrapy.Request(
                url=slug_url,
                headers=headers,
                callback=self.slugs_page,
                meta={"slug": slug, "page": page}
            )

    def slugs_page(self, response):
        slug = response.meta["slug"]
        page = response.meta["page"]

        prod_urls = response.xpath('//div[@class="talker__section talker__section--image"]/a/@href').getall()

        if not prod_urls:
            print(f"No more products found at slug: {slug}, page: {page}")
            return

        for main_url in prod_urls:
            product_url = f"https://ringwoodeast.shop.ritchies.com.au{main_url}"
            print(product_url)

            product_data = {
                "ProductUrl": product_url,
                "Status": "Pending"
            }

            try:
                self.legacy_urls.insert_one(product_data)
                print(f"Inserted product URL: {product_url}")
            except Exception as e:
                print(f"Error inserting product URL: {e}")

        next_page = page + 1
        next_slug_url = f'https://ringwoodeast.shop.ritchies.com.au/category/{slug}?page={next_page}'

        yield scrapy.Request(
            url=next_slug_url,
            headers=headers,
            callback=self.slugs_page,
            meta={"slug": slug, "page": next_page}
        )





    def close(spider: Spider, reason: str) -> Union[Deferred, None]:
        print("Spider Closing....")


if __name__ == '__main__':
    # process = CrawlerProcess(get_project_settings())
    # process.crawl(WoolworthsSpider)
    # process.start()
    from scrapy.cmdline import execute

    execute('scrapy crawl ritchie_category -a retailer=ritchies-au -a region=au'.split())

