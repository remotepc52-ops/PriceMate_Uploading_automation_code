import json
import scrapy
from datetime import datetime
from Common_Modual.common_functionality import *
from pymongo import MongoClient
from datetime import datetime
from dateutil.relativedelta import relativedelta, TU
from dateutil.relativedelta import relativedelta, MO
# next_tuesday = (datetime.today() + relativedelta(weekday=TU(0))).date()
# Today1 = (datetime.today() + relativedelta(weekday=MO(1))).date()
Today1 = datetime.today().date()
headers = {
    'sec-ch-ua-platform': '"Windows"',
    'Referer': 'https://ringwoodeast.shop.ritchies.com.au/',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'cookie': '_ga=GA1.1.1913311790.1750656117; _session_id=ykegy3CJlBewZ99%2FV3Il6bBTv6PrjaNgxguGGMAfzbsoXHX%2FVaL5wcWWBzUZ%2FagVUlME4TVCJZuy8z9SbmVyJYNx8e3y9NkmzS0OKIMPy7xSWKXrH19gGqG2NgIdATe3e80GAD9f8Nm9JXthShULjCO3OJWURdmrrGgL0HfEGLal6yrm8AsVDT9Bkup8u8CpxTdlSbBK7l3h9DjveP8vHvGMaVuoQRYBcJbUq3qV6kCAnbJ%2BANvHFIhWmLUgHsWkQ49kmw%2B7anqwVAVL89dSg9rRvLPs7RlJxoyfpMkLsgqSDDzALOjkwtJn441IK05ICalDvm5uhLbrBfS%2FxJK2rz5%2FsPYLnZtvdfdkX8fiHhMAzhF8PrFkCKC5ODW1S6m%2FpOHZhOe3bIzYwHW04A%3D%3D--GTNV2k79UcG0SH%2BM--EQ2SHXVY2oQodi35gpgw0A%3D%3D; _ga_T49B3XEG45=GS2.1.s1752140206$o10$g1$t1752141972$j37$l0$h0; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A1979b3c6814ff0-0c6a504b3d4f488-26011e51-144000-1979b3c6815ff0%22%2C%22%24device_id%22%3A%20%221979b3c6814ff0-0c6a504b3d4f488-26011e51-144000-1979b3c6815ff0%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; _ga_B86HYM34PP=GS2.1.s1752140207$o10$g1$t1752141972$j37$l0$h0',

}
class RitchiePDPSpider(scrapy.Spider):
    name = "ritchie_pdp"

    def __init__(self, retailer, region, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.retailer = retailer
        self.region = region
        self.today = Today1.strftime("%Y_%m_%d")

        mongo_uri = "mongodb://localhost:27017/"
        db_name = f"pricemate_eshop_ritchies_au"
        self.mongo_client = MongoClient(mongo_uri)
        self.db = self.mongo_client[db_name]

        self.legacy_urls = self.db[f"legacy_urls_{self.today}"]
        self.product_table = self.db[f"Product_Data_{self.today}"]

        self.legacy_urls.create_index("ProductUrl", unique=True)
        self.product_table.create_index("ProductCode", unique=True)

    def start_requests(self):
        pending_products = self.legacy_urls.find({"Status": "Pending"})
        for product in pending_products:
            url = product["ProductUrl"]
            yield scrapy.Request(
                url=url,
                callback=self.parse_pdp,
                headers=headers,
                meta={"mongo_id": product["_id"], "url": url}
            )

    def parse_pdp(self, response):
        mongo_id = response.meta["mongo_id"]
        url = response.meta["url"]
        selector = Selector(response.text)

        try:
            scripts = selector.xpath('//script/text()').getall()
            member_price = None
            strip_member = None
            was_price = None
            main_was = None

            member = selector.xpath(
                "//div[contains(@class, 'ProductDetail__Price__LoyaltyMember')]//span/text()").get()
            if member:
                member_price = member.split('$')[-1].strip()
                strip_member = float(member_price) if member_price else None

            unit_price = selector.xpath('//span[contains(@class, "ProductDetail__Price__UnitPricing")]/text()').get()
            if unit_price:
                unit_price = unit_price.replace('$', '').strip()

            was_price_raw = selector.xpath('//span[@class="ProductDetail__Price__Was"]/span/text()').get()
            if was_price_raw:
                was_price = was_price_raw.split('$')[-1].strip()
                main_was = float(was_price)
            image = selector.xpath('//div[@class="ProductDetail__SingleImage"]//img/@src').get()
            size = selector.xpath('//h1[@class="ProductDetail__Title"]/span//text()').get()
            if unit_price:
                unit_price = unit_price.replace('$', '').strip()

            json_ld = selector.xpath('//script[@type="application/ld+json"]/text()').get()
            data = json.loads(json_ld)
            brand = data.get("brand")
            availability_url = data.get("offers", {}).get("availability", "")
            availability_status = availability_url.split("/")[-1]
            if availability_status == 'InStock':
                availability_status = True
            else:
                availability_status = False
            for script in scripts:
                # Look for the gtag event that contains item details
                match = re.search(r"gtag\('event',\s*'view_item',\s*({.*?})\);", script, re.DOTALL)
                if match:
                    try:
                        gtag_json = match.group(1)
                        data = json.loads(gtag_json)
                        items = data.get("items", [])
                        for item in items:
                            item_id = item.get("item_id")
                            item_name = item.get("item_name")
                            price = item.get("price")
                            categories = []

                            # Loop through all keys
                            for key, value in item.items():
                                if key.startswith("item_category") and value:
                                    categories.append(value.strip())

                            # Join all categories with " > "
                            category_hierarchy = " > ".join(categories)

                            if main_was:
                                rrp_price = main_was
                            else:
                                rrp_price = price
                            Items = {"Name": item_name, "Promo_Type": "", "Price": price, "per_unit_price": unit_price,
                                     "WasPrice": main_was,
                                     "Offer_info": "", "Pack_size": size, "Barcode": "",
                                     "Images": image,
                                     "ProductURL": url, "is_available": availability_status,
                                     "Status": "Done", "ParentCode": "", "ProductCode": item_id,
                                     "retailer_name": "ritchies-au",
                                     "Category_Hierarchy": category_hierarchy, "Brand": brand, "RRP": rrp_price}

                            # Save base variant
                            member_rrp = was_price if was_price else strip_member

                            product_variants = []

                            # Normal variant
                            product_variants.append({
                                **Items,
                                "ProductCode": item_id,
                                "Price": price,
                                "RRP": float(rrp_price),
                                "Promo_Type": ""
                            })

                            # Member variant if available
                            if member_price:
                                product_variants.append({
                                    **Items,
                                    "ProductCode": f"{item_id}_MEM",
                                    "Price": strip_member,
                                    "RRP": float(member_rrp),
                                    "Promo_Type": "MEMBER SPECIAL"
                                })

                            for variant in product_variants:
                                try:
                                    self.product_table.update_one(
                                        {"ProductCode": variant["ProductCode"]},
                                        {"$set": variant},
                                        upsert=True
                                    )
                                    print(f"Upserted ProductCode: {variant['ProductCode']}")
                                    self.legacy_urls.update_one(
                                        {"ProductUrl": url},
                                        {"$set": {"Status": "Done"}}
                                    )
                                except Exception as e:
                                    print(f"Insert failed for {variant['ProductCode']}: {e}")
                    except Exception as e:
                        print(e)
        except Exception as e:
            print(e)
if __name__ == "__main__":
    from scrapy.cmdline import execute
    execute("scrapy crawl ritchie_pdp -a retailer=ritchies-au -a region=au".split())
