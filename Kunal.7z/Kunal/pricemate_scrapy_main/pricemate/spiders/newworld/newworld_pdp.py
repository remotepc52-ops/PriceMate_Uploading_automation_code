# import json
# from scrapy.selector import Selector
# from typing import Union
# import scrapy
# from datetime import datetime
# from Common_Modual.common_functionality import *
# from pymongo import MongoClient
# from dateutil.relativedelta import relativedelta, TU
#
# next_tuesday = (datetime.today() + relativedelta(weekday=TU(0))).date()
# headers = {
#         'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
#         'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
#         'cache-control': 'max-age=0',
#         'priority': 'u=0, i',
#         'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"',
#         'sec-ch-ua-arch': '"x86"',
#         'sec-ch-ua-bitness': '"64"',
#         'sec-ch-ua-full-version': '"138.0.7204.97"',
#         'sec-ch-ua-full-version-list': '"Not)A;Brand";v="8.0.0.0", "Chromium";v="138.0.7204.97", "Google Chrome";v="138.0.7204.97"',
#         'sec-ch-ua-mobile': '?0',
#         'sec-ch-ua-model': '""',
#         'sec-ch-ua-platform': '"Windows"',
#         'sec-ch-ua-platform-version': '"19.0.0"',
#         'sec-fetch-dest': 'document',
#         'sec-fetch-mode': 'navigate',
#         'sec-fetch-site': 'same-origin',
#         'sec-fetch-user': '?1',
#         'upgrade-insecure-requests': '1',
#         'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
#         'cookie': 'SessionCookieIdV3=b28f6195593d44119c14d5f26b44c112; GeolocationInformation={"IsUnknown":false,"AreaCode":"N/A","BusinessName":"N/A","City":"Singapore","Country":"SG","Dns":"N/A","Isp":"N/A","Latitude":1.28967,"Longitude":103.85007,"MetroCode":"N/A","PostalCode":"018989","Region":"N/A","Url":"N/A"}; eCom_STORE_ID=6ea5a1cf-56b8-44eb-856c-fd916560e92e; server_nearest_store_v2={"StoreId":"6ea5a1cf-56b8-44eb-856c-fd916560e92e","UserLat":"1.28967","UserLng":"103.85007","StoreLat":"-45.0258","StoreLng":"168.7419","IsSuccess":true}; eCom_StoreId_NotSameAs_Brands=false; brands_store_reset=; STORE_ID_V2=6ea5a1cf-56b8-44eb-856c-fd916560e92e|False; Region=SI; AllowRestrictedItems=true; _gcl_au=1.1.139499621.1751886003; _ga=GA1.1.710376333.1751886004; FPID=FPID2.3.XQ83pBGX3LHhjBATNJ2C%2FkWO92SYZnzov1nksnk6Mp0%3D.1751886004; ki_r=; ki_s=230135%3A0.0.0.0.0; _hjSessionUser_877117=eyJpZCI6ImJlMTMzZDdjLTlmMTctNTZiMC04YzhiLTJjODNkY2U4ZWViZCIsImNyZWF0ZWQiOjE3NTE4ODYwMDQ5ODcsImV4aXN0aW5nIjp0cnVlfQ==; ORA_FPC=id=f7c0464f-6076-4042-8101-2b3854d15e0d; WTPERSIST=; _fbp=fb.3.1751886064708.532140073404865; _fbp=fb.3.1751886064708.532140073404865; BVBRANDID=7db3d93f-651c-4ff2-be43-886cab9016ba; browser_nearest_store={%22StoreId%22:%22%22%2C%22IsSuccess%22:false}; browser_nearest_store_v2={%22StoreId%22:%22%22%2C%22IsSuccess%22:false}; FPLC=Oa%2F%2FIocRngbjWKoe2fmxwWt0zAEmWC7g4WTtiSnBqiM5Q5jOnuT%2BynjUkS5hsg%2FuHD9uY4oSBTi85%2BYrnzHHyBmiJ5xtZk%2BQw1PBZttvYZuarSwqPbkvYKtH7hw0dA%3D%3D; shell#lang=en; __RequestVerificationToken=jRor1LNCV9kiLJkDitssC0TBhzilY8YVvt3THKQwKRRLWHEJO5mdaUJqSPXUSKpVGyktQHoGhnZsXmw-mTI-MCtoN7M1; sxa_site=New World; __cf_bm=_uIoKNxbgIu8RxGtSFX0akhFfsDWF1B_bmDaHlJcY7o-1752040976-1.0.1.1-9gVA8UdnqB453lc8.0UrTTQaBeWDPYWJmrreLd6MO2ChKQMezr7568kuwlrng8H6QpPM.YoWjXSj9B42mLcB9OKa1oOyG8jksiAJgOf2azYys.DWoxg6MkbvSP3JRjds; _hjSession_877117=eyJpZCI6IjEwNjI4YmNlLTU5NzAtNGIzZS05YjIwLTY0OWI0ZDEyNmIxMSIsImMiOjE3NTIwNDA5OTEzNzYsInMiOjEsInIiOjAsInNiIjowLCJzciI6MCwic2UiOjAsImZzIjowLCJzcCI6MX0=; cf_clearance=dIfFE94_WfUpysbUAeiXef2_uG__7c4GnOt1YNzDU0A-1752040991-1.2.1.1-N4tUdH5njlY0hm5CjvxlCel2hoP0cZtqhDiut27skqWZvfG74KDnAbeRbveKRW8igtyIRPePs9TnGq0xD6lBBP1MY6LzgPFaXG1.ecGIaxglAZIFmKddN0ztZZg3Ax_ZpsQH4mPhkD7K9FLs5Op6fxBFxou2bLXA2ruFjUFj5ZUFD3Q._alKClyLSiIh4FK9i0VyGwBF72WjZeIgsMtuWI8yLYaaQogMr.FVOGiScUg; fs-store-select-tooltip-closed=true; __cfruid=0c537ef060315f2eecb1d727b02e54854a800af2-1752041070; ki_t=1751886004930%3B1752040991370%3B1752041073879%3B3%3B46; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A197e48acb177d0-0f7ae17b3438318-26011e51-144000-197e48acb177d0%22%2C%22%24device_id%22%3A%20%22197e48acb177d0-0f7ae17b3438318-26011e51-144000-197e48acb177d0%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; BVBRANDSID=fbc21b13-d48c-4a58-b2ff-6a4c51ba3c13; ABTastySession=mrasn=&lp=https%253A%252F%252Fwww.newworld.co.nz%252F; ABTasty=uid=9vnhsb4e972g9b5p&fst=1751886002734&pst=1751976594602&cst=1752040978848&ns=10&pvt=70&pvis=4&th=1407762.1748005.69.4.10.1.1751886002748.1752041597132.0.10_1407769.0.69.4.10.1.1751886002750.1752041597138.0.10_1426170.0.10.1.5.1.1751886002750.1752040978856.0.10_1454120.0.69.4.10.1.1751886003042.1752041597213.0.10_1464559.0.10.1.5.1.1751886003042.1752040978861.0.10; _ga_6M61DH60LD=GS2.1.s1752040984$o10$g1$t1752041598$j56$l0$h2114700640',
# }
#
# class newworldPDPSpider(scrapy.Spider):
#     name = "newworld_pdp"
#
#     def __init__(self, retailer, region, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         self.retailer = retailer
#         self.region = region
#         self.today = next_tuesday.strftime("%Y_%m_%d")
#
#         mongo_uri = "mongodb://localhost:27017"
#         db_name = f"PriceMate_newworld_nz_spidey"
#         self.mongo_client = MongoClient(mongo_uri)
#         self.db = self.mongo_client[db_name]
#
#         self.category_input = self.db["search_data_2025_07_08"]
#         self.product_data = self.db[f"product_data_2025_07_08"]
#
#         self.category_input.create_index("ProductUrl", unique=True)
#         self.product_data.create_index("ProductCode", unique=True)
#
#     def start_requests(self):
#         pending_products = self.category_input.find({"Status": "Pending"})
#         for product in pending_products:
#             url = product["ProductUrl"]
#             proxy = "http://21ed11ef5c872bc7727680a52233027db4578a0e:@api.zenrows.com:8001"
#
#             proxies = {"http": proxy, "https": proxy}
#             yield scrapy.Request(
#                 url=url,
#                 callback=self.parse_pdp,
#                 headers=headers,
#                 meta={"mongo_id": product["_id"], "ProductUrl": url}#"proxy": proxies['http'],
#             )
#
#     def parse_pdp(self, response):
#         mongo_id = response.meta["mongo_id"]
#         product_url = response.meta["ProductUrl"]
#         selector = Selector(text=response.text)
#         name = selector.xpath('//h1[@data-testid="product-title"]//text()').get()
#         per_unit_price = selector.xpath('//p[@data-testid="non-promo-comparative-price"]//text()').get()
#         alt_text = selector.xpath('//div[@class="dkmg3a0"]/div/img/@alt').get() or ""
#
#         offer_main = ""
#
#         if alt_text:
#             try:
#                 offer_main = alt_text.split(', ', 1)[-1].strip()
#             except:
#                 offer_main = ""
#         json_text = selector.xpath('//script[@id="__NEXT_DATA__"]/text()').get()
#         if json_text:
#             try:
#                 json_data = json.loads(json_text)
#                 page_props = json_data.get('props', {}).get('pageProps', {})
#                 product = page_props.get('product', {})
#                 product_id = product.get('id')
#                 brand = product.get('brand')
#                 categories = product.get('categories', [])
#                 category_path = ' > '.join(categories)
#                 pack_size = product.get('subtitle')
#                 images = product.get('images', {})
#                 main_image = images.get('lg')
#
#                 alt_images = product.get('alternativeImages', [])
#                 alt_image_urls = [img.get('url') for img in alt_images if img.get('url')]
#                 retailPrice = product.get('price').get('retailValue')
#                 price_main = retailPrice / 100
#                 club_sale_price = product.get('price').get('saleValue') or ""
#                 price_club = club_sale_price / 100
#                 club_per_unit = product.get('promotionUnitPrice', {}).get('plainText') or ""
#
#                 all_images = [main_image] + alt_image_urls if main_image else alt_image_urls
#                 image_string = ' | '.join(all_images)
#                 print("Image String:", image_string)
#             except json.JSONDecodeError as e:
#                 print("Error parsing JSON:", e)
#         price_json = selector.xpath('//script[@type="application/ld+json"]/text()').get()
#         if price_json:
#             try:
#                 main_data = json.loads(price_json)
#                 availability_url = main_data.get('offers', {}).get('availability', '')
#
#                 stock_status = availability_url.endswith('InStock')
#                 print(stock_status)
#
#             except Exception as e:
#                 print(e)
#         Items = {"Name": name, "Promo_Type": "", "Price": price_main, "per_unit_price": per_unit_price,
#                  "WasPrice": "",
#                  "Offer_info": offer_main, "Pack_size": pack_size, "Barcode": "",
#                  "Images": image_string,
#                  "ProductURL": product_url, "is_available": stock_status,
#                  "Status": "Done", "ParentCode": "", "ProductCode": product_id,
#                  "retailer_name": "New World",
#                  "Category_Hierarchy": category_path, "Brand": brand, "RRP": price_main}
#         try:
#             self.product_data.update_one(
#                 {"ProductCode": Items["ProductCode"]},
#                 {"$set": Items},
#                 upsert=True
#             )
#             self.category_input.update_one({"_id": mongo_id}, {"$set": {"Status": "Done"}})
#             print("Base item saved.")
#         except Exception as e:
#             self.category_input.update_one({"_id": mongo_id}, {"$set": {"Status": "Not found"}})
#             print(f"Error saving base item: {e}")
#
#             # Handle Club Deal Offer
#         if offer_main == "Club Deal":
#             club_item = Items.copy()
#             club_item["Price"] = price_club
#             club_item["per_unit_price"] = club_per_unit
#             club_item["ProductCode"] = f"{product_id}_CLB"
#             club_item["RRP"] = price_club
#             club_item["Offer_info"] = "Club Deal"
#             try:
#                 self.product_data.update_one(
#                     {"ProductCode": club_item["ProductCode"]},
#                     {"$set": club_item},
#                     upsert=True
#                 )
#                 print("Club Deal item saved.")
#             except Exception as e:
#                 print(f"Error saving Club Deal item: {e}")
#
#
#
#
#
#
# if __name__ == "__main__":
#     from scrapy.cmdline import execute
#     execute("scrapy crawl newworld_pdp -a retailer=newworld -a region=nz".split())
