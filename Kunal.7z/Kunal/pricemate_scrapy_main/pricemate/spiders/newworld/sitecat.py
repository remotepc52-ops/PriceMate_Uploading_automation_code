#
# from typing import Union
# import scrapy
# from datetime import datetime
# from Common_Modual.common_functionality import *
# from lxml import etree
# from pymongo import MongoClient
# from scrapy import Spider
# from scrapy.crawler import CrawlerProcess
# from scrapy.utils.project import get_project_settings
# from twisted.internet.defer import Deferred
# from dateutil.relativedelta import relativedelta, TU
#
# next_tuesday = (datetime.today() + relativedelta(weekday=TU(0))).date()
#
# headers = {
#     'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
#     'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
#     'cache-control': 'max-age=0',
#     'priority': 'u=0, i',
#     'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
#     'sec-ch-ua-arch': '"x86"',
#     'sec-ch-ua-bitness': '"64"',
#     'sec-ch-ua-full-version': '"137.0.7151.120"',
#     'sec-ch-ua-full-version-list': '"Google Chrome";v="137.0.7151.120", "Chromium";v="137.0.7151.120", "Not/A)Brand";v="24.0.0.0"',
#     'sec-ch-ua-mobile': '?0',
#     'sec-ch-ua-model': '""',
#     'sec-ch-ua-platform': '"Windows"',
#     'sec-ch-ua-platform-version': '"19.0.0"',
#     'sec-fetch-dest': 'document',
#     'sec-fetch-mode': 'navigate',
#     'sec-fetch-site': 'none',
#     'sec-fetch-user': '?1',
#     'upgrade-insecure-requests': '1',
#     'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
#     'cookie': 'shell#lang=en; SessionCookieIdV3=b28f6195593d44119c14d5f26b44c112; GeolocationInformation={"IsUnknown":false,"AreaCode":"N/A","BusinessName":"N/A","City":"Singapore","Country":"SG","Dns":"N/A","Isp":"N/A","Latitude":1.28967,"Longitude":103.85007,"MetroCode":"N/A","PostalCode":"018989","Region":"N/A","Url":"N/A"}; eCom_STORE_ID=6ea5a1cf-56b8-44eb-856c-fd916560e92e; server_nearest_store_v2={"StoreId":"6ea5a1cf-56b8-44eb-856c-fd916560e92e","UserLat":"1.28967","UserLng":"103.85007","StoreLat":"-45.0258","StoreLng":"168.7419","IsSuccess":true}; __RequestVerificationToken=ui77OLpQs-6-YumFDpX_72Z8SS2ONIOfcTIHUwY8vfFg2Xmi-S0aq-XqADHDwOGeflDD6rMO6StX3yzQxWPKpJZk9rc1; eCom_StoreId_NotSameAs_Brands=false; brands_store_reset=; STORE_ID_V2=6ea5a1cf-56b8-44eb-856c-fd916560e92e|False; Region=SI; AllowRestrictedItems=true; _gcl_au=1.1.139499621.1751886003; _ga=GA1.1.710376333.1751886004; FPID=FPID2.3.XQ83pBGX3LHhjBATNJ2C%2FkWO92SYZnzov1nksnk6Mp0%3D.1751886004; FPLC=gT9ihFY60fnC2Qy4sxFqRbhbpkz%2BNS3eKKKKSPhbQWZooRGeOOhFqRu19Gu4ZWnP9nkkj%2Fx3qs5L7eIkb47E4cAqNGwnaAOhBgn%2B7wDj23fiBXvrOkQGLh79Ku0kdw%3D%3D; ki_r=; ki_s=230135%3A0.0.0.0.0; _hjSessionUser_877117=eyJpZCI6ImJlMTMzZDdjLTlmMTctNTZiMC04YzhiLTJjODNkY2U4ZWViZCIsImNyZWF0ZWQiOjE3NTE4ODYwMDQ5ODcsImV4aXN0aW5nIjp0cnVlfQ==; ORA_FPC=id=f7c0464f-6076-4042-8101-2b3854d15e0d; WTPERSIST=; fs-store-select-tooltip-closed=true; _fbp=fb.3.1751886064708.532140073404865; sxa_site=New World; _fbp=fb.3.1751886064708.532140073404865; BVBRANDID=7db3d93f-651c-4ff2-be43-886cab9016ba; browser_nearest_store={%22StoreId%22:%22%22%2C%22IsSuccess%22:false}; browser_nearest_store_v2={%22StoreId%22:%22%22%2C%22IsSuccess%22:false}; __cfruid=1383d05aeee3f656fa4f1c903d741e3e2d0878a5-1751889595; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A197e48acb177d0-0f7ae17b3438318-26011e51-144000-197e48acb177d0%22%2C%22%24device_id%22%3A%20%22197e48acb177d0-0f7ae17b3438318-26011e51-144000-197e48acb177d0%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; cf_clearance=SHsJhedGBAZVv2CLhMdOiDOUlVZi73fW.fYn0vI9MiA-1751889596-1.2.1.1-XJS3lvjXF5Y1mN.mt0ZpRiuF0cAm9xxryPjf9Q9iUT682WOFOYpJq66FnnVTwF5gt66la3XDlBLVET81vBfOFlHt0T0T.Skob4Uh1dzIpfPkm_OdlZuvATvHjNhesgl6z7W12VcVRnfVZLHT3PKrzOSe9lA6uT7jHxyrKNqI_jQLXfrra4a5j3VPfWtPM5rT9N1IrIje8cZNSwWD54wzoUAQzgXwLImhoAcHNVdDeNrF33iQuEdxEVHiZroBxzFK; ABTasty=uid=9vnhsb4e972g9b5p&fst=1751886002734&pst=1751886002734&cst=1751889595227&ns=2&pvt=3&pvis=1&th=1407762.1748005.3.1.2.1.1751886002748.1751889595247.0.2_1407769.0.3.1.2.1.1751886002750.1751889595249.0.2_1426170.0.1.1.1.1.1751886002750.1751886002750.0.1_1454120.0.3.1.2.1.1751886003042.1751889595269.0.2_1464559.0.1.1.1.1.1751886003042.1751886003042.0.1; ki_t=1751886004930%3B1751886004930%3B1751889597188%3B1%3B5; _ga_6M61DH60LD=GS2.1.s1751889563$o2$g1$t1751889712$j60$l0$h1360476985; __cf_bm=fB5aGJ3hVx4J6f80_N7bcOjl5aVqiZJ20MdqMyvH_.k-1751947547-1.0.1.1-vn0Mf9R0K0vuzzkKWnP1ZI.TOU9je9dnH974rIiM9ERj4G3yJJY0j4w3M_.RVgQF1NufB9GCWYLIb1UVKTZXLAGyX6zArJx.hlYTp5E8JSmbyMnWLYL3nJYx.jFe89zV',
# }
#
#
#
#
#
#
# class newworldSpider(scrapy.Spider):
#     name = "newworld_category"
#
#     # allowed_domains = ["woolworths.com.au"]
#
#     # start_urls = ["https://www.woolworths.com.au/shop/browse"]
#
#     def __init__(self, retailer, region, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         self.retailer = retailer
#         self.region = region
#         self.today = next_tuesday.strftime("%Y_%m_%d")
#
#         # One-time Mongo connection
#         mongo_uri = "mongodb://localhost:27017"
#         db_name = f"PriceMate_{retailer}_{region}_spidey"
#
#         self.mongo_client = MongoClient(mongo_uri)
#         self.db = self.mongo_client[db_name]
#         self.category_input = self.db[f"search_data_{self.today}"]
#
#         coll_list = self.db.list_collection_names()
#         if f'product_data_{self.today}' not in coll_list:
#             self.category_input.update_many({}, {"$set": {"Status": "Pending"}})
#
#         self.product_table = self.db[f"product_data_{self.today}"]
#
#         self.product_table.create_index("Product_code", unique=True)
#         self.category_input.create_index("ProductUrl", unique=True)
#
#
#     def start_requests(self):
#         proxy = "http://21ed11ef5c872bc7727680a52233027db4578a0e:@api.zenrows.com:8001"
#
#         proxies = {"http": proxy, "https": proxy}
#         main_cat_urls = [
#             f"https://www.newworld.co.nz/ecom_sitemap_products_{i}.xml"
#             for i in range(10)
#         ]
#
#         for url in main_cat_urls:
#             yield scrapy.Request(
#                 url,
#                 headers=headers,
#                 callback=self.get_all_category,
#                 # meta={"proxy": proxies['http']}
#             )
#
#     def get_all_category(self, response):
#         namespaces = {'ns': 'https://www.sitemaps.org/schemas/sitemap/0.9'}
#
#         try:
#             # ✅ Proper XML parsing
#             root = etree.fromstring(response.body)
#             loc_elements = root.xpath('//ns:loc', namespaces=namespaces)
#
#             self.logger.info(f"Found {len(loc_elements)} URLs in sitemap: {response.url}")
#
#             for loc in loc_elements:
#                 url = loc.text.strip()
#
#                 # ✅ Make sure Mongo key is consistent
#                 self.category_input.update_one(
#                     {"ProductUrl": url},
#                     {"$set": {"ProductUrl": url, "Status": "Pending"}},
#                     upsert=True
#                 )
#
#                 self.logger.debug(f"Inserted URL: {url}")
#
#         except Exception as e:
#             self.logger.error(f"Error parsing {response.url}: {e}")
#
#     def close(spider: Spider, reason: str) -> Union[Deferred, None]:
#         print("Spider Closing....")
#
#
# if __name__ == '__main__':
#     # process = CrawlerProcess(get_project_settings())
#     # process.crawl(WoolworthsSpider)
#     # process.start()
#     from scrapy.cmdline import execute
#
#     execute('scrapy crawl newworld_category -a retailer=newworld -a region=nz'.split())
#
