import json
from scrapy.selector import Selector
import scrapy
from datetime import datetime
from Common_Modual.common_functionality import *
from pymongo import MongoClient
from datetime import datetime
from dateutil.relativedelta import relativedelta, TU
from dateutil.relativedelta import relativedelta, MO
# next_tuesday = (datetime.today() + relativedelta(weekday=TU(0))).date()
# Today1 = (datetime.today() + relativedelta(weekday=MO(1))).date()
Today1 = datetime.today().date()
headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
    'cache-control': 'max-age=0',
    # 'if-none-match': 'W/"534162df9b0f63d68a2a1206d58695e7"',
    'priority': 'u=0, i',
    'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    'cookie': '_fbp=fb.2.1751865762792.152790094849720456; _hjSessionUser_5092773=eyJpZCI6ImJjMWUzMWJkLTM4NGItNTZjNC04ZGI2LTNjZWE5M2YxYThkNSIsImNyZWF0ZWQiOjE3NTE4NjU3NjMxMTksImV4aXN0aW5nIjp0cnVlfQ==; _ga_WSW2V455GF=GS2.1.s1757072705$o9$g0$t1757072705$j60$l0$h316656825; _session_id=UZNQPuAlhv0%2FgCoaP7KfDeZqLCergrlBPhG43%2B%2FJWVN0I%2FNKhkZ1%2Bj3f4%2FFEutDiVvH%2BA2CmFw47%2Fd1tqhBAQpZzAg%2FXE4GTXCUwdxoH6yQand0HgKkq9TRyTXrcq4RSkS4Ag%2BsPNVi9m9dUjwCEQrVC%2FRwsfX7byfVzq2Q2E%2FrBdsYdnpNZVa8%2F34k%2BEl6R2BsHIhnoTnsICdmVmRrtuxgVROEjsrm%2FWckvLriA0dtjxrxQq7XcSap8cFmC2YXETTLhKCs5xIWyuH3vIxySlWx9sR6xArQjGGwUCEIWSnQg6s3QeDPHHrBUE4aLQYpf%2Fv7sE8%2FqCow2KvPjvmccj9bZU%2F294FMtnWK69oGbuBsk9FzU6KKOdTQAPDc9dbl9vA%2BODG02wup8C3uXCxGpIQfuQmBmPZylwxpGARvfd6gMUNJunx7MPV4%3D--jc7q2JTMSzZ4WSd8--IpnJoDTpY6Agj3oRT1ucNQ%3D%3D; _ga_T49B3XEG45=GS2.1.s1758604932$o10$g0$t1758604932$j60$l0$h0; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A197e356219bfe1-0187f939d18bc28-26011e51-144000-197e356219bfe1%22%2C%22%24device_id%22%3A%20%22197e356219bfe1-0187f939d18bc28-26011e51-144000-197e356219bfe1%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; _ga=GA1.3.1010276944.1751865762; _gid=GA1.3.2094242737.1758604935; _gat_UA-116537812-11=1; _hjSession_5092773=eyJpZCI6IjNmOWJlNjg0LTgwNTctNDNhZi1iZjdkLWUwNDRlNDY0MjEyOSIsImMiOjE3NTg2MDQ5MzU3NzksInMiOjAsInIiOjAsInNiIjowLCJzciI6MCwic2UiOjAsImZzIjowLCJzcCI6MH0=',
}

class drakesPDPSpider(scrapy.Spider):
    name = "drakes_pdp"

    def __init__(self, retailer, region, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.retailer = retailer.lower()
        self.region = region.lower()
        self.today = Today1.strftime("%Y_%m_%d")

        # One-time Mongo connection
        mongo_uri = "mongodb://localhost:27017"
        db_name = f"pricemate_eshop_drakes_au"

        self.mongo_client = MongoClient(mongo_uri)
        self.db = self.mongo_client[db_name]
        self.category_input = self.db[f"category_urls_{self.today}"]

        coll_list = self.db.list_collection_names()
        if f'Product_Data_{self.today}' not in coll_list:
            self.category_input.update_many({}, {"$set": {"Status": "Pending"}})

        self.product_table = self.db[f"Product_Data_{self.today}"]

        self.product_table.create_index("ProductCode", unique=True)
        self.category_input.create_index("cat_url", unique=True)
        self.limit = 30

    def start_requests(self):
        pending_products = self.category_input.find({"Status": "Pending"})
        for product in pending_products:
            url = product["cat_url"]
            proxy = "http://21ed11ef5c872bc7727680a52233027db4578a0e:@api.zenrows.com:8001"

            proxies = {"http": proxy, "https": proxy}
            yield scrapy.Request(
                url=url,
                callback=self.parse_pdp,
                headers=headers,
                meta={"mongo_id": product["_id"],"proxy": proxies['http'], "cat_url": url}
            )

    def parse_pdp(self, response):
        mongo_id = response.meta["mongo_id"]
        product_url = response.meta["cat_url"]

        selector = Selector(text=response.text)
        main = selector.xpath('//div[@class="mfl-shopfloor"]')
        name = main.xpath('//h1[@class="ProductDetail__Title"]//text()').get()
        name = name.strip()
        size = main.xpath('//span[@class="weak"]//text()').get()
        price_raw = main.xpath('//span[@class="ProductDetail__Price__Sell"]//text()').get()
        price_clean = price_raw.replace('$', '').strip()
        price = float(price_clean)
        was_price_raw = main.xpath('//span[@class="ProductDetail__Price__Was"]/span//text()').get()

        if was_price_raw:
            # Extract only the numeric part using regex
            match = re.search(r"\$?(\d+\.\d{2})", was_price_raw)
            if match:
                was_price = float(match.group(1))
            else:
                was_price = None
        else:
            was_price = None

        per_unit_price = main.xpath(
            '//span[contains(@class, "ProductDetail__Price__UnitPricing--UnitPrice")]/text()').get()
        url_key = product_url.split('/lines/')[-1]
        script_texts = selector.xpath('//script[contains(., "window.gtmDataLayer")]/text()').getall()

        item_ids = []

        for script in script_texts:
            # Extract JSON-like data from the script text
            match = re.search(r'window\.gtmDataLayer\s*=\s*(\[\{.*?\}\]);', script, re.DOTALL)
            if match:
                json_text = match.group(1)
                try:
                    data = json.loads(json_text)
                    for item in data[0].get('ecommerce', {}).get('items', []):
                        item_id = item.get('item_id')
                        if item_id:
                            item_ids.append(item_id)
                        category_parts = []
                        for i in range(1, 5):  # item_category, item_category2, item_category3, item_category4
                            key = "item_category" if i == 1 else f"item_category{i}"
                            value = item.get(key)
                            if value:
                                category_parts.append(value)

                        # Join with >
                        category_hierarchy = " > ".join(category_parts)
                        print(f"Category Hierarchy: {category_hierarchy}")
                except Exception as e:
                    print("Failed to parse gtmDataLayer JSON.", {e})

        print(f"Found item IDs: {item_ids}")
        image = main.xpath('//img[@class="product_image"]/@src').get()
        texts = main.xpath(
            "//div[contains(@class, 'talker__stickers')]//span[contains(@class, 'talker__sticker__label')]//text()").getall()

        clean_texts = [t.strip() for t in texts if t.strip()]
        offer_info = ' '.join(clean_texts)
        json_text = selector.xpath("//script[@type='application/ld+json']/text()").get()

        if json_text:
            try:
                data = json.loads(json_text)

                availability_url = data.get('offers', {}).get('availability', '')

                stock_status = availability_url.endswith('InStock')

                print(f"Stock status: {stock_status}")
            except json.JSONDecodeError:
                print("Failed to parse JSON-LD.")
        else:
            print("No JSON-LD found.")
        category = main.xpath('//div[@class="ProductDetail__MoreInfo"]//a//text()').get()
        if was_price is None or was_price == price:
            rrp_price = price
        else:
            rrp_price = was_price
        Items = {"Name": name, "Promo_Type": "", "Price": price, "per_unit_price": per_unit_price,
                 "WasPrice": was_price,
                 "Offer_info": offer_info, "Pack_size": size, "Barcode": "",
                 "Images": image,
                 "ProductURL": product_url, "is_available": stock_status,
                 "Status": "Done", "ParentCode": "", "ProductCode": item_ids[0],
                 "retailer_name": "Drakes",
                 "Category_Hierarchy": category_hierarchy, "Brand": "", "RRP": rrp_price}
        print(Items)

        if Items:
            self.product_table.insert_one(Items)  # Changed from insert_many
            print("Data Inserted")
            self.category_input.update_one({"_id": mongo_id}, {"$set": {"Status": "Done"}})
        else:
            self.category_input.update_one({"_id": mongo_id}, {"$set": {"Status": "Not_found"}})



if __name__ == "__main__":
    from scrapy.cmdline import execute
    execute("scrapy crawl drakes_pdp -a retailer=drakes -a region=au".split())
