from typing import Union
import scrapy
from datetime import datetime
from Common_Modual.common_functionality import *
from lxml import etree
from pymongo import MongoClient
from scrapy import Spider
from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
from twisted.internet.defer import Deferred
from datetime import datetime
from dateutil.relativedelta import relativedelta, TU
from dateutil.relativedelta import relativedelta, MO
# next_tuesday = (datetime.today() + relativedelta(weekday=TU(0))).date()
# Today1 = (datetime.today() + relativedelta(weekday=MO(1))).date()
Today1 = datetime.today().date()
headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
    'cache-control': 'max-age=0',
    # 'if-none-match': 'W/"534162df9b0f63d68a2a1206d58695e7"',
    'priority': 'u=0, i',
    'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    'cookie': '_session_id=crtslKTh3pxV0R4%2FXUc5pAPZfyHtpoa20quZC3kUUDIBkTPvLdd6FYKDxkviYAAFgrBR7neAFcMORueK%2BFbayw0JqrNKNVkmyNCi80887upJuohm0qQEnr%2BJ%2Bw5dKbb6izKxN5z61DqhJwW7VX%2Ff6WTKhotgmp3SYbDMogznRGemlzhcCclDjJWv8j3VzHZckB0eygdAOBrGkvV4%2BMptdZQhHsItOkkD6bghitX%2Bt58yE0P7mP2MF9hASq%2FpdqExVuY1lcgffUyigwwqmrHUHLUeIfxaflVn1H11IGzpNOmHX2tF53b6hoVnydPl--nBJE5ZUmd9kKB2%2BE--b6fJYqrbvfTC1jV%2FPzqmlQ%3D%3D',
}






class drakesSpider(scrapy.Spider):
    name = "drakes_category"

    # allowed_domains = ["woolworths.com.au"]

    # start_urls = ["https://www.woolworths.com.au/shop/browse"]

    def __init__(self, retailer, region, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.retailer = retailer
        self.region = region
        self.today = Today1.strftime("%Y_%m_%d")

        # One-time Mongo connection
        mongo_uri = "mongodb://localhost:27017"
        db_name = f"pricemate_eshop_drakes_au"

        self.mongo_client = MongoClient(mongo_uri)
        self.db = self.mongo_client[db_name]
        self.category_input = self.db[f"category_urls_{self.today}"]

        coll_list = self.db.list_collection_names()
        if f'Product_Data_{self.today}' not in coll_list:
            self.category_input.update_many({}, {"$set": {"Status": "Pending"}})

        self.product_table = self.db[f"Product_Data_{self.today}"]

        self.product_table.create_index("ProductCode", unique=True)
        self.category_input.create_index("cat_url", unique=True)
        self.limit = 30

    def start_requests(self):
        proxy = "http://21ed11ef5c872bc7727680a52233027db4578a0e:@api.zenrows.com:8001"

        proxies = {"http": proxy, "https": proxy}
        main_cat_url = "https://018.drakes.com.au/sitemap.xml"

        yield scrapy.Request(
            main_cat_url, headers=headers,
            callback=self.get_all_category,
            meta={"proxy": proxies['https']}

        )

    def get_all_category(self, response):
        namespaces = {'ns': 'http://www.sitemaps.org/schemas/sitemap/0.9'}

        # Parse sitemap XML with lxml
        root = etree.fromstring(response.body)
        loc_elements = root.xpath('//ns:loc', namespaces=namespaces)

        for loc in loc_elements:
            url = loc.text.strip()

            if '/lines/' in url:
                # Insert into your database
                self.category_input.update_one(
                    {"cat_url": url},
                    {"$set": {"cat_url": url, "Status": "Pending"}},
                    upsert=True
                )
                self.logger.info(f"Inserted: {url}")

                # Optionally: follow the product page

            else:
                self.logger.info(f"Skipped (not a product URL): {url}")







    def close(spider: Spider, reason: str) -> Union[Deferred, None]:
        print("Spider Closing....")


if __name__ == '__main__':
    # process = CrawlerProcess(get_project_settings())
    # process.crawl(WoolworthsSpider)
    # process.start()
    from scrapy.cmdline import execute

    execute('scrapy crawl drakes_category -a retailer=drakes -a region=au'.split())

