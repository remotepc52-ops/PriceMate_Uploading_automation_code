import json
from typing import Union
import scrapy
from Common_Modual.common_functionality import *
from pandas.core.strings.accessor import cat_core
from pymongo import MongoClient
from scrapy import Spider
from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
from twisted.internet.defer import Deferred
from datetime import datetime
from dateutil.relativedelta import relativedelta, TU
from dateutil.relativedelta import relativedelta, MO
# next_tuesday = (datetime.today() + relativedelta(weekday=TU(0))).date()
# Today1 = (datetime.today() + relativedelta(weekday=MO(1))).date()
Today1 = datetime.today().date()
headers = {
    'sec-ch-ua-platform': '"Windows"',
    'Referer': '',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
}



class AldiSpider(Spider):
    name = "aldi_category"

    def __init__(self, retailer, region, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.retailer = retailer
        self.region = region
        self.today = Today1.strftime("%Y_%m_%d")

        mongo_uri = "mongodb://localhost:27017"
        # Use lowercase db name to avoid case conflicts
        db_name = f"pricemate_eshop_aldi_au"

        self.mongo_client = MongoClient(mongo_uri)
        self.db = self.mongo_client[db_name]
        self.category_input = self.db[f"category_urls_{self.today}"]

        coll_list = self.db.list_collection_names()
        if f'Product_Data_{self.today}' not in coll_list:
            self.category_input.update_many({}, {"$set": {"Status": "Pending"}})

        self.product_table = self.db[f"Product_Data_{self.today}"]
        self.product_table.create_index("ProductCode", unique=True)
        self.category_input.create_index("sku", unique=True)

        self.limit = 30

    def start_requests(self):
        offset = 0
        yield self.make_request(offset)

    def make_request(self, offset):
        main_cat_url = (
            f"https://api.aldi.com.au/v3/product-search"
            f"?currency=AUD&serviceType=walk-in&limit={self.limit}&offset={offset}"
            f"&getNotForSaleProducts=1&sort=relevance&testVariant=A&servicePoint=G452"
        )
        return scrapy.Request(
            main_cat_url,
            headers=headers,
            callback=self.get_all_category,
            meta={"offset": offset}
        )

    def get_all_category(self, response):
        if response.status != 200:
            self.logger.warning(f"⚠️ API Error: {response.status} for {response.url}")
            return

        data = json.loads(response.text)

        # Extract product list
        product_list = data.get("data", [])

        # Extract pagination info
        pagination = data.get("meta", {}).get("pagination", {})
        current_offset = pagination.get("offset", 0)
        total_count = pagination.get("totalCount", 0)

        # Process product data
        for product in product_list:
            sku = product.get("sku")
            slug = product.get("urlSlugText")
            if not sku or not slug:
                continue

            product_url = f"https://www.aldi.com.au/product/{slug}-{sku}"
            entry = {
                "sku": sku,
                "ProductUrl": product_url,
                "Status": "Pending"
            }

            try:
                self.category_input.insert_one(entry)
                self.logger.info(f"✅ Inserted: {product_url}")
            except Exception as e:
                self.logger.warning(f"⚠️ Could not insert {sku}: {e}")

        # Prepare next offset
        next_offset = current_offset + self.limit
        if next_offset < total_count:
            next_url = (
                f"https://api.aldi.com.au/v3/product-search"
                f"?currency=AUD&serviceType=walk-in&limit={self.limit}&offset={next_offset}"
                f"&getNotForSaleProducts=1&sort=relevance&testVariant=A&servicePoint=G452"
            )

            self.logger.info(f"➡️ Crawling next offset: {next_offset}/{total_count}")
            yield scrapy.Request(
                url=next_url,
                headers=headers,
                callback=self.get_all_category,
                meta={"offset": next_offset}
            )
        else:
            self.logger.info(f"✅ Finished crawling. Total: {total_count} products.")

    def close(self, reason: str) -> Union[Deferred, None]:
        print("Spider Closing....")


if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute('scrapy crawl aldi_category -a retailer=aldi -a region=au'.split())