import json
import scrapy

from pymongo import MongoClient

from dateutil.relativedelta import relativedelta, TU
from datetime import datetime
from dateutil.relativedelta import relativedelta, MO
# next_tuesday = (datetime.today() + relativedelta(weekday=TU(0))).date()
# Today1 = (datetime.today() + relativedelta(weekday=MO(1))).date()
Today1 = datetime.today().date()
headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7',
    'cache-control': 'max-age=0',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
    # 'cookie': '_gcl_au=1.1.1840274494.1751618328; _tt_enable_cookie=1; _ttp=01JZA9D6TB8GYVQCH0740E1HRP_.tt.2; _fbp=fb.2.1751618332079.367526310195327529; rxVisitor=1752144850656JI9JS41PO4NDTNTMV2VMRIQE5U5EI2VI; at_check=true; AMCVS_95446750574EBBDF7F000101%40AdobeOrg=1; AMCV_95446750574EBBDF7F000101%40AdobeOrg=179643557%7CMCIDTS%7C20280%7CMCMID%7C83111691603227384562751674196356491311%7CMCAAMLH-1752749652%7C8%7CMCAAMB-1752749652%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1752152052s%7CNONE%7CMCAID%7CNONE%7CvVersion%7C5.5.0; dtSa=-; tealCookieSyncFlag=true; s_vnc365=1783680856955%26vn%3D4; s_ivc=true; s_cc=true; tfpsi=17ea0ff2-f4f6-4ad5-8639-22d0c316442a; dtPC=-37$144850646_554h-vFPUGHVCVOBFAPMBEMUPLUAPIMJESHHAC-0e0; dtCookie=v_4_srv_1_sn_98UU7N1GSS55J1G43TI5HCRQ77IPKJ1O_app-3A32ce7df317f98c72_0_ol_0_perc_100000_mul_1; rxvt=1752146663704|1752144850657; s_sq=%5B%5BB%5D%5D; s_nr365=1752145519166-Repeat; gpv_pn=Champagne%20Brut%20750ml; mbox=PC#1bf58fd79faf40cca11750dc43f696ce.36_0#1815390320|session#1c6b9fc7d0834fd096a0736253899181#1752147380; ttcsid=1752144858112::6Aqy3W0WgKhzn9R3gN1J.4.1752145519367; ttcsid_CR61HVBC77U9N3BNSMUG=1752144858112::SSBsUx2GnHQWrIlOSTD1.4.1752145519582; TEAL=v:4197d496a84355828696757308868576f7918675960$t:1752147319865$sn:4$en:9$s:1752144857710%3Bexp-sess; mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel=%7B%22distinct_id%22%3A%20%22%24device%3A197d49691ca5b1-0b08df78fa027b8-26011e51-144000-197d49691cb5b1%22%2C%22%24device_id%22%3A%20%22197d49691ca5b1-0b08df78fa027b8-26011e51-144000-197d49691cb5b1%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D',
}

class AldiPDPSpider(scrapy.Spider):
    name = "aldi_pdp"

    def __init__(self, retailer, region, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.retailer = retailer
        self.region = region
        self.today = Today1.strftime("%Y_%m_%d")

        mongo_uri = "mongodb://localhost:27017"
        # Use lowercase db name to avoid case conflicts
        db_name = f"pricemate_eshop_aldi_au"

        self.mongo_client = MongoClient(mongo_uri)
        self.db = self.mongo_client[db_name]
        self.category_input = self.db[f"category_urls_{self.today}"]

        coll_list = self.db.list_collection_names()
        if f'Product_Data_{self.today}' not in coll_list:
            self.category_input.update_many({}, {"$set": {"Status": "Pending"}})

        self.product_table = self.db[f"Product_Data_{self.today}"]
        self.product_table.create_index("ProductCode", unique=True)
        self.category_input.create_index("sku", unique=True)

        self.limit = 30

    def start_requests(self):
        pending_products = self.category_input.find({"Status": "Pending"})
        for product in pending_products:
            doc_id = product["_id"]
            sku = product["sku"]
            product_url = product.get("ProductUrl")

            api_url = f"https://api.aldi.com.au/v2/products/{sku}?servicePoint=G452&serviceType=walk-in"

            yield scrapy.Request(
                url=product_url,  # First fetch HTML page
                callback=self.parse_html_pdp,
                headers=headers,
                meta={"sku": sku, "doc_id":doc_id, "ProductUrl": product_url, "api_url": api_url}
            )

    def parse_html_pdp(self, response):
        sku = response.meta["sku"]
        doc_id = response.meta["doc_id"]
        product_url = response.meta["ProductUrl"]
        api_url = response.meta["api_url"]

        ld_json_scripts = response.xpath('//script[@type="application/ld+json"]/text()').getall()
        stock_status = False
        joined_image_urls = ""

        for script in ld_json_scripts:
            try:
                data = json.loads(script.strip())

                # sometimes it's a list of objects, sometimes a single dict
                candidates = data if isinstance(data, list) else [data]

                for obj in candidates:
                    if not isinstance(obj, dict):
                        continue

                    if obj.get("@type") == "Product":
                        # Extract images
                        images = obj.get("image", [])
                        if isinstance(images, list):
                            joined_image_urls = " | ".join(images)
                        elif isinstance(images, str):
                            joined_image_urls = images

                        # Extract stock status
                        offers = obj.get("offers", {})
                        if isinstance(offers, dict):
                            if "InStock" in offers.get("availability", ""):
                                stock_status = True
            except Exception as e:
                print(f"⚠️ Error parsing ld+json: {e}")
        srcsets = response.xpath('//div[@class="scroll-container__slides"]//img/@srcset').getall()

        # urls = []
        # for srcset in srcsets:
        #     parts = [u.strip() for u in srcset.split(",")]
        #     for p in parts:
        #         if p.endswith("250w"):
        #             urls.append(p.split()[0])  # keep only the URL
        #
        # # Join all URLs into one string separated by " | "
        # joined_image_urls = " | ".join(urls)
        yield scrapy.Request(
            url=api_url,
            callback=self.parse_pdp,
            headers=headers,
            meta={
                "sku": sku,
                "doc_id": doc_id,
                "ProductUrl": product_url,
                "stock_status": stock_status,
                "joined_image_urls": joined_image_urls,
            },
        )


    def parse_pdp(self, response):
        sku = response.meta["sku"]
        doc_id = response.meta["doc_id"]
        product_url = response.meta["ProductUrl"]
        stock_status = response.meta["stock_status"]
        joined_image_urls = response.meta.get("joined_image_urls", "")

        product = response.json()
        product_data = product.get("data")
        name = product_data.get("name")
        pack_size = product_data.get("sellingSize")
        price = product_data.get("price").get("amountRelevantDisplay")
        main_price = price.replace("$", "").strip()
        per_unit_raw = product_data.get("price").get("comparisonDisplay")
        per_unit_price = per_unit_raw #.replace("$", "").strip()
        category = product_data.get("categories", [])
        cat_names = [main_cat.get("name", "").strip() for main_cat in category if main_cat.get("name")]
        joined_cat_name = " > ".join(cat_names)
        brand_name = product_data.get("brandName")
        if brand_name:
            brand_name = brand_name.title()
            print(brand_name)

        Items = {"Name": name, "Promo_Type": "", "Price": main_price, "per_unit_price": per_unit_price,
                 "WasPrice": "",
                 "Offer_info": "", "Pack_size": pack_size, "Barcode": "",
                 "Images": joined_image_urls,
                 "ProductURL": product_url, "is_available":stock_status,
                 "Status": "Done", "ParentCode": "", "ProductCode": sku,
                 "retailer_name": "Aldi ",
                 "Category_Hierarchy": joined_cat_name, "Brand": brand_name, "RRP": main_price}
        print(Items)
        try:
            self.product_table.insert_one(Items)

        except Exception as e:
            print(f"⚠️ DB Insert Error: {e}")
        self.category_input.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})

if __name__ == "__main__":
    from scrapy.cmdline import execute
    execute("scrapy crawl aldi_pdp -a retailer=aldi -a region=au".split())
