import datetime
from Common_Modual.common_functionality import *
import pymongo
import os
from dateutil.relativedelta import relativedelta, TU

next_tueday = (datetime.datetime.today() + relativedelta(weekday=TU(0))).date()
def configration(website, region):
    today = next_tueday.strftime("%Y_%m_%d")

    conn = pymongo.MongoClient("mongodb://localhost:27017/")
    db = conn[f"PriceMate_{website}"]

    category_input = db['Category_Input']
    coll_list = db.list_collection_names()
    if f'Product_Data_{today}' not in coll_list:
        category_input.update_many({}, {"$set": {"Status":"Pending"}})

    product_data = db[f'Product_Data_{today}']

    product_data.create_index("ProductCode", unique = True)
    category_input.create_index("CategoryId", unique = True)


    # Base path
    base_path = f"D:\\Kamaram\\Crawl_Data_Collection\\PriceMate\\{today}\\{website}"

    # Define paths for different file types
    html_path = os.path.join(base_path, "HTML_Files")
    excel_path = os.path.join(base_path, "Excel_Files")

    # Create directories
    os.makedirs(html_path, exist_ok=True)
    os.makedirs(excel_path, exist_ok=True)

    print(f"HTML files path: {html_path}")
    print(f"Excel files path: {excel_path}")