import scrapy
from pricemate.items import ProductItem

class LazadaMySpider(scrapy.Spider):
    name = "woolworths_au"
    allowed_domains = ["woolworths.com.au"]

    def start_requests(self):
        yield scrapy.Request(
            "https://www.woolworths.com.au/shop/browse/drinks/soft-drinks",
            callback=self.parse
        )

    def parse(self, response):
        for product in response.xpath('//div[contains(@class, "shelfProductTile-root")]'):
            item = ProductItem()
            item["ProductURL"] = response.urljoin(product.xpath(".//a/@href").get())
            item["Name"] = product.xpath(".//a/text()").get()
            item["Price"] = product.xpath(".//span[contains(@class,'price')]/text()").get()
            item["WasPrice"] = product.xpath(".//span[contains(text(),'Was')]/following-sibling::text()").get()
            item["Brand"] = product.xpath(".//span[contains(@class,'brand')]/text()").get()
            item["Promo_Type"] = "Discount" if product.xpath(".//span[contains(text(),'Save')]") else None
            item["is_available"] = True
            yield item
