import os, hashlib, json, time

from scrapy import Selector
from scrapy.http import HtmlResponse
from datetime import datetime
from pymongo import MongoClient
import requests
from lxml import html as lxml_html

class HtmlCacheMiddleware:
    def __init__(self, cache_dir, retailer, region, max_retry=3):
        self.cache_dir = cache_dir
        self.retailer = retailer
        self.region = region
        self.max_retry = max_retry
        os.makedirs(cache_dir, exist_ok=True)

        self.mongo_client = MongoClient("mongodb://localhost:27017")
        self.db = self.mongo_client[f"pricemate_{retailer}_{region}"]
        self.collection = self.db[f"html_cache_logs".lower()]

    @classmethod
    def from_crawler(cls, crawler):
        spider = crawler.spider
        return cls(
            cache_dir=cls.get_cache_path(spider),
            retailer=getattr(spider, 'retailer', 'default'),
            region=getattr(spider, 'region', 'unknown'),
            max_retry=getattr(spider, 'max_retry', 3)
        )

    @staticmethod
    def get_cache_path(spider):
        # today = datetime.today().strftime('%Y-%m-%d')
        today = getattr(spider, 'today', 'default')
        retailer = getattr(spider, 'retailer', 'default')
        region = getattr(spider, 'region', 'unknown')
        base_path = f"D:\\Kamaram\\Crawl_Data_Collection\\Master PriceMate\\{today}\\{retailer}_{region}"
        return os.path.join(base_path, "HTMLs")


    # def validate_response(self, content, should_be=None, not_should_be=None, xpath_should_be=None, xpath_not_should_be=None):
    def validate_response(self, response_text, should_be, not_should_be, xpath_not_should_be, xpath_should_be):
        """
        Validate response text based on presence and absence of specific values.

        :param response_text: The response text to be validated.
        :param should_be: String or list of strings that must be present in the response text.
        :param not_should_be: String or list of strings that must not be present in the response text.
        :return: True if validation passes, False otherwise.
        """
        selector_response = Selector(text=response_text)
        if should_be:
            for val in should_be:
                if '|' in val:
                    if not any(sub_val in response_text for sub_val in val.split('|')):
                        return False
                else:
                    if val not in response_text:
                        return False
        if xpath_should_be:
            if isinstance(xpath_should_be, str):
                xpath_should_be = [xpath_should_be]
            if not all(selector_response.xpath(val) for val in xpath_should_be):
                return False

        if xpath_not_should_be:
            if isinstance(xpath_not_should_be, str):
                xpath_not_should_be = [xpath_not_should_be]
            if not all(not selector_response.xpath(val) for val in xpath_not_should_be):
                return False

        if not_should_be:
            if isinstance(not_should_be, str):
                not_should_be = [not_should_be]
            if not all(val not in response_text for val in not_should_be):
                return False

        return True


    def process_response(self, request, response, spider):
        url = request.url
        method = request.method.upper()
        payload = request.body.decode('utf-8') if request.body else ''
        cache_key = hashlib.md5((url + payload).encode('utf-8')).hexdigest()
        cache_file = os.path.join(self.cache_dir, f"{cache_key}.html")

        # If file already exists, return cached response
        if os.path.exists(cache_file):
            spider.logger.info(f"[Cache Hit] Returning from file: {cache_file}")
            with open(cache_file, "r", encoding="utf-8") as f:
                cached_content = f.read()
            return HtmlResponse(
                url=url,
                body=cached_content,
                encoding='utf-8',
                request=request
            )

        # Validate original Scrapy response
        should_be = request.meta.get('should_be')
        not_should_be = request.meta.get('not_should_be')
        xpath_should_be = request.meta.get('xpath_should_be')
        xpath_not_should_be = request.meta.get('xpath_not_should_be')

        if response.status == 200 and self.validate_response(response.text, should_be, not_should_be, xpath_should_be, xpath_not_should_be):
            with open(cache_file, "w", encoding="utf-8") as f:
                f.write(response.text)

            self.collection.update_one(
                {"url_hash": cache_key},
                {
                    "$set": {
                        "url": url,
                        "path": cache_file,
                        "timestamp": datetime.utcnow(),
                        "status": response.status,
                        "spider": spider.name,
                        "retailer": spider.retailer,
                        "region": self.region,
                        "source": "html",
                        "retried": False
                    }
                },
                upsert=True
            )
            return response

        # ❌ Invalid response, fallback retry via requests
        spider.logger.warning(f"❌ Invalid Scrapy response for: {url}, retrying via requests")

        headers = request.headers.to_unicode_dict()
        proxies = request.meta.get('proxies')
        cookies = request.cookies
        verify = request.meta.get('verify', True)
        timeout = request.meta.get('timeout', 15)

        retry_count = 0
        while retry_count < self.max_retry:
            retry_count += 1
            try:
                if method == 'GET':
                    r = requests.get(url, headers=headers, cookies=cookies, timeout=timeout, verify=verify, proxies=proxies)
                else:
                    r = requests.post(url, headers=headers, data=request.body, cookies=cookies, timeout=timeout, verify=verify, proxies=proxies)

                if r.status_code == 200 and self.validate_response(r.text, should_be, not_should_be, xpath_should_be, xpath_not_should_be):
                    with open(cache_file, "w", encoding="utf-8") as f:
                        f.write(r.text)

                    self.collection.update_one(
                        {"url_hash": cache_key},
                        {
                            "$set": {
                                "url": url,
                                "path": cache_file,
                                "timestamp": datetime.utcnow(),
                                "status": r.status_code,
                                "spider": spider.name,
                                "region": self.region,
                                "source": "html",
                                "retried": True
                            }
                        },
                        upsert=True
                    )
                    spider.logger.info(f"✅ Valid response saved after retry {retry_count}")
                    return HtmlResponse(
                        url=url,
                        body=r.text,
                        encoding='utf-8',
                        request=request
                    )

            except Exception as e:
                spider.logger.error(f"Retry {retry_count} failed for {url}: {e}")
                time.sleep(5)

        spider.logger.error(f"❌ Final failure after {self.max_retry} retries for {url}")
        return response  # return original (invalid) response if all retries fail
