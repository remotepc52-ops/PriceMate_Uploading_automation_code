# File: dashboard/app.py

from flask import Flask, render_template, request
from pymongo import MongoClient
import os

app = Flask(__name__)

# MongoDB config
MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017")
client = MongoClient(MONGO_URI)
db = client["pricemate"]

@app.route("/")
def home():
    # Get all retailer collections
    collections = db.list_collection_names()
    summary = []
    for col in collections:
        if col.endswith("_products"):
            count = db[col].count_documents({})
            done = db[col].count_documents({"is_available": True})
            summary.append({
                "retailer": col.replace("_products", ""),
                "total": count,
                "available": done,
                "unavailable": count - done
            })
    return render_template("dashboard.html", summary=summary)

@app.route("/retailer/<name>")
def view_retailer(name):
    collection = db[f"{name}_products"]
    docs = list(collection.find({}, {"_id": 0, "Name": 1, "Price": 1, "Offer_info": 1, "is_available": 1}).limit(100))
    return render_template("retailer_detail.html", name=name, products=docs)

if __name__ == '__main__':
    app.run(debug=True, port=5002)
