# File: dashboard/app.py

import streamlit as st
import pandas as pd
from pymongo import MongoClient

st.set_page_config(page_title="Crawl Dashboard", layout="wide")

# Connect to MongoDB
MONGO_URI = "mongodb://localhost:27017/"
client = MongoClient(MONGO_URI)
db = client["pricemate"]
status_col = db["crawl_status"]

# Load crawl status records
records = list(status_col.find().sort("ts", -1))

if not records:
    st.warning("No crawl status data found.")
    st.stop()

df = pd.DataFrame(records)

# Clean data
if '_id' in df.columns:
    df.drop(columns=['_id'], inplace=True)
if 'ts' in df.columns:
    df['ts'] = pd.to_datetime(df['ts'])

# Sidebar Filters
st.sidebar.title("Filters")
retailers = df['retailer'].unique().tolist()
selected_retailers = st.sidebar.multiselect("Retailer", options=retailers, default=retailers)
dates = df['date'].unique().tolist()
selected_dates = st.sidebar.multiselect("Date", options=dates, default=dates)

# Filtered view
filtered_df = df[(df['retailer'].isin(selected_retailers)) & (df['date'].isin(selected_dates))]

# Metrics
st.title("📊 Crawl Monitoring Dashboard")
st.markdown("---")
col1, col2, col3 = st.columns(3)
col1.metric("Total Crawls", len(filtered_df))
col2.metric("Unique Retailers", len(filtered_df['retailer'].unique()))
col3.metric("Total Records Exported", filtered_df['record_count'].sum())

st.markdown("---")

# Table view
st.subheader("📋 Crawl Summary Table")
st.dataframe(
    filtered_df.sort_values("ts", ascending=False).reset_index(drop=True),
    use_container_width=True
)

# Download links if any
st.markdown("### 📥 Exported Files")
for idx, row in filtered_df.iterrows():
    st.markdown(f"**{row['retailer']} ({row['date']})**")
    st.write(f"🔗 [Excel]({row['excel_file']})  |  🔗 [JSON]({row['json_file']})")
