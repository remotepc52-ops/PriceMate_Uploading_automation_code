import requests
from scrapy import signals


class TelegramNotifier:
    @classmethod
    def from_crawler(cls, crawler):
        ext = cls()
        crawler.signals.connect(ext.spider_closed, signal=signals.spider_closed)
        return ext

    def spider_closed(self, spider, reason):
        CHAT_ID = "-4804879093"

        text = f"✅ {spider.name} crawl done. Status: {reason}"
