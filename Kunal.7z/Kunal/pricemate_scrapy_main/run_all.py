from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
from pricemate.spiders.Woolworths.woolworths_au_category import WoolworthsSpider
from pricemate.spiders.lazada_my import LazadaMySpider

process = CrawlerProcess(get_project_settings())
process.crawl(WoolworthsSpider)
process.crawl(LazadaMySpider)
process.start()
