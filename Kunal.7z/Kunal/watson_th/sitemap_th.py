import requests
from lxml import etree
from rsa.cli import verify

from config import *

cookies = {
    'AKA_A2': 'A',
    'PIM-SESSION-ID': 'zAOBlqyUUxINYF2b',
    'ROUTE': '.jsapps-5875f56457-gcmmw',
    'bm_mi': 'D9CF44EDC1BC961C623F1C327A37370A~YAAQqyQ+F2mQWCabAQAARfXpdx4Lg/Py1nK2xhiJYjqxGh9/XLD73DZyQwuQxHLPBQc27FBkOHxZ0q1914+eHEoBTUW2rSxmROOohmwVgHsq7RNw6/GDDN2aCVxMwRtvVh3nzSZb61d5cKGfQettMK4twzeHE7qD5+oxrsiwiNDnew1zGZJ5q7cf5j79t/Xl2HFgsQN6P4R3MvtFcyvQrR6KraqzuBavre/1CR76oAqIicRRivFL0gZzGiv7qWWdaouT5nR/3LjkfC9s+7ePEhaKhcomV3Xko7ko8FPguVUXJcX9dAfJ28dtjo+61+zYDbmwRw==~1',
    'bm_sz': '7C60656CF5D87002706AC933289CCE6E~YAAQqyQ+F2uQWCabAQAARfXpdx7Gz6RvVyILz2dh3v5ClgMZgtPT/56jsayM5oQeBmU8qiBRX93dPwNHN0j0cBmqpg6cDszWra1oDM/uyADDMyB74CXWZhPaYJve/R/xXpjh3W225y/ZW+TVwOXarFJfn04nYQhkDRE44U6USSFxjj4QqWlEN5XQGDN/I6TYBVj0W13nfd7QAPtcsZ2zdIdGRL4khZnMFb9cgONY26r6HEmaqpl7PotMoSxlUea6YLZw99nPjo0rl7qa/WJgGfmeyXHjek56PdaUDzOm6ftFOyk+z0D3w3B0HYbLbceTnx+7my2CzmgDmiNJx1zLbacLTSl1Kk+E/9gNK6qVAa8Ny9bo8IwCBwIoUlzcNHvaB3kJ9G5QTu5jxMzIzH/RpnLaGyDCdM5SHrbcz4Z1D4NfJhg=~3687750~3555650',
    '_abck': '693EC4DB2A7048FF215A4611C6ADEF5A~0~YAAQqyQ+F32QWCabAQAAbvfpdw95pwiMhEae8NmR7RD3aPxhR4KEigOUY2xRBSapKMpQnAzoMrLSOiSeczobjQM260M+qllCgUKVzwwk6l7boKyStTDEGW8Wj3sFRTHSM/qOv/1MazhXg3Zq3cYhfpO8D0SKZ2Z+Edd5c30NjxFduZpCwzugr+zrqi3Du3bdlO140WkWpyDB7b1lQX3LQRbPpkMpzFo95iqoRhnsVeus70tWaKbmM5GIDIjKJig8OJgfdRTlwATirdShvJ4+qCvqYBghCOrz9s1sD1nSKpnaLSMEe+2qe+EOp0wh4Ox2m4IesEMnYy2zs4B0+whb/vquZG77E1iNzov+NClQHFYkaVzWrlHOe1Jv3PgKYb/yTv84IEi7AWdmPAhpsE3xnYjNF1LsA72HPwI5gVHSJKtnPN/dUMSuVO8RFoxDqjcxaP1M3q9sr5dzRGx6xmoVnjKxG3vPbFkZHqDifEhsVB3WGPujVawQGYH7Tw+oM/ChDHbTjpaC1fIDJYI9OTpR4IEqsEqCpsHjPzDn3gtOGezzj6W3TlLDoeDheM52eFZmdMHRD42/ezkx86L8hHAMJjxZQQ==~-1~-1~-1~AASAAAAE%2f%2f%2f%2f%2fwaeuVtzfe6AC0VowT8yOTiew+L6wPDAAwCHocoZxnLXEZRyruSgrAHggoKu1i9ZZENuGWv1~-1',
    'e2-language': 'en_TH',
    'language': 'en_TH',
    'langcode': 'en',
    'ak_bmsc': 'E3AD3B09752FE3F6292C4059653DC456~000000000000000000000000000000~YAAQJ03cF5KyfzCbAQAAGvzpdx6L/zGNwp/hrPXWcsMuGzxSMLDmZmmW8d4aZ45ib14AE0UurYSgBUzZo/hA7vSLwiG0uNq94gekVVEpFVteBFOL8v1MSOEAXPQvRHc5A5otybCk8GBd6YFqMrrLhdIB4FMnuvCvQtPeQGud717GpfiLF7mLa1QhJYJtRMQU9Q0+3kgKdzzTeSd80lxEew7oW2Eyn3PZUHYx4sF2rw4WRBLTz2lTIHH8TPM1XoO82HypRHJz5YA5vaIoO3rkuBrWuDPey//SgCGwTl+SggDWWfPNdUUqlF/7bFDDe/LtphZjsB+3kmEwe5OpH/tbufILoPb+4HBZi8BdFNPCn5eqAwBAbfplm0ag+MQd5YKnFFuSXX9i3UxmUCK8UFlP60gcxXJlMYbZIKSENwJB18TIjMHxILpnUpldRAS0bfGV1ABa/SRyMt69iRTSQXYTSJu8J4MjDrpNfCqddmjfHDj7nD5fbDsMQnwKK0E8uA==',
    'bm_sv': 'CFEC9E2D7019B6BE5F3AA9D9E4BEC647~YAAQJ03cFyyzfzCbAQAAdAnqdx6fkBAtOIyDsTIujSW2ymf6nE+o/XmJtNORFK8Tnj9Cvzcd63Sm3qJyDeQ8sLOTFMpuFfk6q3zh3fbuLjVJR84Jb4CDPU7d3Bt9f/Pln0yCsFwuvECCyXpJBSqd/0rwncACifLNI4K2UWSOx2nfYXRMcdHF9S6x6lRt7dc91nnTMDI17q1cUpPDo6tR4F6uvbE/q+P+eOPDbt47JKyKw/lFrKuxadtLkbf+GvbwgAeZkw==~1',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Thu+Jan+01+2026+10%3A26%3A28+GMT%2B0530+(India+Standard+Time)&version=202411.2.0&browserGpcFlag=0&isIABGlobal=false&hosts=&consentId=c32bbd0e-8f6a-424c-b5e3-d595d35633d3&interactionCount=1&isAnonUser=1&landingPath=NotLandingPage&groups=C0001%3A1%2CC0003%3A0%2CC0004%3A0&AwaitingReconsent=false',
}

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'cache-control': 'max-age=0',
    'if-none-match': '"0c461006cd726337215564a44e61cd922-gzip"',
    'priority': 'u=0, i',
    'sec-ch-ua': '"Google Chrome";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
    # 'cookie': 'AKA_A2=A; PIM-SESSION-ID=zAOBlqyUUxINYF2b; ROUTE=.jsapps-5875f56457-gcmmw; bm_mi=D9CF44EDC1BC961C623F1C327A37370A~YAAQqyQ+F2mQWCabAQAARfXpdx4Lg/Py1nK2xhiJYjqxGh9/XLD73DZyQwuQxHLPBQc27FBkOHxZ0q1914+eHEoBTUW2rSxmROOohmwVgHsq7RNw6/GDDN2aCVxMwRtvVh3nzSZb61d5cKGfQettMK4twzeHE7qD5+oxrsiwiNDnew1zGZJ5q7cf5j79t/Xl2HFgsQN6P4R3MvtFcyvQrR6KraqzuBavre/1CR76oAqIicRRivFL0gZzGiv7qWWdaouT5nR/3LjkfC9s+7ePEhaKhcomV3Xko7ko8FPguVUXJcX9dAfJ28dtjo+61+zYDbmwRw==~1; bm_sz=7C60656CF5D87002706AC933289CCE6E~YAAQqyQ+F2uQWCabAQAARfXpdx7Gz6RvVyILz2dh3v5ClgMZgtPT/56jsayM5oQeBmU8qiBRX93dPwNHN0j0cBmqpg6cDszWra1oDM/uyADDMyB74CXWZhPaYJve/R/xXpjh3W225y/ZW+TVwOXarFJfn04nYQhkDRE44U6USSFxjj4QqWlEN5XQGDN/I6TYBVj0W13nfd7QAPtcsZ2zdIdGRL4khZnMFb9cgONY26r6HEmaqpl7PotMoSxlUea6YLZw99nPjo0rl7qa/WJgGfmeyXHjek56PdaUDzOm6ftFOyk+z0D3w3B0HYbLbceTnx+7my2CzmgDmiNJx1zLbacLTSl1Kk+E/9gNK6qVAa8Ny9bo8IwCBwIoUlzcNHvaB3kJ9G5QTu5jxMzIzH/RpnLaGyDCdM5SHrbcz4Z1D4NfJhg=~3687750~3555650; _abck=693EC4DB2A7048FF215A4611C6ADEF5A~0~YAAQqyQ+F32QWCabAQAAbvfpdw95pwiMhEae8NmR7RD3aPxhR4KEigOUY2xRBSapKMpQnAzoMrLSOiSeczobjQM260M+qllCgUKVzwwk6l7boKyStTDEGW8Wj3sFRTHSM/qOv/1MazhXg3Zq3cYhfpO8D0SKZ2Z+Edd5c30NjxFduZpCwzugr+zrqi3Du3bdlO140WkWpyDB7b1lQX3LQRbPpkMpzFo95iqoRhnsVeus70tWaKbmM5GIDIjKJig8OJgfdRTlwATirdShvJ4+qCvqYBghCOrz9s1sD1nSKpnaLSMEe+2qe+EOp0wh4Ox2m4IesEMnYy2zs4B0+whb/vquZG77E1iNzov+NClQHFYkaVzWrlHOe1Jv3PgKYb/yTv84IEi7AWdmPAhpsE3xnYjNF1LsA72HPwI5gVHSJKtnPN/dUMSuVO8RFoxDqjcxaP1M3q9sr5dzRGx6xmoVnjKxG3vPbFkZHqDifEhsVB3WGPujVawQGYH7Tw+oM/ChDHbTjpaC1fIDJYI9OTpR4IEqsEqCpsHjPzDn3gtOGezzj6W3TlLDoeDheM52eFZmdMHRD42/ezkx86L8hHAMJjxZQQ==~-1~-1~-1~AASAAAAE%2f%2f%2f%2f%2fwaeuVtzfe6AC0VowT8yOTiew+L6wPDAAwCHocoZxnLXEZRyruSgrAHggoKu1i9ZZENuGWv1~-1; e2-language=en_TH; language=en_TH; langcode=en; ak_bmsc=E3AD3B09752FE3F6292C4059653DC456~000000000000000000000000000000~YAAQJ03cF5KyfzCbAQAAGvzpdx6L/zGNwp/hrPXWcsMuGzxSMLDmZmmW8d4aZ45ib14AE0UurYSgBUzZo/hA7vSLwiG0uNq94gekVVEpFVteBFOL8v1MSOEAXPQvRHc5A5otybCk8GBd6YFqMrrLhdIB4FMnuvCvQtPeQGud717GpfiLF7mLa1QhJYJtRMQU9Q0+3kgKdzzTeSd80lxEew7oW2Eyn3PZUHYx4sF2rw4WRBLTz2lTIHH8TPM1XoO82HypRHJz5YA5vaIoO3rkuBrWuDPey//SgCGwTl+SggDWWfPNdUUqlF/7bFDDe/LtphZjsB+3kmEwe5OpH/tbufILoPb+4HBZi8BdFNPCn5eqAwBAbfplm0ag+MQd5YKnFFuSXX9i3UxmUCK8UFlP60gcxXJlMYbZIKSENwJB18TIjMHxILpnUpldRAS0bfGV1ABa/SRyMt69iRTSQXYTSJu8J4MjDrpNfCqddmjfHDj7nD5fbDsMQnwKK0E8uA==; bm_sv=CFEC9E2D7019B6BE5F3AA9D9E4BEC647~YAAQJ03cFyyzfzCbAQAAdAnqdx6fkBAtOIyDsTIujSW2ymf6nE+o/XmJtNORFK8Tnj9Cvzcd63Sm3qJyDeQ8sLOTFMpuFfk6q3zh3fbuLjVJR84Jb4CDPU7d3Bt9f/Pln0yCsFwuvECCyXpJBSqd/0rwncACifLNI4K2UWSOx2nfYXRMcdHF9S6x6lRt7dc91nnTMDI17q1cUpPDo6tR4F6uvbE/q+P+eOPDbt47JKyKw/lFrKuxadtLkbf+GvbwgAeZkw==~1; OptanonConsent=isGpcEnabled=0&datestamp=Thu+Jan+01+2026+10%3A26%3A28+GMT%2B0530+(India+Standard+Time)&version=202411.2.0&browserGpcFlag=0&isIABGlobal=false&hosts=&consentId=c32bbd0e-8f6a-424c-b5e3-d595d35633d3&interactionCount=1&isAnonUser=1&landingPath=NotLandingPage&groups=C0001%3A1%2CC0003%3A0%2CC0004%3A0&AwaitingReconsent=false',
}
region = "th"

sitemaps = [
        f'https://www.watsons.co.th/sitemap_prd_en_01.xml'
    ]
namespaces = {'ns': 'http://www.sitemaps.org/schemas/sitemap/0.9'}

for sitemap_url in sitemaps:
    response = requests.get(sitemap_url, cookies=cookies, headers=headers,proxies=proxies,verify=False)
    print(f"Fetching {sitemap_url} → {response.status_code}")

    if response.status_code == 200:
        root = etree.fromstring(response.content)

        loc_elements = root.xpath('//ns:loc', namespaces=namespaces)

        for loc in loc_elements:
            url = loc.text.strip()
            search_data.update_one(
                {"url": url},
                {"$set": {"url": url, "Status": "Pending"}},
                upsert=True
            )
            print(f"Inserted: {url}")
    else:
        print(f"Failed to fetch sitemap {sitemap_url}. Status code: {response.status_code}")