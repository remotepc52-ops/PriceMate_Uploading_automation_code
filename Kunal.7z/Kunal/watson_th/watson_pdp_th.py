import json
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse

from config import *
def extract_size(size_string):
    try:
        size_string = size_string.strip()

        # Define the units regex part once to keep it consistent and clean
        # Added: pieces?, pcs?, pairs?
        units = r'(ml|mL|l|L|g|kg|oz|lb|packs?|pack|tablets?|capsules?|pieces?|pcs?|pairs?)'

        # 1️⃣ Look for patterns like "Size: 200ml" or "Pack Size: 2kg"
        pattern1 = fr'(?:Size|Pack Size)[:\s]*([\d.]+)\s*{units}'
        match = re.search(pattern1, size_string, re.IGNORECASE)
        if match:
            size_value = match.group(1)
            size_unit = match.group(2)
            return f"{size_value} {size_unit}"

        # 2️⃣ Look for things like "200ml", "2kg", "2 pieces", "(2 pieces)"
        # valid: "2 pieces", "2pcs", "2.5kg"
        pattern2 = fr'([\d.]+)\s*{units}'
        match = re.search(pattern2, size_string, re.IGNORECASE)
        if match:
            size_value = match.group(1)
            size_unit = match.group(2)
            return f"{size_value} {size_unit}"

        # 3️⃣ Look for patterns like "90g×2" or "200ml x 3"
        pattern3 = r'([\d.]+)\s*(ml|mL|l|L|g|kg|oz|lb)\s*[×xX]\s*(\d+)'
        match = re.search(pattern3, size_string, re.IGNORECASE)
        if match:
            size = f"{match.group(1)} {match.group(2)}"
            quantity = match.group(3)
            return f"{size} x {quantity}"

        # 4️⃣ Look for just quantity (like "24本入り" or "2個")
        pattern4 = r'(\d+)\s*(個|本入り|袋|本)'
        match = re.search(pattern4, size_string, re.IGNORECASE)
        if match:
            quantity = f"{match.group(1)} {match.group(2)}"
            return quantity

        return ""

    except Exception as e:
        print(f"Error extracting size: {e}")
        return ""

def process_document(doc):
    referer_url = doc['url']
    doc_id = doc['_id']

    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
        'cache-control': 'max-age=0',
        'if-none-match': 'W/"c3376-8Aq1jPwKfwdLVMdLO8+LNUJmBOU-gzip"',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Google Chrome";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
        'cookie': 'AKA_A2=A; PIM-SESSION-ID=zAOBlqyUUxINYF2b; ROUTE=.jsapps-5875f56457-gcmmw; bm_mi=D9CF44EDC1BC961C623F1C327A37370A~YAAQqyQ+F2mQWCabAQAARfXpdx4Lg/Py1nK2xhiJYjqxGh9/XLD73DZyQwuQxHLPBQc27FBkOHxZ0q1914+eHEoBTUW2rSxmROOohmwVgHsq7RNw6/GDDN2aCVxMwRtvVh3nzSZb61d5cKGfQettMK4twzeHE7qD5+oxrsiwiNDnew1zGZJ5q7cf5j79t/Xl2HFgsQN6P4R3MvtFcyvQrR6KraqzuBavre/1CR76oAqIicRRivFL0gZzGiv7qWWdaouT5nR/3LjkfC9s+7ePEhaKhcomV3Xko7ko8FPguVUXJcX9dAfJ28dtjo+61+zYDbmwRw==~1; _abck=693EC4DB2A7048FF215A4611C6ADEF5A~0~YAAQqyQ+F32QWCabAQAAbvfpdw95pwiMhEae8NmR7RD3aPxhR4KEigOUY2xRBSapKMpQnAzoMrLSOiSeczobjQM260M+qllCgUKVzwwk6l7boKyStTDEGW8Wj3sFRTHSM/qOv/1MazhXg3Zq3cYhfpO8D0SKZ2Z+Edd5c30NjxFduZpCwzugr+zrqi3Du3bdlO140WkWpyDB7b1lQX3LQRbPpkMpzFo95iqoRhnsVeus70tWaKbmM5GIDIjKJig8OJgfdRTlwATirdShvJ4+qCvqYBghCOrz9s1sD1nSKpnaLSMEe+2qe+EOp0wh4Ox2m4IesEMnYy2zs4B0+whb/vquZG77E1iNzov+NClQHFYkaVzWrlHOe1Jv3PgKYb/yTv84IEi7AWdmPAhpsE3xnYjNF1LsA72HPwI5gVHSJKtnPN/dUMSuVO8RFoxDqjcxaP1M3q9sr5dzRGx6xmoVnjKxG3vPbFkZHqDifEhsVB3WGPujVawQGYH7Tw+oM/ChDHbTjpaC1fIDJYI9OTpR4IEqsEqCpsHjPzDn3gtOGezzj6W3TlLDoeDheM52eFZmdMHRD42/ezkx86L8hHAMJjxZQQ==~-1~-1~-1~AASAAAAE%2f%2f%2f%2f%2fwaeuVtzfe6AC0VowT8yOTiew+L6wPDAAwCHocoZxnLXEZRyruSgrAHggoKu1i9ZZENuGWv1~-1; e2-language=en_TH; language=en_TH; langcode=en; bm_sv=CFEC9E2D7019B6BE5F3AA9D9E4BEC647~YAAQJ03cFyyzfzCbAQAAdAnqdx6fkBAtOIyDsTIujSW2ymf6nE+o/XmJtNORFK8Tnj9Cvzcd63Sm3qJyDeQ8sLOTFMpuFfk6q3zh3fbuLjVJR84Jb4CDPU7d3Bt9f/Pln0yCsFwuvECCyXpJBSqd/0rwncACifLNI4K2UWSOx2nfYXRMcdHF9S6x6lRt7dc91nnTMDI17q1cUpPDo6tR4F6uvbE/q+P+eOPDbt47JKyKw/lFrKuxadtLkbf+GvbwgAeZkw==~1; ak_bmsc=E3AD3B09752FE3F6292C4059653DC456~000000000000000000000000000000~YAAQqyQ+F0qTWCabAQAAqm/qdx40tZtvmzTVCx1HG7f9EvNZ0sUqQv8JUI8fGfk0bxzD8Ehd+zLQ6WnssiNT2YmgPQ7X8bw3ByfMPuDBdbz26IjY1do3oSKzWIfAF4JS7M60WRXD0+eAXjb3co7e3jsuIymQsu6L11az/LoZoJr8Hsm/4JjnEpd6pA+Tj242CYGRUjkj6BZy2gZvTYD7ssC7xDR+xjHITkkCq3dXye/biODx9bMF+47D5VZjP2LcIWUBB+9nv7wNYJY4hO2e9aZEfrQcnDnSW3XU5EFheMNib1nwq6Xs3zI6KRvxdFePX6TQzbx4RwB6ZEsShCUgnCEM3rGfXWx3+vBk0w+gPXQRv4Tgx20E9RsBqzzEc3Rrn4v6LvlneN08FVG099MmBbOPN9pQxSwDLah61SWcjGVl9wpc2W0B2O7hpBSAFxNq4YrPplD6ePeZ3qzOsscjPdtPDSfG2jGxxe11pBv7GnvuARIsGN+Zmcfi; bm_sz=7C60656CF5D87002706AC933289CCE6E~YAAQqyQ+F7ejWCabAQAAzk3tdx6rEV07ukYZjFyViBr3h5GiZ7mRyYkCFvVgRE1AJ+ECnE67MqL5w1trMY1I1HRhk8TM6Gqpr4HL1jrzACjBwPjB+N4IvPqU1ZOKyddR8OwXL8kFNXhuFJEaJo4wroaT9QoU39bU/8bNIdVXQv8DOBnBp0rSdl6UDLdYgOqj081nhcKhPmujqkVeS2e9Y6E+C9hLPF4UDl7RCPdKYRFQW12OyYlnhfu8BaZKg8GsyANVo8Zp6K9rej8TvWo8EkfV1HPWJRZqmovNEZiEHauCiQqk3NIzIRMCR4hVLXjt2W7n4yortdNa2YhQg6SQe3ixcxMgiWX5nIdp/BRVJ0hppMOM+EgGb6bOlhoGJarzm7R81JRYECnsdTp3hlw0Tq992lKvitwNa6V+mWmxTsSfZP8VOufSSSi648vMlDzJl2MWIE/gg+iqrkzvaYv5HvA=~3687750~3555650; OptanonConsent=isGpcEnabled=0&datestamp=Thu+Jan+01+2026+10%3A30%3A14+GMT%2B0530+(India+Standard+Time)&version=202411.2.0&browserGpcFlag=0&isIABGlobal=false&hosts=&consentId=c32bbd0e-8f6a-424c-b5e3-d595d35633d3&interactionCount=1&isAnonUser=1&landingPath=NotLandingPage&groups=C0001%3A1%2CC0003%3A0%2CC0004%3A0&AwaitingReconsent=false',
    }

    parsed_url = urlparse(referer_url)

    product_slug = parsed_url.path.strip('/').split('/')[-1]
    print("Product slug:", product_slug)
    html_filename = f"{product_slug}_page.html"
    html_filepath = os.path.join(html_path, html_filename)

    response = obj.to_requests(url=referer_url, headers=headers, html_path=html_filepath,
                               should_be=["wtcth-state"], max_retry=3,proxies=proxies, verify=False)# proxies=proxies, verify=False,
    if not response:
        response = obj.to_requests(url=referer_url, headers=headers, html_path=html_filepath,
                                   should_be=['wtcth-state'], max_retry=3,proxies=proxies, verify=False)
    if not response:
        response = obj.to_requests(url = referer_url, headers=headers, html_path=html_filepath,
                                   should_be=['wtcth-state'], max_retry=3,proxies=proxies, verify=False)
    if not response:
        response = obj.to_requests(url = referer_url, headers=headers, html_path=html_filepath,
                                   should_be=['wtcth-state'], max_retry=3,proxies=proxies, verify=False)
    if not response:
        print(f"getting wrong response:{referer_url}")
        return None
    elif 'Result Not Found' in response or 'This product is invalid.' in response or 'This page could not be found' in response:
        search_data.update_one(
            {'_id': id}, {'$set': {'Status': "Not found"}})
        print("Status Updated...")
    elif response:

        product_id = urlparse(referer_url).path.split('/')[-1].replace("BP_", "").strip()

        selector = Selector(text=response)

        json_text = selector.xpath('//script[@id="wtcth-state"]/text()').get()

        if not json_text:
            json_text = selector.xpath('//script[@id="wtcsg-state"]/text()').get()

        if not json_text:
            json_text = selector.xpath('//script[@id="wtcid-state"]/text()').get()

        if not json_text:
            json_text = selector.xpath('//script[@id="wtcth-state"]/text()').get()

        data = None
        if json_text:
            data = json.loads(json_text)
        try:
            stock_status = data['cx-state']['product']['details']['entities'][str(product_id)]['variants']['value']['baseOptions'][0]['options'][
                0][
                'stock']['stockLevelStatus']
        except Exception as e:
            stock_status = data['cx-state']['product']['details']['entities'][str(product_id)]['variants']['value']['baseOptions'][0][
                'options'][
                0][
                'stock']['stockLevelStatus']
            print(e)
        if stock_status == "inStock":
            stock = True
        else:
            stock = False

        product = selector.xpath('//div[@class="ProductSummaryGroup"]')
        name = product.xpath('//div[@class="product-name"]/text()').get()
        brand = product.xpath('//h2[@class="product-brand"]/a/text()').get()
        main_price = product.xpath('//span[@class="price"]/text()').get()

        if main_price:
            price_value = float(main_price)

            price = int(price_value) if price_value.is_integer() else round(price_value, 2)

        compare_price = product.xpath('//span[@class="retail-price"]/text()').get()
        was_price=None
        if compare_price:
            try:

                cleaned_compare_price = compare_price.replace('Rp','').replace('RM', '').replace('S$', '').replace(',', '').replace('฿', '').strip()
                was_price_value = float(cleaned_compare_price)
                was_price = int(was_price_value) if was_price_value.is_integer() else round(was_price_value, 2)
            except Exception as e:
                print(e)
        else:
            was_price = None
        if not was_price or price == was_price:
            rrp_price = price
            was_price = ''
        else:
            rrp_price = was_price
        image_urls = selector.xpath('.//div[@class="ProductImages"]//img/@src').getall()
        main_offer = product.xpath('//span[@class="discount ng-star-inserted"]/text()').get() or ""
        offer = main_offer.strip()
        main_product_id = selector.xpath('//div[@class="info-container"]//div[@class="value"]/text()').get()
        joined_urls = ' | '.join(image_urls)
        breadcrumbs = selector.xpath(
            '//span[@itemprop="itemListElement"]//span[contains(@itemprop, "name")]/text()').getall()
        breads = ' > '.join(item.strip() for item in breadcrumbs if item.strip())

        main_promo = selector.xpath('//div[@class="container-title"]/text()').get() or ""
        promo = main_promo.strip()

        pack_size = extract_size(name)

        Items = {"Name": name, "Promo_Type": promo, "Price": price, "per_unit_price": "",
                 "WasPrice": was_price,
                 "Offer_info": offer, "Pack_size": pack_size, "Barcode": "",
                 "Images": joined_urls,
                 "ProductURL": referer_url, "is_available": stock,
                 "Status": "Done", "ParentCode": "", "ProductCode": main_product_id,
                 "retailer_name": "Watson",
                 "Category_Hierarchy": breads, "Brand": brand, "RRP": rrp_price}
        try:
                product_data.insert_one(Items)
                print("product inserted")
                search_data.update_one({"_id": doc_id}, {"$set": {"Status": "Done"}})
        except Exception as e:
            print(e)

        print(Items)

if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=20) as executor:
        docs = list(search_data.find({"Status": "Pending"}))
        executor.map(process_document, docs)


