import datetime
from Common_Modual.common_functionality import *
import pymongo
import os
from dateutil.relativedelta import relativedelta, MO
from datetime import datetime
from dateutil.relativedelta import relativedelta, TU
from dateutil.relativedelta import relativedelta, MO
# next_tuesday = (datetime.today() + relativedelta(weekday=TU(0))).date()
# Today1 = (datetime.today() + relativedelta(weekday=MO(1))).date()


# first_monday_date = (datetime.datetime.today() + relativedelta(weekday=MO(0))).date()

obj = RequestsManager()

# Parameters
website = "Watson_th"  # Replace with the actual website name or variable
today = datetime.today().strftime("%Y_%m_%d")

conn = pymongo.MongoClient("mongodb://localhost:27017/")
db = conn[f"pricemate_eshop_watsons_th"]

search_data = db[f'Search_Data']
product_data = db[f'Product_Data_{today}']

search_data.create_index("url", unique=True)
product_data.create_index("ProductCode", unique=True)


base_path = f"E:\\Data\\Crawl_Data_Collection\\PriceMate\\{today}\\{website}"

# Define paths for different file types
html_path = os.path.join(base_path, "Data_Files", "HTML_Files")
excel_path = os.path.join(base_path, "Data_Files", "Excel_Files")

# Create directories
os.makedirs(html_path, exist_ok=True)
os.makedirs(excel_path, exist_ok=True)

print(f"HTML files path: {html_path}")
print(f"Excel files path: {excel_path}")

proxy = "http://21ed11ef5c872bc7727680a52233027db4578a0e:@api.zenrows.com:8001"
proxies = {"http": proxy, "https": proxy}

current_proxy = '2c6ea6e6d8c14216a62781b8f850cd5b'
# current_proxy = '7d12e8dc87c84c9b9fccc23416cbdc40'

proxy_host = "api.zyte.com"
proxy_port = "8011"
proxy_auth = f"{current_proxy}:"

proxies2 = {
    "http": "https://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port),
    "https": "http://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port)
}