import subprocess
import time
import os
import pymongo
from datetime import datetime

PROJECT_PATH = r"E:\Projects\KP\PriceMate\Woolworth"
MONGO_URL = "mongodb://localhost:27017/"
DB_NAME = "pricemate_eshop_woolworths_au"


def log(msg):
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}")

def run_file(filename):
    """Run a Python file located inside the project folder."""
    file_path = os.path.join(PROJECT_PATH, filename)

    log(f"➡️ Running: {filename}")
    result = subprocess.run(["python", file_path])

    if result.returncode != 0:
        log(f"❌ Error running {filename}")
    else:
        log(f"✅ Finished: {filename}")

def get_db():
    """Return MongoDB database instance."""
    client = pymongo.MongoClient(MONGO_URL)
    return client[DB_NAME]


def has_pending_pl():
    """Check MongoDB for pending PL & prepare required collections."""
    db = get_db()

    today_key = datetime.today().strftime("%Y_%m_%d")
    product_collection_name = f"Product_Data_{today_key}"

    category_input = db["Category_Input"]

    # ----- STEP 1: Check if today's Product_Data exists -----
    existing_collections = [c["name"] for c in db.list_collections()]

    if product_collection_name not in existing_collections:
        log(f"⚠️ {product_collection_name} not found. Resetting Category_Input to Pending...")
        category_input.update_many({}, {"$set": {"Status": "Pending"}})
        db.create_collection(product_collection_name)

    product_data = db[product_collection_name]

    # ----- STEP 2: Create index if not exists -----
    try:
        product_data.create_index("ProductCode", unique=True)
    except Exception:
        pass  # ignore duplicate index creation warning

    # ----- STEP 3: Check pending count -----
    pending_count = category_input.count_documents({'Status': 'Pending'})
    log(f"Pending items: {pending_count}")

    return pending_count > 0, pending_count, category_input


# ---------------------------------------
# MAIN LOGIC
# ---------------------------------------
def main():
    log(f"📁 Project selected: {PROJECT_PATH}")
    log("🚀 Starting workflow...")

    # 1. RUN CATEGORY FETCH FILE
    run_file("Get_All_Categories.py")

    # 2. LOOP PDP RUNNING UNTIL ALL DONE
    while True:
        has_pending, pending_count, category_input = has_pending_pl()

        if not has_pending:
            log("🎉 All Done! No pending PL left.")
            break

        # Run PDP / Category processor
        run_file("WoolWorths_Category.py")

        log(f"⏳ Waiting 30 minutes before next cycle (Pending left: {pending_count})...\n")
        time.sleep(30 * 60)


if __name__ == "__main__":
    main()
