import time
import undetected_chromedriver as uc
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
import json
import logging
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filename="woolworth_token_log.log"  # Logs will be written to this file
)


def capture_filtered_network_traffic(url, retry = 0, failed = False):
    try:
        # Enable logging for performance (network) data
        capabilities = DesiredCapabilities.CHROME
        capabilities["goog:loggingPrefs"] = {"performance": "ALL"}

        # Initialize undetected Chrome driver
        options = uc.ChromeOptions()
        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-blink-features=AutomationControlled")

        # driver = uc.Chrome(options=options, desired_capabilities=capabilities)

        options = webdriver.ChromeOptions()
        driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

        try:
            logging.info(f"Opening URL: {url}")
            driver.get(url)

            # Retrieve cookies
            cookies = driver.get_cookies()

            # Convert cookies to a string format
            cookie_string = "; ".join([f"{cookie['name']}={cookie['value']}" for cookie in cookies])

            print("Cookies as String:", cookie_string)
            with open('woolworth_cookies.txt', 'w', encoding='utf-8') as f:
                f.write(cookie_string)
            print("cookies updated....")

        finally:
            driver.quit()
            logging.info(f"Driver closed successfully.")
            if retry < 2 and failed:
                retry += 1
                capture_filtered_network_traffic("https://www.woolworths.com.au/",  retry)
            return True

    except Exception as e:
        logging.error(f"Try: {retry}, Error initializing or using the Chrome driver: {e}")
        retry += 1
        if retry < 2 and failed:
            retry += 1
            capture_filtered_network_traffic("https://www.woolworths.com.au/", retry)
        return False
if __name__ == "__main__":

    # Example usage
    status = capture_filtered_network_traffic("https://www.woolworths.com.au/")
