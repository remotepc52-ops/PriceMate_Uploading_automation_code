import json

from Woolworth_cookie_automation import capture_filtered_network_traffic
from config import *

import requests


def collect_leaf_categories(data, path=None, results=None, unique_leaf_paths = None):
    if results is None:
        results = []
    if path is None:
        path = []

    current_name = data.get('UrlFriendlyName', 'Unknown')
    new_path = path + [current_name]

    # If no children → it's a leaf node
    if not data.get('Children'):
        # If this node has a UrlFriendlyName, store it
        if 'UrlFriendlyName' in data:
            NodeId = data['NodeId']
            name = data['Description']
            UrlFriendlyName = data['UrlFriendlyName']
            cat_path = " > ".join(path)
            if 'front-of-store' not in cat_path and 'everyday-market' not in cat_path and 'special' not in cat_path:
                if cat_path not in unique_leaf_paths:
                    unique_leaf_paths.append(cat_path)

                    results.append({
                        "path": cat_path,
                        "Category Name": name,
                        "UrlFriendlyName": UrlFriendlyName,
                        "CategoryId": NodeId,
                        "Status": "Pending",
                    })


    else:
        for child in data['Children']:
            collect_leaf_categories(child, new_path, results, unique_leaf_paths)

    return results



def collect_categories(data, path=None, results=None, unique_leaf_paths = None):
    if results is None:
        results = []
    if path is None:
        path = []

    # If this node has a UrlFriendlyName, store it
    if 'UrlFriendlyName' in data:
        NodeId = data['NodeId']
        name = data['Description']
        UrlFriendlyName = data['UrlFriendlyName']
        cat_path = " > ".join(path)
        if cat_path not in unique_leaf_paths:

            if 'front-of-store' not in cat_path and 'everyday-market' not in cat_path and 'special' not in cat_path:
                unique_leaf_paths.append(cat_path)

                results.append({
                     "path": " > ".join(path),
                     "Category Name": name,
                     "UrlFriendlyName": UrlFriendlyName,
                     "CategoryId": NodeId,
                     "Status": "Pending",
                })

    # If it has children, recursively go through each
    if 'Children' in data and isinstance(data['Children'], list):
        for child in data['Children']:
            new_path = path + [child.get('UrlFriendlyName', 'Unknown')]
            collect_categories(child, new_path, results, unique_leaf_paths)

    return results

if __name__ == '__main__':
    file_path = "woolworth_cookies.txt"

    # Get the last modified time of the file
    last_modified_time = os.path.getmtime(file_path)

    # Get the current time
    current_time = time.time()

    # Check if the file was modified in the last hour (3600 seconds)
    if current_time - last_modified_time <= 3600:
        print(f"{file_path} was updated in the last hour.")

    else:
        print(f"{file_path} was NOT updated in the last hour.")
        # Example usage
        cookie_update = capture_filtered_network_traffic("https://www.woolworths.com.au/")
        if not cookie_update:
            print("Cookies is not updated....")
            raise Exception("Cookies is not updated....")

    cookies = open('woolworth_cookies.txt', 'r').read()

    headers = {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'en-US,en;q=0.9,hi;q=0.8',
        'priority': 'u=1, i',
        'referer': 'https://www.woolworths.com.au/',
        'request-context': 'appId=cid-v1:4601595d-64c0-46e0-be60-45622438acb3',
        'request-id': '|a404268d403e459d8d4e2ce9f0cff2c3.ca04058b4da54f58',
        'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'traceparent': '00-a404268d403e459d8d4e2ce9f0cff2c3-ca04058b4da54f58-01',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
        'cookie': cookies,
    }

    proxy = "http://21ed11ef5c872bc7727680a52233027db4578a0e:@api.zenrows.com:8001"

    response = requests.get(
        'https://www.woolworths.com.au/apis/ui/PiesCategoriesWithSpecials',
        headers=headers,
        proxies={
            'http': proxy,
            'https': proxy
        },
        verify=False
    )

    print(response.text)

    if response.status_code != 200:
        Rprint("Somthing went wrong in response...", response.status_code)
        exit(212)

    # category_input.delete_many({})
    json_data = json.loads(response.text)

    all_categories = []
    unique_leaf_paths = []
    for category in json_data.get('Categories', []):
        path = [category.get('UrlFriendlyName', 'Unknown')]
        collect_categories(category, path, all_categories, unique_leaf_paths)

    # Print or store results
    for inx, item in enumerate(all_categories):
        print(f"{inx}  ------> {item['path']} --> {item['UrlFriendlyName']}")
        try:
            category_input.insert_one(item)
            Gprint("Successfully Added...")
        except:
            Yprint("Already Exists...")

    # json_data = json.loads(response.text)
    # leaf_paths = []
    # unique_leaf_paths = []
    # for category in json_data.get('Categories', []):
    #     collect_leaf_categories(category, [category.get('UrlFriendlyName', 'Unknown')], leaf_paths, unique_leaf_paths)
    #
    # # Print final paths
    # for inx, items in enumerate(leaf_paths):
    #     print(inx, "---> ", items['path'])
    #     print(items)
    #     try:
    #         category_input.insert_one(items)
    #         Gprint("Successfully Added...")
    #     except:
    #         pass

    # # $.Categories[0].Children[7].Children[5].Children[2].UrlFriendlyName
    # Categories = response['ListTopLevelPiesCategories']['Categories']
    # for Main_Cat in Categories:
    #     NodeId = Main_Cat['NodeId']
    #     name = Main_Cat['Description']
    #     UrlFriendlyName = Main_Cat['UrlFriendlyName']
    #     if 'front-of-store' == UrlFriendlyName:
    #         continue
    #
    #     items = {
    #         "Category Name": name,
    #         "UrlFriendlyName": UrlFriendlyName,
    #         "CategoryId": NodeId,
    #         "Status": "Pending",
    #     }
    #
    #     try:
    #         category_input.insert_one(items)
    #         Gprint("Successfully Added...")
    #     except:
    #         pass
