import json

def collect_leaf_categories(data, path=None, results=None, unique_leaf_paths = None):
    if results is None:
        results = []
    if path is None:
        path = []

    current_name = data.get('UrlFriendlyName', 'Unknown')
    new_path = path + [current_name]

    # If no children → it's a leaf node
    if not data.get('Children'):
        # If this node has a UrlFriendlyName, store it
        if 'UrlFriendlyName' in data:
            NodeId = data['NodeId']
            name = data['Description']
            UrlFriendlyName = data['UrlFriendlyName']
            cat_path = " > ".join(path)
            if 'front-of-store' not in cat_path and 'everyday-market' not in cat_path and 'special' not in cat_path:
                if cat_path not in unique_leaf_paths:
                    unique_leaf_paths.append(cat_path)

                    results.append({
                        "path": cat_path,
                        "Category Name": name,
                        "UrlFriendlyName": UrlFriendlyName,
                        "CategoryId": NodeId,
                        "Status": "Pending",
                    })


    else:
        for child in data['Children']:
            collect_leaf_categories(child, new_path, results, unique_leaf_paths)

    return results


# Load your JSON data from file (or any source)
with open('your_file.json', 'r', encoding='utf-8') as f:
    json_data = json.load(f)

leaf_paths = []
unique_leaf_paths = []
for category in json_data.get('Categories', []):
    collect_leaf_categories(category, [category.get('UrlFriendlyName', 'Unknown')], leaf_paths, unique_leaf_paths)

# Print final paths
for inx, path in enumerate(leaf_paths):
    print(inx, "---> ", path['path'])
