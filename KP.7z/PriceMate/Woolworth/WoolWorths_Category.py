import json
from threading import Thread
from Woolworth_cookie_automation import capture_filtered_network_traffic
from config import *

def PL_Extraction(start,end):
    data_list = category_input.find({"Status":"Pending"}).skip(int(start)).limit(int(end))
    for cat_item in data_list:
        id = cat_item['_id']
        UrlFriendlyName = str(cat_item['UrlFriendlyName'])
        Category_Name = str(cat_item['Category Name'])
        CategoryId = str(cat_item['CategoryId'])

        total_pages = 0
        page_no = 1
        total_result = 0

        # ------ Duplicates Remove ---------
        # Delete records where Ids is equal to 1 and Parent is equal to "No"
        # result = product_data.delete_many({"Category_Name": Category_Name})

        # Output the number of documents deleted
        # print(f"Deleted {result.deleted_count} documents.")

        data_extraction(id,total_result, UrlFriendlyName, Category_Name, CategoryId, page_no,total_pages)
        # break


def data_extraction(id, total_result, UrlFriendlyName, Category_Name, CategoryId, page_no,total_pages):
    try:
        filename = f'/New_{CategoryId}_{page_no}.html'
        path =  html_path + filename
        full_path = path.replace("\\","/")

        url = "https://www.woolworths.com.au/apis/ui/browse/category"

        payload = json.dumps(
            {
                'categoryId': CategoryId,
                'pageNumber': page_no,
                'pageSize': 36,
                'sortType': 'TraderRelevance',
                'url': f'/shop/browse/{UrlFriendlyName}?pageNumber={page_no}',
                'location': f'/shop/browse/{UrlFriendlyName}?pageNumber={page_no}',
                'formatObject': '{"name":"' + Category_Name + '"}',
                'isSpecial': False,
                'isBundle': False,
                'isMobile': False,
                'filters': [],
                'token': '',
                'gpBoost': 0,
                'isHideUnavailableProducts': False,
                'isHideEverydayMarketProducts': True,
                'isRegisteredRewardCardPromotion': False,
                'enableAdReRanking': False,
                'groupEdmVariants': False,
                'categoryVersion': 'v2',
                'flags': {
                    'EnableProductBoostExperiment': True,
                },
            }
        )

        headers = {
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'en-US,en;q=0.9,hi;q=0.8',
            'content-type': 'application/json',
            'traceparent': '00-56a3e86d82224244b968f5fa15cce95c-2e8c75dcb16344e6-01',
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
            'cookie': cookies,
        }

        response = obj.to_requests(url = url, headers = headers, method = "POST", data = payload,
                                   html_path = full_path,should_be = ['Bundles'], proxies=proxies, verify=False)

        if not response:
            if os.path.exists(full_path): os.remove(full_path)
            return None

        elif 'VerifyHuman' in response:
            print("Captcha Not Resolved after all retries executed...")

        elif 'Result Not Found' in response or 'This product is invalid.' in response or 'This page could not be found' in response:
            category_input.update_one({'_id':id},{'$set':{'Status':"Not found"}})
            print("Status Updated...")

        elif response:
            print("Getting Correct Response...")
            res_json = json.loads(response)

            check_bundles = res_json['Bundles']
            if check_bundles:
                for prdct in check_bundles:
                    product = prdct['Products'][0]

                    pdp_urlfriendlyname = product['UrlFriendlyName']
                    Stockcode = product['Stockcode']

                    ProductURL = f"https://www.woolworths.com.au/shop/productdetails/{Stockcode}/{pdp_urlfriendlyname}"

                    barcode = product['Barcode']

                    Name = product['DisplayName']
                    Price = product['Price']
                    WasPrice = product['WasPrice']
                    if not Price and WasPrice or WasPrice == Price:
                        Price = WasPrice
                        WasPrice = None
                    elif not WasPrice:
                        print("Price should not be blank....")
                        return None

                    if not Price and not WasPrice:
                        continue

                    try:
                        per_unit_price = product['CupString']
                        if not per_unit_price:
                            per_unit_price = ""
                    except: per_unit_price = ""

                    PackageSize = product['PackageSize']

                    try:product_images = product['AdditionalAttributes']['productimages']
                    except:
                        print("No Image Available...continue")
                        continue
                    try:
                        product_images = product_images.split(",")
                        product_images = [f"https://cdn0.woolworths.media/content/wowproductimages/large/{img}" for img
                                         in product_images]
                        product_images = "|".join(product_images)
                    except Exception as e:
                        product_images = ""


                    breadcrumbs = json.loads(product['AdditionalAttributes']['piescategorynamesjson'])
                    breadcrumbs_1 = product.get('AdditionalAttributes').get('piessubcategorynamesjson', None)
                    if breadcrumbs_1:
                        breadcrumbs_1 = json.loads(breadcrumbs_1)
                        breadcrumbs = f"{Category_Name} > " + " > ".join(breadcrumbs) + " > " + " > ".join(breadcrumbs_1)

                    else:
                        breadcrumbs = f"{Category_Name} > " + " > ".join(breadcrumbs)

                    # Product Availability
                    is_available = product['IsAvailable']

                    brand = product['Brand']
                    if not brand:
                        brand = ""

                    # if 'woolworths' not in brand.lower() or not barcode:
                    #     continue

                    try:

                        offer_info = []
                        promo_type = []
                        for i in product['Tags']:
                            try:
                                of_inof = i['Content']['Attributes']['Text']
                                prm_type = i['Content']['Attributes']['Promotion']
                            except:
                                of_inof = i['Content']['Attributes']['FallbackText']
                                try:prm_type = i['Content']['Attributes']['Promotion']
                                except: prm_type = ""

                            if of_inof:
                                offer_info.append(of_inof)

                            if prm_type:
                                promo_type.append(prm_type)

                        offer_info = "|".join(offer_info)
                        promo_type = "|".join(promo_type)

                    except:
                        offer_info = ""
                        promo_type = ""

                    items = {}
                    items["full_path"] = full_path
                    items["Category_Name"] = Category_Name
                    items["ProductURL"] = ProductURL
                    items["ProductCode"] = Stockcode
                    items["Name"] = Name
                    items["Price"] = Price
                    items["WasPrice"] = WasPrice
                    items["RRP"] = WasPrice if WasPrice else Price
                    items["per_unit_price"] = per_unit_price
                    items["Offer_info"] = offer_info
                    items["Pack_size"] = PackageSize
                    items["Barcode"] = barcode
                    items["retailer_name"] = "woolworths"
                    items["Category_Hierarchy"] = breadcrumbs
                    items["Brand"] = brand
                    items["Promo_Type"] = promo_type
                    items["Images"] = product_images
                    items["is_available"] = is_available
                    items["Status"] = "Done"

                    try:
                        product_data.insert_one(items)
                        print("Product Data Inserted...")

                    except Exception as e:
                        if 'duplicate key error' in str(e):
                            print('Duplicate key error......')
                            category_input.update_one({'_id': id}, {'$set': {'Status': "Done"}})
                        else:
                            print(e)

                if not total_result:
                    total_result = res_json['TotalRecordCount']
                    total_pages = math.ceil(int(total_result) / 36)

                if page_no < total_pages:
                    page_no += 1
                    data_extraction(id,total_result,UrlFriendlyName,Category_Name,CategoryId,page_no,total_pages)
                else:
                    print("Next Page is not Available...")
                    category_input.update_one({'_id':id},{'$set':{'Status':"Done"}})
                    print("status updated...")

            else:
                print("Not Found Data In Next Page....")
                category_input.update_one({'_id':id},{'$set':{'Status':"Done"}})
                print("status updated...")

        else:
            print("Somthing Went Wrong in Requests...")

    except Exception as e:
        print(f"Error in Main Data Extraction function ",e)


if __name__ == '__main__':

    file_path = r"E:\Projects\KP\PriceMate\Woolworth\woolworth_cookies.txt"

    # Get the last modified time of the file
    last_modified_time = os.path.getmtime(file_path)

    # Get the current time
    current_time = time.time()

    # Check if the file was modified in the last hour (3600 seconds)
    if current_time - last_modified_time <= 3600:
        print(f"{file_path} was updated in the last hour.")

    else:
        print(f"{file_path} was NOT updated in the last hour.")
        # Example usage
        cookie_update = capture_filtered_network_traffic("https://www.woolworths.com.au/")
        if not cookie_update:
            print("Cookies is not updated....")
            raise Exception("Cookies is not updated....")

    cookies = open('woolworth_cookies.txt', 'r').read()

    # start = 1
    # end = 1
    # PL_Extraction(start, end)
    # exit()

    print(f"----- Main open ------- ")

    while True:
        total_count = category_input.count_documents({'Status': 'Pending'})
        if not total_count:
            Gprint("All Done...")
            break

        print("Total Pending....",total_count)
        if total_count > 50:
            variable_count = total_count // 50
        else:
            variable_count = total_count // total_count

        if variable_count == 0:
            variable_count = total_count ** 2

        count = 1
        threads = [Thread(target = PL_Extraction,args = (i,variable_count)) for i in
                   range(0,total_count,variable_count)]

        for th in threads:
            th.start()
        for th in threads:
            th.join()

        print(f"--------- Thread Ends ----------- ")
        # time.sleep(5)

    if category_input.count_documents({'Status':'Pending'}) == 0:
        print("All Count Done...")
