import re
from typing import Optional, Tuple, List


def extract_size_master(product_name: str) -> Optional[str]:
    """
    AI-powered master function to extract size information from product names.
    Handles various formats including volume, weight, count, and multi-pack sizes.

    Args:
        product_name (str): The product name string to extract size from

    Returns:
        Optional[str]: Extracted size string or None if no size found
    """
    if not product_name or not isinstance(product_name, str):
        return None

    # Clean the input string
    cleaned_name = product_name.strip()

    # Strategy 1: Explicit size labels (Size:, Pack Size:, Net Weight:, etc.)
    size = _extract_explicit_size(cleaned_name)
    if size:
        return size

    # Strategy 2: Multi-pack formats (90g×1本, 500ml x 2, etc.)
    size = _extract_multipack_size(cleaned_name)
    if size:
        return size

    # Strategy 3: Standard size formats (500ml, 100g, 24 tablets, etc.)
    size = _extract_standard_size(cleaned_name)
    if size:
        return size

    # Strategy 4: Japanese/Asian specific formats
    size = _extract_asian_formats(cleaned_name)
    if size:
        return size

    # Strategy 5: Count-based sizes (pack of 12, 30 count, etc.)
    size = _extract_count_formats(cleaned_name)
    if size:
        return size

    # Strategy 6: Dimension formats (12x8x4, 5"x7", etc.)
    size = _extract_dimension_formats(cleaned_name)
    if size:
        return size

    # Strategy 7: Fractional and decimal formats
    size = _extract_fractional_formats(cleaned_name)
    if size:
        return size

    return None


def _extract_explicit_size(text: str) -> Optional[str]:
    """Extract sizes with explicit labels like 'Size:', 'Pack Size:', etc."""
    patterns = [
        r'\b(?:Size|Pack\s*Size|Net\s*Weight|Net\s*Volume|Weight|Volume|Contents?):\s*([0-9]+(?:\.[0-9]+)?)\s*(ml|mL|L|l|g|kg|oz|lb|floz|fl\.oz|tablets?|capsules?|caps?|pills?|packs?|pieces?|pcs?|units?)\b',
        r'\b(?:Size|Pack\s*Size|Net\s*Weight|Net\s*Volume|Weight|Volume|Contents?):\s*([0-9]+(?:\.[0-9]+)?)\s*([A-Za-z]+)\b'
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            value, unit = match.groups()
            return f"{value} {unit}".strip()

    return None


def _extract_multipack_size(text: str) -> Optional[str]:
    """Extract multi-pack formats like '90g×1本', '500ml x 2 bottles', etc."""
    patterns = [
        # Japanese style: 90g×1本, 200ml×3個
        r'([0-9]+(?:\.[0-9]+)?)\s*(ml|mL|L|l|g|kg|oz|lb|floz)\s*[×x]\s*([0-9]+)\s*(本|個|袋|包|缶|瓶)?',
        # English style: 500ml x 2, 100g × 5 packs
        r'([0-9]+(?:\.[0-9]+)?)\s*(ml|mL|L|l|g|kg|oz|lb|floz|fl\.oz)\s*[×x]\s*([0-9]+)\s*(bottles?|cans?|packs?|pieces?|units?)?',
        # Count x size: 3 x 500ml, 6 × 100g
        r'([0-9]+)\s*[×x]\s*([0-9]+(?:\.[0-9]+)?)\s*(ml|mL|L|l|g|kg|oz|lb|floz|fl\.oz|tablets?|capsules?)',
        # Size (count): 500ml (2), 100g (6 pack)
        r'([0-9]+(?:\.[0-9]+)?)\s*(ml|mL|L|l|g|kg|oz|lb|floz)\s*\(\s*([0-9]+)\s*(pack|本|個|袋)?\s*\)'
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            groups = match.groups()
            if len(groups) >= 3:
                # Handle different group arrangements
                if groups[2].isdigit():  # Pattern like 500ml x 2
                    size_val, unit, count = groups[0], groups[1], groups[2]
                    extra = groups[3] if len(groups) > 3 and groups[3] else ""
                    return f"{size_val}{unit} × {count}{' ' + extra if extra else ''}".strip()
                elif groups[0].isdigit() and not groups[1].isdigit():  # Pattern like 3 x 500ml
                    count, size_val, unit = groups[0], groups[1], groups[2]
                    return f"{size_val}{unit} × {count}".strip()

    return None


def _extract_standard_size(text: str) -> Optional[str]:
    """Extract standard size formats like '500ml', '100g', '24 tablets', etc."""
    patterns = [
        # Volume and weight with units
        r'\b([0-9]+(?:\.[0-9]+)?)\s*(ml|mL|L|l|g|kg|oz|lb|floz|fl\.oz|mg)\b',
        # Count with units
        r'\b([0-9]+)\s*(tablets?|capsules?|caps?|pills?|lozenges?|gummies|softgels?|pieces?|pcs?|units?)\b',
        # Pack formats
        r'\b([0-9]+)\s*(?:pack|packs?|pk|count|ct|cnt)\b',
        # Size with parentheses
        r'\(([0-9]+(?:\.[0-9]+)?)\s*(ml|mL|L|l|g|kg|oz|lb|floz|tablets?|capsules?)\)',
    ]

    for pattern in patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        if matches:
            # Return the longest/most specific match
            best_match = max(matches, key=lambda x: len(''.join(x)))
            value, unit = best_match
            return f"{value} {unit}".strip()

    return None


def _extract_asian_formats(text: str) -> Optional[str]:
    """Extract Asian-specific formats like '24本入り', '30個入', etc."""
    patterns = [
        # Japanese: 24本入り, 30個入, 12袋入
        r'([0-9]+)\s*(本|個|袋|包|錠|粒|缶|瓶)?\s*入[りる]?',
        # Chinese: 24片装, 30粒装
        r'([0-9]+)\s*(片|粒|錠|袋|包|瓶|罐)\s*装',
        # Korean and other formats
        r'([0-9]+)\s*(개|정|포|병|캔)\s*입',
    ]

    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            value = match.group(1)
            unit_part = match.group(2) if match.group(2) else ""
            full_match = match.group(0)

            # Try to preserve the original format
            if "入" in full_match:
                return f"{value}個入り" if not unit_part else f"{value}{unit_part}入り"
            elif "装" in full_match:
                return f"{value}個装" if not unit_part else f"{value}{unit_part}装"
            else:
                return full_match

    return None


def _extract_count_formats(text: str) -> Optional[str]:
    """Extract count-based formats like 'pack of 12', '30 count', etc."""
    patterns = [
        r'\bpack\s+of\s+([0-9]+)\b',
        r'\b([0-9]+)\s*count\b',
        r'\b([0-9]+)\s*ct\b',
        r'\b([0-9]+)\s*pieces?\b',
        r'\bset\s+of\s+([0-9]+)\b',
        r'\b([0-9]+)\s*pc\b',
        r'\b([0-9]+)\s*pcs\b',
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            if 'pack of' in match.group(0).lower():
                return f"pack of {match.group(1)}"
            elif 'set of' in match.group(0).lower():
                return f"set of {match.group(1)}"
            else:
                return f"{match.group(1)} count"

    return None


def _extract_dimension_formats(text: str) -> Optional[str]:
    """Extract dimension formats like '12x8x4', '5"x7"', etc."""
    patterns = [
        r'\b([0-9]+(?:\.[0-9]+)?)\s*["\']?\s*[×x]\s*([0-9]+(?:\.[0-9]+)?)\s*["\']?\s*(?:[×x]\s*([0-9]+(?:\.[0-9]+)?)\s*["\']?)?\s*(inch|in|cm|mm|ft)?\b',
        r'\b([0-9]+(?:\.[0-9]+)?)\s*(inch|in|cm|mm|ft)\s*[×x]\s*([0-9]+(?:\.[0-9]+)?)\s*(inch|in|cm|mm|ft)?\b',
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            groups = [g for g in match.groups() if g and not g.isspace()]
            if len(groups) >= 2:
                return match.group(0).strip()

    return None


def _extract_fractional_formats(text: str) -> Optional[str]:
    """Extract fractional formats like '1/2 oz', '2.5 L', etc."""
    patterns = [
        r'\b([0-9]+/[0-9]+)\s*(ml|mL|L|l|g|kg|oz|lb|floz|fl\.oz)\b',
        r'\b([0-9]+\.[0-9]+)\s*(ml|mL|L|l|g|kg|oz|lb|floz|fl\.oz|tablets?|capsules?)\b',
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            value, unit = match.groups()
            return f"{value} {unit}".strip()

    return None


# Test function to demonstrate usage
def test_size_extraction():
    """Test function with various product name examples"""
    test_cases = [
        "Vitamin D3 2000 IU - Size: 90 tablets",
        "Green Tea Extract 500mg×60個",
        "Omega-3 Fish Oil 1000mg (180 softgels)",
        "Protein Powder 2.5 kg",
        "Multivitamin 30本入り",
        "Calcium Magnesium 500ml x 2 bottles",
        "Probiotics pack of 30",
        "CoQ10 100mg 60 count",
        "Whey Protein 5 lb",
        "Vitamin C 1000mg/90 tablets",
        "Energy Drink 250ml×24缶",
        "Collagen Powder 1/2 oz",
        "Memory Support 60 capsules",
        "Joint Support 120 tabs",
        "Fiber Supplement 12oz",
    ]

    print("Testing Size Extraction:")
    print("-" * 50)
    for product in test_cases:
        size = extract_size_master(product)
        print(f"Product: {product}")
        print(f"Extracted Size: {size}")
        print("-" * 30)

# Uncomment to run tests
test_size_extraction()