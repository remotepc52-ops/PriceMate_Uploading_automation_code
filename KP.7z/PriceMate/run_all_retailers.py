import subprocess
import threading
import time
import logging
import os
import sys
from datetime import datetime, timedelta

# Configure logging with better formatting and UTF-8 encoding
log_formatter = logging.Formatter('%(asctime)s - %(levelname)s - [%(threadName)s] - %(message)s')

# File handler with UTF-8 encoding
file_handler = logging.FileHandler('retailer_manager.log', encoding='utf-8')
file_handler.setFormatter(log_formatter)

# Console handler with fallback for emoji issues
console_handler = logging.StreamHandler()
console_handler.setFormatter(log_formatter)

# Set up root logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)
logger.addHandler(file_handler)
logger.addHandler(console_handler)


# Function to safely log messages with emojis
def safe_log(level, message):
    """Safely log messages, removing emojis if console can't handle them"""
    try:
        # Try logging with emojis first
        getattr(logging, level.lower())(message)
    except UnicodeEncodeError:
        # Remove emojis and special characters for console compatibility
        safe_message = message.encode('ascii', 'ignore').decode('ascii')
        getattr(logging, level.lower())(safe_message)


class RetailerScriptManager:
    def __init__(self):
        # Define retailers and their scripts with DB name mapping
        self.retailers = {
            'Woolworth': {
                'scripts': [
                    r'E:\Kamaram\Projects\PriceMate\Woolworth\WoolWorths_Category.py'
                    # Note: Based on logs, Woolworth only has one script
                ],
                'db_name': 'Woolworths'
            },
            'PriceLine': {
                'scripts': [
                    r'E:\Kamaram\Projects\PriceMate\Priceline\Category_sitemap.py',
                    r'E:\Kamaram\Projects\PriceMate\Priceline\PriceLine_Category.py',
                    r'E:\Kamaram\Projects\PriceMate\Priceline\PriceLine_PDP.py'
                ],
                'db_name': 'Priceline'
            },
            'Liquorland': {
                'scripts': [
                    r'E:\Kamaram\Projects\PriceMate\Liquorland\Get_All_Categories.py',
                    r'E:\Kamaram\Projects\PriceMate\Liquorland\Category.py'
                    # Note: Based on logs, no PDP script exists yet
                ],
                'db_name': 'Liquorland'
            },
            'DanMurphy': {
                'scripts': [
                    r'E:\Kamaram\Projects\PriceMate\DanMurphy\Category.py',
                    r'E:\Kamaram\Projects\PriceMate\DanMurphy\PDP.py'
                ],
                'db_name': 'DanMurPhys'
            },
            'Coles': {
                'scripts': [
                    r'E:\Kamaram\Projects\PriceMate\Coles\Get_All_Categories.py',
                    r'E:\Kamaram\Projects\PriceMate\Coles\Coles_Category.py',
                    r'E:\Kamaram\Projects\PriceMate\Coles\PDP.py'
                ],
                'db_name': 'Coles'
            },
            'ChemistWareHouse': {
                'scripts': [
                    r'E:\Kamaram\Projects\PriceMate\ChemistWareHouse\Get_All_Categories.py',
                    r'E:\Kamaram\Projects\PriceMate\ChemistWareHouse\Category.py',
                    r'E:\Kamaram\Projects\PriceMate\ChemistWareHouse\PDP.py'
                ],
                'db_name': 'ChemistWareHouse'
            },
            'CellarBrations': {
                'scripts': [
                    r'E:\Kamaram\Projects\PriceMate\CellarBrations\Get_All_Categories.py',
                    r'E:\Kamaram\Projects\PriceMate\CellarBrations\Category.py'
                ],
                'db_name': 'CellarBrations'
            },
            'BWS': {
                'scripts': [
                    r'E:\Kamaram\Projects\PriceMate\BWS\Category.py',
                    r'E:\Kamaram\Projects\PriceMate\BWS\PDP.py'
                ],
                'db_name': 'BWS'
            }
        }

        # Check count script
        self.check_count_script = r'E:\Kamaram\Projects\PriceMate\Data_Dump\Get_Crawled_Count.py'

        # Timing configuration
        self.script_delay = 60  # 60 seconds between scripts in same retailer
        self.retry_delay = 30 * 60  # 30 minutes retry delay
        self.max_retries = 5  # Maximum retries per retailer before giving up

        # Active threads and retry counters
        self.active_threads = []
        self.retry_counts = {retailer: 0 for retailer in self.retailers.keys()}
        self.completed_retailers = set()
        self.failed_retailers = set()

        # Lock for thread-safe logging
        self.lock = threading.Lock()

    def validate_scripts(self):
        """Validate that all script files exist before starting"""
        missing_scripts = []

        for retailer_name, config in self.retailers.items():
            for script in config['scripts']:
                if not os.path.exists(script):
                    missing_scripts.append(f"{retailer_name}: {script}")

        if missing_scripts:
            logging.error("Missing script files:")
            for missing in missing_scripts:
                logging.error(f"  - {missing}")
            return False

        # Also check count script
        if not os.path.exists(self.check_count_script):
            logging.error(f"Count check script not found: {self.check_count_script}")
            return False

        logging.info("All script files validated successfully")
        return True

    def run_script(self, script_path):
        """Run a single Python script and return success status"""
        try:
            if not os.path.exists(script_path):
                logging.error(f"Script not found: {script_path}")
                return False

            logging.info(f"Starting script: {os.path.basename(script_path)}")

            # Use the same Python executable that's running this script
            python_exe = sys.executable

            # Use UTF-8 encoding and handle encoding issues
            result = subprocess.run(
                [python_exe, script_path],
                capture_output=True,
                text=True,
                timeout=7200,  # 2 hour timeout
                encoding='utf-8',
                errors='replace',
                cwd=os.path.dirname(script_path)  # Set working directory to script location
            )

            if result.returncode == 0:
                logging.info(f"Script completed successfully: {os.path.basename(script_path)}")
                if result.stdout.strip():
                    # Log last few lines of output for debugging
                    output_lines = result.stdout.strip().split('\n')[-3:]
                    for line in output_lines:
                        if line.strip():
                            logging.debug(f"Script output: {line.strip()}")
                return True
            else:
                logging.error(f"Script failed: {os.path.basename(script_path)} (exit code: {result.returncode})")
                if result.stderr:
                    stderr_msg = result.stderr[:1000] + "..." if len(result.stderr) > 1000 else result.stderr
                    logging.error(f"Error output: {stderr_msg}")
                if result.stdout:
                    stdout_msg = result.stdout[-500:] if len(result.stdout) > 500 else result.stdout
                    logging.error(f"Last stdout: {stdout_msg}")
                return False

        except subprocess.TimeoutExpired:
            logging.error(f"Script timeout after 2 hours: {os.path.basename(script_path)}")
            return False
        except Exception as e:
            logging.error(f"Error running script {os.path.basename(script_path)}: {str(e)}")
            return False

    def check_count(self, retailer_name):
        """Run the count check script for specific retailer and return success status"""
        try:
            # Get the database name for this retailer
            db_name = self.retailers[retailer_name]['db_name']

            logging.info(f"Running count check for {retailer_name} (DB: {db_name})...")

            python_exe = sys.executable
            result = subprocess.run(
                [python_exe, self.check_count_script, db_name],
                capture_output=True,
                text=True,
                timeout=300,  # 5 minute timeout
                encoding='utf-8',
                errors='replace',
                cwd=os.path.dirname(self.check_count_script)
            )

            # Check if the script returned successfully and parse output
            if result.returncode == 0:
                output_text = result.stdout.strip()

                if output_text:
                    # Look for explicit success/failure indicators
                    output_lower = output_text.lower()

                    # Check for various success patterns
                    success_patterns = ['true', 'passed', 'check_result: passed', 'no significant changes']
                    failure_patterns = ['false', 'failed', 'check_result: failed', 'threshold exceeded']

                    for pattern in success_patterns:
                        if pattern in output_lower:
                            logging.info(f"Count check passed for {retailer_name}")
                            return True

                    for pattern in failure_patterns:
                        if pattern in output_lower:
                            logging.warning(f"Count check failed for {retailer_name} - threshold exceeded")
                            return False

                # If no explicit indicator, assume success if script ran without errors
                logging.info(f"Count check completed for {retailer_name} (no explicit result, assuming success)")
                return True
            else:
                logging.warning(f"Count check script failed for {retailer_name} (exit code: {result.returncode})")
                if result.stderr:
                    stderr_msg = result.stderr[:500] + "..." if len(result.stderr) > 500 else result.stderr
                    logging.warning(f"Count check error: {stderr_msg}")
                return False

        except subprocess.TimeoutExpired:
            logging.error(f"Count check timeout for {retailer_name}")
            return False
        except Exception as e:
            logging.error(f"Error running count check for {retailer_name}: {str(e)}")
            return False

    def run_retailer_scripts(self, retailer_name, retailer_config):
        """Run all scripts for a single retailer sequentially"""
        thread_name = threading.current_thread().name
        logging.info(f"Starting retailer: {retailer_name}")
        scripts = retailer_config['scripts']

        while self.retry_counts[retailer_name] < self.max_retries:
            try:
                all_success = True
                failed_script = None

                # Log start of attempt
                attempt_num = self.retry_counts[retailer_name] + 1
                logging.info(f"{retailer_name}: Starting attempt {attempt_num}/{self.max_retries}")

                for i, script in enumerate(scripts):
                    # Add delay between scripts (except for the first one)
                    if i > 0:
                        logging.info(f"{retailer_name}: Waiting {self.script_delay} seconds before next script...")
                        time.sleep(self.script_delay)

                    success = self.run_script(script)
                    if not success:
                        all_success = False
                        failed_script = os.path.basename(script)
                        logging.error(f"{retailer_name}: Failed at script {i + 1}/{len(scripts)}: {failed_script}")
                        break
                    else:
                        logging.info(
                            f"{retailer_name}: Completed script {i + 1}/{len(scripts)}: {os.path.basename(script)}")

                # Check if all scripts completed successfully
                if all_success:
                    logging.info(f"{retailer_name}: All scripts completed, running count check...")
                    # Run count check for this specific retailer
                    if self.check_count(retailer_name):
                        with self.lock:
                            self.completed_retailers.add(retailer_name)
                        safe_log('info',
                                 f"{retailer_name}: [SUCCESS] COMPLETED successfully after {self.retry_counts[retailer_name]} retries")
                        return  # Successfully completed
                    else:
                        self.retry_counts[retailer_name] += 1
                        logging.warning(
                            f"{retailer_name}: Count check failed (attempt {self.retry_counts[retailer_name]}/{self.max_retries})")
                else:
                    self.retry_counts[retailer_name] += 1
                    logging.warning(
                        f"{retailer_name}: Script execution failed at {failed_script} (attempt {self.retry_counts[retailer_name]}/{self.max_retries})")

                # Check if we should retry
                if self.retry_counts[retailer_name] >= self.max_retries:
                    with self.lock:
                        self.failed_retailers.add(retailer_name)
                    safe_log('error',
                             f"{retailer_name}: [FAILED] Maximum retries ({self.max_retries}) reached. Giving up.")
                    return

                # Wait before retry
                retry_minutes = self.retry_delay / 60
                next_attempt = datetime.now() + timedelta(seconds=self.retry_delay)
                logging.info(
                    f"{retailer_name}: Waiting {retry_minutes} minutes before retry (next attempt at {next_attempt.strftime('%H:%M:%S')})...")
                time.sleep(self.retry_delay)

            except KeyboardInterrupt:
                logging.info(f"{retailer_name}: Interrupted by user")
                return
            except Exception as e:
                self.retry_counts[retailer_name] += 1
                logging.error(f"{retailer_name}: Unexpected error - {str(e)}")

                if self.retry_counts[retailer_name] >= self.max_retries:
                    with self.lock:
                        self.failed_retailers.add(retailer_name)
                    safe_log('error', f"{retailer_name}: [FAILED] Maximum retries reached due to errors. Giving up.")
                    return

                logging.info(
                    f"{retailer_name}: Waiting {self.retry_delay / 60} minutes before retrying due to error...")
                time.sleep(self.retry_delay)

    def start_all_retailers(self):
        """Start all retailers in separate threads"""
        safe_log('info', "=" * 60)
        safe_log('info', "[*] STARTING ALL RETAILERS")
        safe_log('info', "=" * 60)

        # Validate scripts first
        if not self.validate_scripts():
            logging.error("Script validation failed. Aborting.")
            return []

        # Clear any existing state
        self.active_threads = []
        self.completed_retailers = set()
        self.failed_retailers = set()
        self.retry_counts = {retailer: 0 for retailer in self.retailers.keys()}

        # Start each retailer in its own thread
        for retailer_name, retailer_config in self.retailers.items():
            thread = threading.Thread(
                target=self.run_retailer_scripts,
                args=(retailer_name, retailer_config),
                name=f"Thread-{retailer_name}",
                daemon=True
            )
            thread.start()
            self.active_threads.append(thread)
            safe_log('info', f"[+] Started thread for {retailer_name}")

        safe_log('info', f"[INFO] Started {len(self.active_threads)} retailer threads")
        return self.active_threads

    def validate_scripts(self):
        """Validate that all script files exist before starting"""
        missing_scripts = []

        for retailer_name, config in self.retailers.items():
            for script in config['scripts']:
                if not os.path.exists(script):
                    missing_scripts.append(f"{retailer_name}: {script}")

        if missing_scripts:
            safe_log('error', "[X] Missing script files:")
            for missing in missing_scripts:
                logging.error(f"  - {missing}")
            return False

        # Also check count script
        if not os.path.exists(self.check_count_script):
            safe_log('error', f"[X] Count check script not found: {self.check_count_script}")
            return False

        safe_log('info', "[+] All script files validated successfully")
        return True

    def get_detailed_status(self):
        """Get detailed status of all running threads"""
        status = {}
        for thread in self.active_threads:
            retailer_name = thread.name.replace("Thread-", "")
            status[retailer_name] = {
                'running': thread.is_alive(),
                'retries': self.retry_counts.get(retailer_name, 0),
                'max_retries': self.max_retries,
                'completed': retailer_name in self.completed_retailers,
                'failed': retailer_name in self.failed_retailers
            }
        return status

    def get_status(self):
        """Get simple status of all running threads"""
        status = {}
        for thread in self.active_threads:
            retailer_name = thread.name.replace("Thread-", "")
            if retailer_name in self.completed_retailers:
                status[thread.name] = "Completed"
            elif retailer_name in self.failed_retailers:
                status[thread.name] = "Failed"
            else:
                status[thread.name] = "Running" if thread.is_alive() else "Stopped"
        return status

    def log_status_summary(self):
        """Log a comprehensive status summary"""
        with self.lock:
            total_retailers = len(self.retailers)
            completed = len(self.completed_retailers)
            failed = len(self.failed_retailers)
            running = total_retailers - completed - failed

            safe_log('info', "=" * 50)
            safe_log('info', f"[STATUS SUMMARY]")
            safe_log('info', f"   [+] Completed: {completed}/{total_retailers} - {list(self.completed_retailers)}")
            safe_log('info', f"   [X] Failed: {failed}/{total_retailers} - {list(self.failed_retailers)}")
            safe_log('info', f"   [~] Running: {running}/{total_retailers}")

            if running > 0:
                detailed_status = self.get_detailed_status()
                running_retailers = []
                for name, details in detailed_status.items():
                    if details['running'] and not details['completed'] and not details['failed']:
                        running_retailers.append(f"{name}(retry:{details['retries']})")
                logging.info(f"   Running retailers: {', '.join(running_retailers)}")

            safe_log('info', "=" * 50)

    def wait_for_completion(self):
        """Wait for all retailer threads to complete with periodic status updates"""
        safe_log('info', "[WAIT] Waiting for all retailers to complete...")

        try:
            last_status_time = time.time()
            status_interval = 300  # 5 minutes

            while True:
                # Check if all threads are done
                alive_threads = [t for t in self.active_threads if t.is_alive()]

                if not alive_threads:
                    break

                # Log status every 5 minutes
                current_time = time.time()
                if current_time - last_status_time >= status_interval:
                    self.log_status_summary()
                    last_status_time = current_time

                # Wait a bit before checking again
                time.sleep(30)

        except KeyboardInterrupt:
            safe_log('info', "[STOP] Received interrupt signal, stopping all retailers...")
            return

        # Final status
        self.log_status_summary()
        safe_log('info', "[DONE] All retailers have completed or been stopped")

    def emergency_stop(self):
        """Emergency stop all running processes"""
        safe_log('warning', "[EMERGENCY] Emergency stop initiated...")

        # Note: This is a graceful stop - threads will finish their current operations
        # For forceful termination, you'd need to track subprocess PIDs and kill them
        for thread in self.active_threads:
            if thread.is_alive():
                logging.info(f"Waiting for {thread.name} to finish current operation...")

        logging.info("Emergency stop completed")


def main():
    """Main function to run the retailer script manager"""
    manager = RetailerScriptManager()

    try:
        # Start all retailers
        threads = manager.start_all_retailers()

        if not threads:
            logging.error("Failed to start any retailers")
            return

        # Monitor and wait for completion
        manager.wait_for_completion()

    except KeyboardInterrupt:
        safe_log('info', "[STOP] Received interrupt signal, shutting down...")
        manager.emergency_stop()
    except Exception as e:
        safe_log('error', f"[ERROR] Unexpected error in main: {str(e)}")
        logging.exception("Full error traceback:")
    finally:
        safe_log('info', "[END] Script manager shutting down")

        # Final summary
        completed = len(manager.completed_retailers)
        failed = len(manager.failed_retailers)
        total = len(manager.retailers)

        safe_log('info', "=" * 60)
        safe_log('info', "[FINAL RESULTS]")
        safe_log('info', f"   [+] Successfully completed: {completed}/{total}")
        safe_log('info', f"   [X] Failed: {failed}/{total}")

        if manager.completed_retailers:
            logging.info(f"   Successful retailers: {', '.join(sorted(manager.completed_retailers))}")
        if manager.failed_retailers:
            logging.info(f"   Failed retailers: {', '.join(sorted(manager.failed_retailers))}")

        safe_log('info', "=" * 60)


def test_single_retailer(retailer_name):
    """Test function to run a single retailer for debugging"""
    manager = RetailerScriptManager()

    if retailer_name not in manager.retailers:
        logging.error(f"Unknown retailer: {retailer_name}")
        logging.info(f"Available retailers: {list(manager.retailers.keys())}")
        return

    safe_log('info', f"[TEST] Testing single retailer: {retailer_name}")

    if not manager.validate_scripts():
        return

    try:
        manager.run_retailer_scripts(retailer_name, manager.retailers[retailer_name])
    except Exception as e:
        logging.error(f"Error testing {retailer_name}: {str(e)}")


if __name__ == "__main__":
    # Check if running in test mode
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        if len(sys.argv) > 2:
            test_single_retailer(sys.argv[2])
        else:
            print("Usage: python script.py test <retailer_name>")
            print(
                "Available retailers: Woolworth, PriceLine, Liquorland, DanMurphy, Coles, ChemistWareHouse, CellarBrations, BWS")
    else:
        main()