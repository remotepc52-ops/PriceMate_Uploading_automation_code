from config import *

import requests



if __name__ == '__main__':

    url = "https://www.coles.com.au/browse"

    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-US,en;q=0.9,hi;q=0.8',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
        'cookie': 'dsch-visitorid=f9a2ed58-41db-49d8-8e01-3997ba46ffdf; visid_incap_2800108=0+l+n6TdRp6mSQlDkJj/rRCeJmkAAAAAQUIPAAAAAACP5Qe4AJJcGuNqxr0462ka; ld_user=9a6b6be8-34e5-46a2-bdba-b1234cc807e8; visitorId=afa476a6-1445-488c-8bd6-3d4a193a1562; ORA_FPC=id=bba4087e-92e4-472a-b498-825794899871; WTPERSIST=; _fbp=fb.2.1764138521577.478298927998435932; kndctr_0B3D037254C7DE490A4C98A6_AdobeOrg_identity=CiYxNDc2MTU3Mzg5MzQxMzIzOTg4NjY5NzgwOTkyMDQyNjM1MjAzN1IRCPep5varMxgBKgRBVVMzMAPwAfep5varMw==; BVBRANDID=828b4e74-4f08-4cb0-b5eb-5c99533f7627; s_ecid=MCMID|14761573893413239886697809920426352037; nlbi_2800108_2670698=kd8JX3O/JnrzmbYn5VPXvwAAAABFxeb4HdgcCfdui9dOUl/m; incap_ses_339_2800108=ix5tLNUQ0QZY7HBiLV+0BDQIXWkAAAAApH6qWwV8JN0pZP3WMW+ftw==; nlbi_2800108_2147483392=TU33PjAJUwcLl0hH5VPXvwAAAADo/QWoUWqEMaX27HpAIb1x; reese84=3:up3GZ61vOwHHQ4O1Y1ICmg==:S5r3xe2X/IrU0uw92tIRslfa4LF/1+WKM69r/sKr5LmKJleV5HFqWErkHaDfmSmCoukestQUvOHuu+ImI8vap+5bf9lknTqZ5gFbPQZiy3uDaBwzewq1usdmfm2Pp7az1F5ZaHEoGLj8T6nQNARuF+Khr8hcDS7RAQb7hObz+w9WMONWRLS8m1i+ec4vtTtsgLKCP0bs9iDUkVZaK7LFxRY91lbpZ7l3iqxHzqZwc4lEJ1HQOLV5qtDB6LgK/WS+mPYBn80Dpf+kd/7PmaJchznaZbXUv9n+rLkSfPBbozsGsVBUSOO3/HUKmLluJKNuy7OqeJBngynoJ15BvenfbL8KGbpacTVZFfXNmHnxTuXvgbKBzHXKMPixrp3nvo9jxgwVDmWwm479mjEeYpYLFekpmpSNsgh9f/7Ta3AZGx1qhqb/Thc7aqw7SM5VsZL4sJydBIq3AkKRtQamG1sTAw==:4WA5rGndn0UosBU4hRUafYRL8j/gCxmAep6RWyw6WM4=; s_rnd=93; AMCVS_0B3D037254C7DE490A4C98A6%40AdobeOrg=1; sessionId=75e27bdb-8496-4370-ae76-e81d58056a8c; nlbi_2800108_3037207=cIE7FTw8tjSNxrui5VPXvwAAAADcxsYr47i8f7+viIm0bjIZ; analyticsIsLoggedIn=false; ldUserType=anonymous; at_check=true; mbox=PC#e1610986446540779a03a9b6022a7c74.36_0#1831035837|session#11e2d9a94a6549f8a5a06f74a5ea343f#1767792897; fs_lua=1.1767791035119; s_ips=427; s_tp=1746; s_ppv=cusp%253Abrowse%2C24%2C24%2C24%2C427%2C4%2C1; gpv_page=cusp%3Abrowse; s_cc=true; AMCV_0B3D037254C7DE490A4C98A6%40AdobeOrg=179643557%7CMCIDTS%7C20461%7CMCMID%7C14761573893413239886697809920426352037%7CMCAID%7CNONE%7CMCOPTOUT-1767798241s%7CNONE%7CvVersion%7C5.5.0; fs_uid=#o-210D95-na1#6b4c07d9-bc05-4114-a3da-f5512ddb15ba:3d9a1362-f343-47c4-b112-02e209602660:1767791035119::1#b2ffbab7#/1799327037; BVBRANDSID=c8497f4e-f4d1-489b-9579-536e5822c1df',
    }

    response = requests.request("GET", url, headers=headers)
    if response.status_code != 200:
        Rprint("Somthing went wrong in response...", response.status_code)
        exit(212)

    category_input.delete_many({})

    sel_res = Selector(text=response.text)
    script_json = sel_res.xpath('//script[@id="__NEXT_DATA__"]//text()').get()
    response = json.loads(script_json)
    # $.props.pageProps.allProductCategories.catalogGroupView[17].name
    Categories = response['props']['pageProps']['allProductCategories']['catalogGroupView']
    for Main_Cat in Categories:
        name = Main_Cat['name']
        seoToken = Main_Cat['seoToken']
        items = {
            "Category Name": name,
            "UrlFriendlyName": seoToken,
            "Status": "Pending",
        }

        try:
            category_input.insert_one(items)
            Gprint("Successfully Added...")
        except:
            pass

    de = {
    "Dairy":	"dairy-eggs-fridge",
    "Pantry":	"pantry",
    "Drinks":	"drinks",
    "Frozen":	"frozen",
    "Household":	"household",
    "Health & Beauty":	"health-beauty",
    "Baby":	"baby",
    "Pet":	"pet"
    }
    for name, seoToken in de.items():
        # name = Main_Cat['name']
        # seoToken = Main_Cat['seoToken']
        items = {
            "Category Name": name,
            "UrlFriendlyName": seoToken,
            "Status": "Pending",
        }

        try:
            category_input.insert_one(items)
            Gprint("Successfully Added...")
        except:
            pass