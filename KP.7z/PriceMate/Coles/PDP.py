from threading import Thread
from time import sleep
from config import *

def fetch_data(start, end):
    data_list = product_data.find({"Status": "Pending"}).skip(int(start)).limit(int(end))
    # data_list = search_data.find({ "ProductURL": { "$regex": "6748" } })
    for cat_item in data_list:
        ID = cat_item['_id']
        ProductURL = str(cat_item['ProductURL'])
        ProductCode = str(cat_item['ProductCode'])

        data_extraction(ID, ProductURL, ProductCode)


def data_extraction(ID, url, product_code):
    try:


        filename = f'PDP_{product_code}.html'
        path = os.path.join(html_path, filename)
        full_path = path.replace("\\", "/")

        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'priority': 'u=0, i',
            'sec-ch-ua': '"Google Chrome";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
            # 'cookie': 'dsch-visitorid=f9a2ed58-41db-49d8-8e01-3997ba46ffdf; visid_incap_2800108=0+l+n6TdRp6mSQlDkJj/rRCeJmkAAAAAQUIPAAAAAACP5Qe4AJJcGuNqxr0462ka; ld_user=9a6b6be8-34e5-46a2-bdba-b1234cc807e8; visitorId=afa476a6-1445-488c-8bd6-3d4a193a1562; ORA_FPC=id=bba4087e-92e4-472a-b498-825794899871; WTPERSIST=; _fbp=fb.2.1764138521577.478298927998435932; kndctr_0B3D037254C7DE490A4C98A6_AdobeOrg_identity=CiYxNDc2MTU3Mzg5MzQxMzIzOTg4NjY5NzgwOTkyMDQyNjM1MjAzN1IRCPep5varMxgBKgRBVVMzMAPwAfep5varMw==; BVBRANDID=828b4e74-4f08-4cb0-b5eb-5c99533f7627; s_ecid=MCMID|14761573893413239886697809920426352037; s_rnd=93; analyticsIsLoggedIn=false; mbox=PC#e1610986446540779a03a9b6022a7c74.36_0#1831035867|session#11e2d9a94a6549f8a5a06f74a5ea343f#1767792927; AMCV_0B3D037254C7DE490A4C98A6%40AdobeOrg=179643557%7CMCIDTS%7C20461%7CMCMID%7C14761573893413239886697809920426352037%7CMCAID%7CNONE%7CMCOPTOUT-1767798273s%7CNONE%7CvVersion%7C5.5.0; fs_uid=#o-210D95-na1#6b4c07d9-bc05-4114-a3da-f5512ddb15ba:3d9a1362-f343-47c4-b112-02e209602660:1767791035119::2#b2ffbab7#/1799327040; reese84=3:xwKe+WtoJk+l0pcP1SE/lg==:Bx8XRkAR5g0cN8jBYGsO3dG8NoZVu1twaoakv2VuNa2SeMK9znV9qLrN6C4N4n9Ndt5CAu4u2Qo7n4UPvG1n2Gjd1Yl/v5lkLvZ7F9XyGfePKRp9njfN0JcQOW2ELMMjEjwRZ+dTP8gEBnKa3OWlHi84zNxZ9nKS78qTqtt43aaF1k45Ax74Io5EawNxQjB3sZNhr6ygYwhfaaFGDhOMkKAmV/xh1utuQoDe+RZnTeCddE8c2yQojp3H0WevwCqnxnvPBwp/ydItzFl65Hpi1S4+z5sP5yHHShd7DrsFZtoGZimhYjOwQIvyG/D/8sWm1h39QCj5K8BpYYFb29Yg8wwvo3rGNLujath9CmUd+MsI50HJLt8BXtd4bK15ai/2EX2Vi+K9reDg6SiJjMTSI6FK7wr9aGb5UffOZunNLAx/6g/xiZRaWHV9cfSccPLxL4wrnhPNmqMxbigOA6PFKg==:BnvZtbIQBI+95zz+uqg45p59AIzwVunJF3+PeXeqtR0=; nlbi_2800108_2670698=rQNAYhaqr2J9oQja5VPXvwAAAADnpJNuA417Gd5qKcohqgZr; incap_ses_1469_2800108=4K6tOPTwYRxhcCLGMPBiFH5IXWkAAAAAZ8pEOnAw0aOMTjnQCU3vdQ==',
        }

        # scraper_url = f'http://api.scraperapi.com/?api_key={scraper_api_key}&url={url}&keep_headers=true&country_code=au'

        apikey = '21ed11ef5c872bc7727680a52233027db4578a0e'

        params1 = {
            'url': url,
            'apikey': apikey,
            'custom_headers': 'true'
        }

        response = obj.to_requests(url='https://api.zenrows.com/v1/', headers=headers, params=params1, verify=False,
                                       html_path=full_path, should_be=['id="__NEXT_DATA__"'], max_retry=5)
        if not response:    
            Hprint("❌Getting blank response..... ❌", url)
            return None

        elif 'VerifyHuman' in response:
            Rprint("❌ Captcha Not Resolved after all retries executed..❌")

        elif 'Result Not Found' in response or 'Sorry, the product you  are looking for' in response or 'This page could not be found' in response:
            product_code.update_one({'_id': ID}, {'$set': {'Status': "Not found"}})
            Rprint("✅ Status updated as Result ℹ️ Not Found...")

        elif response:
            sel_res = Selector(text=response)
            json_data = sel_res.xpath('//script[@id="__NEXT_DATA__"]//text()').get()

            res_json = json.loads(json_data)

            Products = res_json['props']['pageProps']['product'] # $.props.pageProps.product

            GTIN = Products.get('gtin', "") or ""
            variation_by = Products.get('variations', "") or ""

            Variation_data = {}

            if variation_by:
                for Key in variation_by:
                    if not Key.startswith("by"):
                        continue

                    RelatedIds = []
                    By_Variant = variation_by[Key]
                    for v in By_Variant:
                        variant_id = str(v['id'])
                        RelatedIds.append(variant_id)
                    if RelatedIds:
                        Variation_data[Key.replace("by", "")] = RelatedIds

            v_data = []
            if Variation_data:
                for k, v in Variation_data.items():
                    value = ', '.join(v)
                    v_data.append(f"{k}:{value}")

            v_data = "|".join(v_data)

            is_available = Products['availability']

            Items = {
                "is_available": is_available,
                "Barcode": GTIN,
                "Variation_Data": v_data,
                "Status": "Done"
                     }

            try:
                product_data.update_one({'_id': ID}, {'$set': Items})
                Gprint("✅ Status updated as Result ℹ️ Done...")

            except Exception as e:
                print(e)
        else:
            Rprint("Somthing Went Wrong in Requests...")


    except Exception as e:
        Rprint(f"Error in Main Data Extraction function ", e)


if __name__ == '__main__':
    Gprint("🚀 Starting data scraping...")
    retry = 0
    while True and retry <= 5:
        retry += 1

        total_count = product_data.count_documents({'Status': 'Pending'})
        if not total_count:
            print("All Done...")
            break

        Bprint("Total Pending....", total_count)
        if total_count > 50:
            variable_count = total_count // 50
        else:
            variable_count = total_count // total_count

        if variable_count == 0:
            variable_count = total_count ** 2

        count = 1
        threads = [Thread(target=fetch_data, args=(i, variable_count)) for i in
                   range(0, total_count, variable_count)]

        for th in threads:
            th.start()

        for th in threads:
            th.join()

        Hprint(f"--------- Thread Ends ----------- ")
        sleep(5)

    if product_data.count_documents({'Status': 'Pending'}) == 0:
        Gprint("🎉 Finished processing all records!")
