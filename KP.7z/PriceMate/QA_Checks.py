import pandas as pd
import numpy as np
import re
from urllib.parse import urlparse
from datetime import datetime
import os
from typing import Dict, List, Tuple, Any
import warnings

warnings.filterwarnings('ignore')


class PriceMateQATool:
    """
    Automated Data Quality Checker for PriceMate Product Catalog DataFrame
    """

    def __init__(self, df: pd.DataFrame, retailer):
        """
        Initialize the QA tool with a DataFrame

        Args:
            df (pd.DataFrame): Product catalog DataFrame to validate
        """

        self.retailer = retailer
        self.df = df.copy()
        self.results = {
            'summary': {},
            'detailed_results': {},
            'failed_records': {},
            'statistics': {}
        }
        self.total_records = len(df)

    def validate_url(self, url: str) -> bool:
        """Validate if string is a proper URL format"""
        if pd.isna(url) or not isinstance(url, str):
            return False
        try:
            result = urlparse(url)
            return all([result.scheme in ['http', 'https'], result.netloc])
        except:
            return False

    def has_junk_characters(self, text: str) -> bool:
        """Check if text contains junk characters"""
        if pd.isna(text):
            return False
        junk_patterns = [r'###', r'\*\*\*', r'<<<', r'>>>', r'\?\?\?', r'NULL', r'null']
        for pattern in junk_patterns:
            if re.search(pattern, str(text)):
                return True
        return False

    def is_alphanumeric_only(self, text: str) -> bool:
        """Check if text contains only alphanumeric characters"""
        if pd.isna(text):
            return False
        return str(text).replace(' ', '').isalnum()

    def extract_numeric_from_unit_price(self, unit_price: str) -> float:
        """Extract numeric value from unit price string"""
        if pd.isna(unit_price):
            return None
        try:
            numbers = re.findall(r'\d+\.?\d*', str(unit_price))
            return float(numbers[0]) if numbers else None
        except:
            return None

    def is_valid_barcode_length(self, barcode: str) -> bool:
        """Check if barcode has valid length (8, 12, 13, or 14 digits)"""
        if pd.isna(barcode):
            return True  # Nullable field
        valid_lengths = [8, 12, 13, 14]
        return len(str(barcode)) in valid_lengths

    def check_product_url(self) -> Dict:
        """Validate ProductURL column"""
        column = 'ProductURL'
        results = {
            'passed': 0,
            'failed': 0,
            'issues': [],
            'failed_indices': []
        }

        if column not in self.df.columns:
            results['issues'].append(f"Column '{column}' missing from dataset")
            return results

        # Check for null values
        null_mask = self.df[column].isna()
        null_count = null_mask.sum()

        # Check URL format
        valid_url_mask = self.df[column].apply(self.validate_url)
        invalid_url_count = (~valid_url_mask & ~null_mask).sum()

        # Check uniqueness
        duplicate_count = self.df[column].duplicated().sum()

        results['passed'] = len(self.df) - null_count - invalid_url_count - duplicate_count
        results['failed'] = null_count + invalid_url_count + duplicate_count

        if null_count > 0:
            results['issues'].append(f"{null_count} null values found")
            results['failed_indices'].extend(self.df[null_mask].index.tolist())

        if invalid_url_count > 0:
            results['issues'].append(f"{invalid_url_count} invalid URL formats")
            invalid_indices = self.df[~valid_url_mask & ~null_mask].index.tolist()
            results['failed_indices'].extend(invalid_indices)

        if duplicate_count > 0:
            results['issues'].append(f"{duplicate_count} duplicate URLs")
            dup_indices = self.df[self.df[column].duplicated()].index.tolist()
            results['failed_indices'].extend(dup_indices)

        return results

    def check_product_code(self) -> Dict:
        """Validate ProductCode column"""
        column = 'ProductCode'
        results = {
            'passed': 0,
            'failed': 0,
            'issues': [],
            'failed_indices': []
        }

        if column not in self.df.columns:
            results['issues'].append(f"Column '{column}' missing from dataset")
            return results

        # Check for null values
        null_mask = self.df[column].isna()
        null_count = null_mask.sum()

        # Check uniqueness
        duplicate_count = self.df[column].duplicated().sum()

        # Check alphanumeric pattern
        alphanum_mask = self.df[column].apply(self.is_alphanumeric_only)
        invalid_pattern_count = (~alphanum_mask & ~null_mask).sum()

        results['passed'] = len(self.df) - null_count - duplicate_count - invalid_pattern_count
        results['failed'] = null_count + duplicate_count + invalid_pattern_count

        if null_count > 0:
            results['issues'].append(f"{null_count} null values found")
            results['failed_indices'].extend(self.df[null_mask].index.tolist())

        if duplicate_count > 0:
            results['issues'].append(f"{duplicate_count} duplicate codes")
            results['failed_indices'].extend(self.df[self.df[column].duplicated()].index.tolist())

        if invalid_pattern_count > 0:
            results['issues'].append(f"{invalid_pattern_count} codes with special characters")
            invalid_indices = self.df[~alphanum_mask & ~null_mask].index.tolist()
            results['failed_indices'].extend(invalid_indices)

        return results

    def check_name(self) -> Dict:
        """Validate Name column"""
        column = 'Name'
        results = {
            'passed': 0,
            'failed': 0,
            'issues': [],
            'failed_indices': []
        }

        if column not in self.df.columns:
            results['issues'].append(f"Column '{column}' missing from dataset")
            return results

        failed_indices = set()

        # Check for null values
        null_mask = self.df[column].isna()
        null_count = null_mask.sum()
        if null_count > 0:
            results['issues'].append(f"{null_count} null values found")
            failed_indices.update(self.df[null_mask].index.tolist())

        # Check for junk characters
        junk_mask = self.df[column].apply(self.has_junk_characters)
        junk_count = junk_mask.sum()
        if junk_count > 0:
            results['issues'].append(f"{junk_count} names with junk characters")
            failed_indices.update(self.df[junk_mask].index.tolist())

        # Check length constraints
        length_mask = self.df[column].str.len()
        short_names = (length_mask < 3) & ~null_mask
        long_names = (length_mask > 500) & ~null_mask
        short_count = short_names.sum()
        long_count = long_names.sum()

        if short_count > 0:
            results['issues'].append(f"{short_count} names too short (< 3 characters)")
            failed_indices.update(self.df[short_names].index.tolist())

        if long_count > 0:
            results['issues'].append(f"{long_count} names too long (> 500 characters)")
            failed_indices.update(self.df[long_names].index.tolist())

        # Check if name is just numbers
        numeric_only = self.df[column].str.match(r'^\d+$', na=False)
        numeric_count = numeric_only.sum()
        if numeric_count > 0:
            results['issues'].append(f"{numeric_count} names are just numbers")
            failed_indices.update(self.df[numeric_only].index.tolist())

        results['failed_indices'] = list(failed_indices)
        results['failed'] = len(failed_indices)
        results['passed'] = len(self.df) - results['failed']

        return results

    def check_price(self) -> Dict:
        """Validate Price column"""
        column = 'Price'
        results = {
            'passed': 0,
            'failed': 0,
            'issues': [],
            'failed_indices': []
        }

        if column not in self.df.columns:
            results['issues'].append(f"Column '{column}' missing from dataset")
            return results

        failed_indices = set()

        # Check for null values
        null_mask = self.df[column].isna()
        null_count = null_mask.sum()
        if null_count > 0:
            results['issues'].append(f"{null_count} null values found")
            failed_indices.update(self.df[null_mask].index.tolist())

        # Check if numeric
        numeric_mask = pd.to_numeric(self.df[column], errors='coerce').notna()
        non_numeric_count = (~numeric_mask & ~null_mask).sum()
        if non_numeric_count > 0:
            results['issues'].append(f"{non_numeric_count} non-numeric values")
            failed_indices.update(self.df[~numeric_mask & ~null_mask].index.tolist())

        # Check if positive
        positive_mask = (pd.to_numeric(self.df[column], errors='coerce') > 0)
        negative_count = (~positive_mask & numeric_mask).sum()
        if negative_count > 0:
            results['issues'].append(f"{negative_count} non-positive prices")
            failed_indices.update(self.df[~positive_mask & numeric_mask].index.tolist())

        # Check against RRP if available
        if 'RRP' in self.df.columns:
            price_exceeds_rrp = (pd.to_numeric(self.df[column], errors='coerce') >
                                 pd.to_numeric(self.df['RRP'], errors='coerce'))
            exceeds_count = price_exceeds_rrp.sum()
            if exceeds_count > 0:
                results['issues'].append(f"{exceeds_count} prices exceed RRP")
                failed_indices.update(self.df[price_exceeds_rrp].index.tolist())

        results['failed_indices'] = list(failed_indices)
        results['failed'] = len(failed_indices)
        results['passed'] = len(self.df) - results['failed']

        return results

    def check_was_price(self) -> Dict:
        """Validate WasPrice column"""
        column = 'WasPrice'
        results = {
            'passed': 0,
            'failed': 0,
            'issues': [],
            'failed_indices': []
        }

        if column not in self.df.columns:
            results['issues'].append(f"Column '{column}' missing from dataset")
            return results

        failed_indices = set()

        # WasPrice can be null, so only check non-null values
        non_null_mask = self.df[column].notna()

        if non_null_mask.sum() == 0:
            results['passed'] = len(self.df)
            return results

        # Check if numeric (for non-null values)
        numeric_mask = pd.to_numeric(self.df[column], errors='coerce').notna()
        non_numeric_count = (non_null_mask & ~numeric_mask).sum()
        if non_numeric_count > 0:
            results['issues'].append(f"{non_numeric_count} non-numeric WasPrice values")
            failed_indices.update(self.df[non_null_mask & ~numeric_mask].index.tolist())

        # Check if positive (for non-null values)
        positive_mask = (pd.to_numeric(self.df[column], errors='coerce') > 0)
        negative_count = (non_null_mask & ~positive_mask).sum()
        if negative_count > 0:
            results['issues'].append(f"{negative_count} non-positive WasPrice values")
            failed_indices.update(self.df[non_null_mask & ~positive_mask].index.tolist())

        # Check if WasPrice >= Price
        if 'Price' in self.df.columns:
            was_price_num = pd.to_numeric(self.df[column], errors='coerce')
            price_num = pd.to_numeric(self.df['Price'], errors='coerce')
            less_than_price = (non_null_mask & (was_price_num < price_num))
            less_count = less_than_price.sum()
            if less_count > 0:
                results['issues'].append(f"{less_count} WasPrice values less than Price")
                failed_indices.update(self.df[less_than_price].index.tolist())

        # Check conditional: If Offer_info exists, WasPrice should exist
        if 'Offer_info' in self.df.columns:
            has_offer = self.df['Offer_info'].notna()
            missing_was_price = has_offer & self.df[column].isna()
            missing_count = missing_was_price.sum()
            if missing_count > 0:
                results['issues'].append(f"{missing_count} records have Offer_info but missing WasPrice")
                failed_indices.update(self.df[missing_was_price].index.tolist())

        results['failed_indices'] = list(failed_indices)
        results['failed'] = len(failed_indices)
        results['passed'] = len(self.df) - results['failed']

        return results

    def check_rrp(self) -> Dict:
        """Validate RRP column"""
        column = 'RRP'
        results = {
            'passed': 0,
            'failed': 0,
            'issues': [],
            'failed_indices': []
        }

        if column not in self.df.columns:
            results['issues'].append(f"Column '{column}' missing from dataset")
            return results

        failed_indices = set()

        # Check for null values
        null_mask = self.df[column].isna()
        null_count = null_mask.sum()
        if null_count > 0:
            results['issues'].append(f"{null_count} null values found")
            failed_indices.update(self.df[null_mask].index.tolist())

        # Check if numeric
        numeric_mask = pd.to_numeric(self.df[column], errors='coerce').notna()
        non_numeric_count = (~numeric_mask & ~null_mask).sum()
        if non_numeric_count > 0:
            results['issues'].append(f"{non_numeric_count} non-numeric values")
            failed_indices.update(self.df[~numeric_mask & ~null_mask].index.tolist())

        # Business logic checks
        if 'Price' in self.df.columns and 'WasPrice' in self.df.columns:
            rrp_num = pd.to_numeric(self.df[column], errors='coerce')
            price_num = pd.to_numeric(self.df['Price'], errors='coerce')
            was_price_num = pd.to_numeric(self.df['WasPrice'], errors='coerce')

            # RRP should equal WasPrice if WasPrice exists, else equal Price
            has_was_price = self.df['WasPrice'].notna()

            # Where WasPrice exists, RRP should equal WasPrice
            rrp_not_equal_was = (has_was_price & (rrp_num != was_price_num))
            rrp_was_mismatch = rrp_not_equal_was.sum()
            if rrp_was_mismatch > 0:
                results['issues'].append(f"{rrp_was_mismatch} RRP values don't equal WasPrice when WasPrice exists")
                failed_indices.update(self.df[rrp_not_equal_was].index.tolist())

            # Where WasPrice doesn't exist, RRP should equal Price
            no_was_price = ~has_was_price
            rrp_not_equal_price = (no_was_price & (rrp_num != price_num))
            rrp_price_mismatch = rrp_not_equal_price.sum()
            if rrp_price_mismatch > 0:
                results['issues'].append(f"{rrp_price_mismatch} RRP values don't equal Price when WasPrice is missing")
                failed_indices.update(self.df[rrp_not_equal_price].index.tolist())

            # RRP must be >= Price
            rrp_less_than_price = (rrp_num < price_num)
            less_count = rrp_less_than_price.sum()
            if less_count > 0:
                results['issues'].append(f"{less_count} RRP values less than Price")
                failed_indices.update(self.df[rrp_less_than_price].index.tolist())

        results['failed_indices'] = list(failed_indices)
        results['failed'] = len(failed_indices)
        results['passed'] = len(self.df) - results['failed']

        return results

    def check_offer_info(self) -> Dict:
        """Validate Offer_info column"""
        column = 'Offer_info'
        results = {
            'passed': 0,
            'failed': 0,
            'issues': [],
            'failed_indices': []
        }

        if column not in self.df.columns:
            results['issues'].append(f"Column '{column}' missing from dataset")
            return results

        failed_indices = set()

        # Check for junk characters in non-null values
        non_null_mask = self.df[column].notna()
        if non_null_mask.sum() > 0:
            junk_mask = self.df[column].apply(self.has_junk_characters)
            junk_count = junk_mask.sum()
            if junk_count > 0:
                results['issues'].append(f"{junk_count} Offer_info with junk characters")
                failed_indices.update(self.df[junk_mask].index.tolist())

        # Conditional: If not null, WasPrice should also not be null
        if 'WasPrice' in self.df.columns:
            has_offer = self.df[column].notna()
            missing_was_price = has_offer & self.df['WasPrice'].isna()
            missing_count = missing_was_price.sum()
            if missing_count > 0:
                results['issues'].append(f"{missing_count} records have Offer_info but missing WasPrice")
                failed_indices.update(self.df[missing_was_price].index.tolist())

        results['failed_indices'] = list(failed_indices)
        results['failed'] = len(failed_indices)
        results['passed'] = len(self.df) - results['failed']

        return results

    def check_per_unit_price(self) -> Dict:
        """Validate per_unit_price column"""
        column = 'per_unit_price'
        results = {
            'passed': 0,
            'failed': 0,
            'issues': [],
            'failed_indices': []
        }

        if column not in self.df.columns:
            results['issues'].append(f"Column '{column}' missing from dataset")
            return results

        failed_indices = set()

        # Check pattern for non-null values
        non_null_mask = self.df[column].notna()
        if non_null_mask.sum() > 0:
            # Should contain numeric value and unit
            pattern_mask = self.df[column].str.contains(r'\d+\.?\d*', na=False)
            invalid_pattern = (non_null_mask & ~pattern_mask)
            invalid_count = invalid_pattern.sum()
            if invalid_count > 0:
                results['issues'].append(f"{invalid_count} per_unit_price without numeric values")
                failed_indices.update(self.df[invalid_pattern].index.tolist())

            # Business logic: Extract numeric value should align with Price/Pack_size
            if 'Price' in self.df.columns and 'Pack_size' in self.df.columns:
                # This is a complex validation that would require parsing pack sizes
                # Simplified check for now
                pass

        results['failed_indices'] = list(failed_indices)
        results['failed'] = len(failed_indices)
        results['passed'] = len(self.df) - results['failed']

        return results

    def check_pack_size(self) -> Dict:
        """Validate Pack_size column"""
        column = 'Pack_size'
        results = {
            'passed': 0,
            'failed': 0,
            'issues': [],
            'failed_indices': []
        }

        if column not in self.df.columns:
            results['issues'].append(f"Column '{column}' missing from dataset")
            return results

        failed_indices = set()

        # Check for junk characters and numeric pattern in non-null values
        non_null_mask = self.df[column].notna()
        if non_null_mask.sum() > 0:
            junk_mask = self.df[column].apply(self.has_junk_characters)
            junk_count = junk_mask.sum()
            if junk_count > 0:
                results['issues'].append(f"{junk_count} Pack_size with junk characters")
                failed_indices.update(self.df[junk_mask].index.tolist())

            # Should contain numeric value and unit
            pattern_mask = self.df[column].str.contains(r'\d+\.?\d*', na=False)
            invalid_pattern = (non_null_mask & ~pattern_mask)
            invalid_count = invalid_pattern.sum()
            if invalid_count > 0:
                results['issues'].append(f"{invalid_count} Pack_size without numeric values")
                failed_indices.update(self.df[invalid_pattern].index.tolist())

        results['failed_indices'] = list(failed_indices)
        results['failed'] = len(failed_indices)
        results['passed'] = len(self.df) - results['failed']

        return results

    def check_barcode(self) -> Dict:
        """Validate Barcode column"""
        column = 'Barcode'
        results = {
            'passed': 0,
            'failed': 0,
            'issues': [],
            'failed_indices': []
        }

        if column not in self.df.columns:
            results['issues'].append(f"Column '{column}' missing from dataset")
            return results

        failed_indices = set()

        # Check for non-null values
        non_null_mask = self.df[column].notna()
        if non_null_mask.sum() > 0:
            # Check if digits only
            digits_only = self.df[column].astype(str).str.match(r'^\d+$', na=False)
            non_digits = (non_null_mask & ~digits_only)
            non_digits_count = non_digits.sum()
            if non_digits_count > 0:
                results['issues'].append(f"{non_digits_count} barcodes with non-digit characters")
                failed_indices.update(self.df[non_digits].index.tolist())

            # Check valid lengths
            valid_length = self.df[column].apply(self.is_valid_barcode_length)
            invalid_length = (non_null_mask & ~valid_length)
            invalid_count = invalid_length.sum()
            if invalid_count > 0:
                results['issues'].append(f"{invalid_count} barcodes with invalid length")
                failed_indices.update(self.df[invalid_length].index.tolist())

        results['failed_indices'] = list(failed_indices)
        results['failed'] = len(failed_indices)
        results['passed'] = len(self.df) - results['failed']

        return results

    def check_category_hierarchy(self) -> Dict:
        """Validate Category_Hierarchy column"""
        column = 'Category_Hierarchy'
        results = {
            'passed': 0,
            'failed': 0,
            'issues': [],
            'failed_indices': []
        }

        if column not in self.df.columns:
            results['issues'].append(f"Column '{column}' missing from dataset")
            return results

        failed_indices = set()

        # Check blank threshold (less than 20% should be blank)
        blank_count = self.df[column].isna().sum()
        blank_percentage = (blank_count / len(self.df)) * 100
        if blank_percentage >= 20:
            results['issues'].append(f"{blank_percentage:.1f}% blank values (threshold: <20%)")
            # Don't add all blank indices as failures for threshold issues

        # Check delimiter consistency for non-null values
        non_null_mask = self.df[column].notna()
        if non_null_mask.sum() > 0:
            # Check for consistent delimiters
            has_arrow = self.df[column].str.contains(' > ', na=False).sum()
            has_slash = self.df[column].str.contains('/', na=False).sum()
            total_non_null = non_null_mask.sum()

            if has_arrow > 0 and has_slash > 0:
                results['issues'].append(f"Inconsistent delimiters found (both ' > ' and '/')")

        results['failed_indices'] = list(failed_indices)
        results['failed'] = len(failed_indices)
        results['passed'] = len(self.df) - results['failed']

        return results

    def check_brand(self) -> Dict:
        """Validate Brand column"""
        column = 'Brand'
        results = {
            'passed': 0,
            'failed': 0,
            'issues': [],
            'failed_indices': []
        }

        if column not in self.df.columns:
            results['issues'].append(f"Column '{column}' missing from dataset")
            return results

        failed_indices = set()

        # Check blank threshold (less than 20% should be blank)
        blank_count = self.df[column].isna().sum()
        blank_percentage = (blank_count / len(self.df)) * 100
        if blank_percentage >= 20:
            results['issues'].append(f"{blank_percentage:.1f}% blank values (threshold: <20%)")

        # Check for junk characters in non-null values
        non_null_mask = self.df[column].notna()
        if non_null_mask.sum() > 0:
            junk_mask = self.df[column].apply(self.has_junk_characters)
            junk_count = junk_mask.sum()
            if junk_count > 0:
                results['issues'].append(f"{junk_count} Brand values with junk characters")
                failed_indices.update(self.df[junk_mask].index.tolist())

        results['failed_indices'] = list(failed_indices)
        results['failed'] = len(failed_indices)
        results['passed'] = len(self.df) - results['failed']

        return results

    def check_promo_type(self) -> Dict:
        """Validate Promo_Type column"""
        column = 'Promo_Type'
        results = {
            'passed': 0,
            'failed': 0,
            'issues': [],
            'failed_indices': []
        }

        if column not in self.df.columns:
            results['issues'].append(f"Column '{column}' missing from dataset")
            return results

        failed_indices = set()

        # Check for junk characters in non-null values
        non_null_mask = self.df[column].notna()
        if non_null_mask.sum() > 0:
            junk_mask = self.df[column].apply(self.has_junk_characters)
            junk_count = junk_mask.sum()
            if junk_count > 0:
                results['issues'].append(f"{junk_count} Promo_Type values with junk characters")
                failed_indices.update(self.df[junk_mask].index.tolist())

        # Business logic: If exists, Offer_info should also exist
        if 'Offer_info' in self.df.columns:
            has_promo = self.df[column].notna()
            missing_offer = has_promo & self.df['Offer_info'].isna()
            missing_count = missing_offer.sum()
            if missing_count > 0:
                results['issues'].append(f"{missing_count} records have Promo_Type but missing Offer_info")
                failed_indices.update(self.df[missing_offer].index.tolist())

        results['failed_indices'] = list(failed_indices)
        results['failed'] = len(failed_indices)
        results['passed'] = len(self.df) - results['failed']

        return results

    def check_is_available(self) -> Dict:
        """Validate is_available column"""
        column = 'is_available'
        results = {
            'passed': 0,
            'failed': 0,
            'issues': [],
            'failed_indices': []
        }

        if column not in self.df.columns:
            results['issues'].append(f"Column '{column}' missing from dataset")
            return results

        failed_indices = set()

        # Check for null values
        null_mask = self.df[column].isna()
        null_count = null_mask.sum()
        if null_count > 0:
            results['issues'].append(f"{null_count} null values found")
            failed_indices.update(self.df[null_mask].index.tolist())

        # Check for valid boolean values
        valid_values = [True, False, 1, 0, '1', '0', 'True', 'False', 'true', 'false']
        non_null_data = self.df[column][~null_mask]
        invalid_mask = ~non_null_data.isin(valid_values)
        invalid_count = invalid_mask.sum()

        if invalid_count > 0:
            results['issues'].append(f"{invalid_count} invalid boolean values")
            invalid_indices = non_null_data[invalid_mask].index.tolist()
            failed_indices.update(invalid_indices)

        results['failed_indices'] = list(failed_indices)
        results['failed'] = len(failed_indices)
        results['passed'] = len(self.df) - results['failed']

        return results

    def run_all_checks(self) -> Dict:
        """Run all data quality checks"""
        print("Running PriceMate Data Quality Checks...")

        # Define all check functions
        checks = {
            'ProductURL': self.check_product_url,
            'ProductCode': self.check_product_code,
            'Name': self.check_name,
            'Price': self.check_price,
            'WasPrice': self.check_was_price,
            'RRP': self.check_rrp,
            'Offer_info': self.check_offer_info,
            'per_unit_price': self.check_per_unit_price,
            'Pack_size': self.check_pack_size,
            'Barcode': self.check_barcode,
            'Category_Hierarchy': self.check_category_hierarchy,
            'Brand': self.check_brand,
            'Promo_Type': self.check_promo_type,
            'is_available': self.check_is_available
        }

        # Run each check
        total_passed = 0
        total_failed = 0

        for column, check_func in checks.items():
            print(f"Checking {column}...")
            result = check_func()
            self.results['detailed_results'][column] = result
            total_passed += result['passed']
            total_failed += result['failed']

            # Store failed records for this column
            if result['failed_indices']:
                self.results['failed_records'][column] = result['failed_indices']

        # Calculate summary statistics
        self.results['summary'] = {
            'total_records': self.total_records,
            'total_passed': total_passed,
            'total_failed': total_failed,
            'pass_rate': (total_passed / (total_passed + total_failed)) * 100 if (total_passed + total_failed) > 0 else 0,
            'columns_checked': len(checks),
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

        # Calculate column-wise statistics
        self.results['statistics'] = {}
        for column in checks.keys():
            if column in self.results['detailed_results']:
                result = self.results['detailed_results'][column]
                self.results['statistics'][column] = {
                    'pass_rate': (result['passed'] / self.total_records) * 100,
                    'fail_rate': (result['failed'] / self.total_records) * 100,
                    'issue_count': len(result['issues'])
                }

        print(f"\nQuality Check Complete!")
        print(f"Overall Pass Rate: {self.results['summary']['pass_rate']:.2f}%")
        print(f"Total Issues Found: {total_failed}")

        return self.results

    def generate_html_report(self, output_file: str = None) -> str:
        """Generate comprehensive HTML report"""

        timestamp = datetime.now().strftime('%Y%m%d')
        if not output_file:
            output_file = f'E:/Kamaram/Projects/PriceMate/qa_reports/{timestamp}/PriceMate_QA_Report_{self.retailer}_{timestamp}.html'

        os.makedirs(f'E:/Kamaram/Projects/PriceMate/qa_reports/{timestamp}', exist_ok=True)

        # HTML template with embedded CSS
        html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PriceMate Data Quality Report For: {self.retailer}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f5f5f5;
        }}

        .container {{
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }}

        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem;
            border-radius: 10px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }}

        .header h1 {{
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }}

        .header .subtitle {{
            font-size: 1.2rem;
            opacity: 0.9;
        }}

        .summary-cards {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }}

        .card {{
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-left: 4px solid #667eea;
        }}

        .card h3 {{
            color: #667eea;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}

        .card .value {{
            font-size: 2rem;
            font-weight: bold;
            color: #333;
        }}

        .card.success {{
            border-left-color: #10b981;
        }}

        .card.success .value {{
            color: #10b981;
        }}

        .card.warning {{
            border-left-color: #f59e0b;
        }}

        .card.warning .value {{
            color: #f59e0b;
        }}

        .card.error {{
            border-left-color: #ef4444;
        }}

        .card.error .value {{
            color: #ef4444;
        }}

        .section {{
            background: white;
            margin-bottom: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }}

        .section-header {{
            background: #f8fafc;
            padding: 1rem 1.5rem;
            border-bottom: 1px solid #e2e8f0;
        }}

        .section-header h2 {{
            color: #1e293b;
            font-size: 1.25rem;
        }}

        .section-content {{
            padding: 1.5rem;
        }}

        .column-result {{
            margin-bottom: 1.5rem;
            padding: 1rem;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
        }}

        .column-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.5rem;
        }}

        .column-name {{
            font-weight: bold;
            font-size: 1.1rem;
            color: #1e293b;
        }}

        .status-badge {{
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: bold;
            text-transform: uppercase;
        }}

        .status-pass {{
            background: #dcfce7;
            color: #166534;
        }}

        .status-fail {{
            background: #fef2f2;
            color: #991b1b;
        }}

        .column-stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 1rem;
            margin: 1rem 0;
        }}

        .stat {{
            text-align: center;
            padding: 0.5rem;
            background: #f8fafc;
            border-radius: 6px;
        }}

        .stat .label {{
            font-size: 0.75rem;
            color: #64748b;
            text-transform: uppercase;
        }}

        .stat .value {{
            font-size: 1.25rem;
            font-weight: bold;
            color: #1e293b;
        }}

        .issues-list {{
            margin-top: 1rem;
        }}

        .issue {{
            padding: 0.5rem;
            margin: 0.25rem 0;
            background: #fef2f2;
            border-left: 3px solid #ef4444;
            border-radius: 4px;
            font-size: 0.9rem;
        }}

        .progress-bar {{
            width: 100%;
            height: 8px;
            background: #e2e8f0;
            border-radius: 4px;
            overflow: hidden;
            margin: 0.5rem 0;
        }}

        .progress-fill {{
            height: 100%;
            background: linear-gradient(90deg, #10b981, #059669);
            transition: width 0.3s ease;
        }}

        .footer {{
            text-align: center;
            padding: 2rem;
            color: #64748b;
            font-size: 0.9rem;
        }}

        .timestamp {{
            background: #f1f5f9;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            display: inline-block;
            margin-top: 1rem;
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 10px;
            }}

            .header h1 {{
                font-size: 2rem;
            }}

            .summary-cards {{
                grid-template-columns: 1fr;
            }}

            .column-stats {{
                grid-template-columns: repeat(2, 1fr);
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>🔍 PriceMate Data Quality Report For: {self.retailer}</h1>
            <div class="subtitle">Automated Quality Assessment for Product Data</div>
        </div>

        <!-- Summary Cards -->
        <div class="summary-cards">
            <div class="card">
                <h3>Total Records</h3>
                <div class="value">{self.results['summary']['total_records']:,}</div>
            </div>
            <div class="card success">
                <h3>Passed Validations</h3>
                <div class="value">{self.results['summary']['total_passed']:,}</div>
            </div>
            <div class="card error">
                <h3>Failed Validations</h3>
                <div class="value">{self.results['summary']['total_failed']:,}</div>
            </div>
            <div class="card {'success' if self.results['summary']['pass_rate'] >= 95 else 'warning' if self.results['summary']['pass_rate'] >= 80 else 'error'}">
                <h3>Overall Pass Rate</h3>
                <div class="value">{self.results['summary']['pass_rate']:.1f}%</div>
            </div>
        </div>

        <!-- Overall Progress -->
        <div class="section">
            <div class="section-header">
                <h2>📊 Overall Quality Score</h2>
            </div>
            <div class="section-content">
                <div class="progress-bar">
                    <div class="progress-fill" style="width: {self.results['summary']['pass_rate']:.1f}%"></div>
                </div>
                <p style="text-align: center; margin-top: 0.5rem; color: #64748b;">
                    {self.results['summary']['pass_rate']:.1f}% of all validations passed
                </p>
            </div>
        </div>

        <!-- Detailed Results -->
        <div class="section">
            <div class="section-header">
                <h2>📋 Detailed Column Analysis</h2>
            </div>
            <div class="section-content">"""

        # Add detailed results for each column
        for column, result in self.results['detailed_results'].items():
            pass_rate = (result['passed'] / self.total_records) * 100 if self.total_records > 0 else 0
            status_class = 'status-pass' if result['failed'] == 0 else 'status-fail'
            status_text = 'PASS' if result['failed'] == 0 else 'FAIL'

            html_content += f"""
                <div class="column-result">
                    <div class="column-header">
                        <div class="column-name">{column}</div>
                        <div class="status-badge {status_class}">{status_text}</div>
                    </div>

                    <div class="progress-bar">
                        <div class="progress-fill" style="width: {pass_rate:.1f}%"></div>
                    </div>

                    <div class="column-stats">
                        <div class="stat">
                            <div class="label">Passed</div>
                            <div class="value" style="color: #10b981;">{result['passed']:,}</div>
                        </div>
                        <div class="stat">
                            <div class="label">Failed</div>
                            <div class="value" style="color: #ef4444;">{result['failed']:,}</div>
                        </div>
                        <div class="stat">
                            <div class="label">Pass Rate</div>
                            <div class="value">{pass_rate:.1f}%</div>
                        </div>
                        <div class="stat">
                            <div class="label">Issues</div>
                            <div class="value">{len(result['issues'])}</div>
                        </div>
                    </div>"""

            # Add issues if any
            if result['issues']:
                html_content += """
                    <div class="issues-list">"""
                for issue in result['issues']:
                    html_content += f"""
                        <div class="issue">⚠️ {issue}</div>"""
                html_content += """
                    </div>"""

            html_content += """
                </div>"""

        # Close the detailed results section and add footer
        html_content += f"""
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <div>
                Report generated by PriceMate QA Tool
                <div class="timestamp">
                    📅 Generated on: {self.results['summary']['timestamp']}
                </div>
            </div>
        </div>
    </div>
</body>
</html>"""

        # Write HTML file
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)

        print(f"\n✅ HTML Report generated: {output_file}")
        return output_file


def QA_Check(df, retailer):

    print(f"PriceMate QA Tool - {retailer} Run")
    print("=" * 50)
    print(f"Sample dataset shape: {df.shape}")
    print(f"Columns: {list(df.columns)}")
    print()

    # df.pop('brand_filter')
    def review(s):
        if not s: return None

    # df_last["Price"] = pd.to_numeric(df_last["Price"], errors="coerce").astype("Float64")

    # df["Price"] = pd.to_numeric(df["Price"].apply(review), errors="coerce").astype("Float64")
    # df["WasPrice"] = pd.to_numeric(df["WasPrice"].apply(review).astype("Float64"))
    # df["RRP"] = pd.to_numeric(df["RRP"].apply(review).astype("Float64"))

    # Initialize QA tool
    qa_tool = PriceMateQATool(df, retailer)

    # Run all checks
    results = qa_tool.run_all_checks()

    # Generate HTML report
    report_file = qa_tool.generate_html_report()

    print(f"\n📊 Quick Summary:")
    print(f"   • Total Records: {results['summary']['total_records']}")
    print(f"   • Pass Rate: {results['summary']['pass_rate']:.1f}%")
    print(f"   • Failed Validations: {results['summary']['total_failed']}")
    print(f"   • Report saved as: {report_file}")


if __name__ == "__main__":
    """
        Example usage of the PriceMate QA Tool
    """
    # Sample data for demonstration
    sample_data = {
        'ProductURL': [
            'https://example.com/product1',
            'https://example.com/product2',
            'invalid-url',
            None,
            'https://example.com/product1'  # Duplicate
        ],
        'ProductCode': ['PROD001', 'PROD002', 'PROD@03', None, 'PROD004'],
        'Name': ['Valid Product Name', 'Another Product', '##', None, '12345'],
        'Price': [10.99, 25.50, -5.00, None, 'invalid'],
        'WasPrice': [15.99, None, 8.00, None, 30.00],
        'RRP': [15.99, 25.50, 15.00, None, 35.00],
        'Offer_info': ['50% Off', None, 'Special Deal', None, 'Limited Time'],
        'per_unit_price': ['$2.20/kg', None, 'invalid', None, '$1.50/unit'],
        'Pack_size': ['500g', None, '###', None, '2L'],
        'Barcode': ['1234567890123', None, 'ABC123', None, '12345'],
        'Category_Hierarchy': ['Food > Snacks > Chips', None, None, None, 'Beverages/Soft Drinks'],
        'Brand': ['BrandA', 'BrandB', '***', None, 'BrandC'],
        'Promo_Type': ['Discount', None, 'BOGO', None, 'Clearance'],
        'is_available': [True, False, 'invalid', None, 1]
    }

    # Create DataFrame
    # df = pd.DataFrame(sample_data)
    file_path = r"C:\Users\ultroneous\Downloads\UNT_E_storing_2025-06-10.xlsx"
    df = pd.read_excel(file_path)
    retailer = file_path.split("UNT_")[-1].split("_2025")[0]
    QA_Check(df, retailer)