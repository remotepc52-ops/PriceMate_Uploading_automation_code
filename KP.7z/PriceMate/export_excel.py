import pandas as pd
from pymongo import MongoClient
from datetime import datetime
import os


MONGO_URI = "mongodb://localhost:27017/"  # Change this if needed
DATABASE_NAME = "may_crawling_Petstock"             # Replace with your DB name
COLLECTION_NAME = "Product_Data_Second_site_02025_05_26"              # Replace with your collection name

# Export Settings
excel_path = "exports"
os.makedirs(excel_path, exist_ok=True)  # <-- add this line
# Folder path to save files
today = datetime.today().strftime('%Y-%m-%d')


def Export_Data(Website):
    # Connect to MongoDB
    client = MongoClient(MONGO_URI)
    db = client[DATABASE_NAME]
    product_data = db[COLLECTION_NAME]

    # Retrieve data from MongoDB and load it into a DataFrame
    data = list(product_data.find({"Status": "Done"}).limit(1000000))
    df = pd.DataFrame(data)

    # Specify the columns you want to export
    columns_to_export = [
        "ProductUrl", "ProductCode", "Name", "Price", "WasPrice", "RRP",
        "Offer_info", "Images", "per_unit_price", "Pack_size", "Barcode", "ParentCode", "retailer_name",
        "Category_Hierarchy", "Brand", "is_available", "Promo_Type","Status"
    ]
    df = df[columns_to_export]

    # Insert Sr. No. column as the first column
    df.insert(0, '#', range(1, len(df) + 1))
    df.insert(1, 'Id', range(1, len(df) + 1))

    # Drop the MongoDB default '_id' column if it exists
    if '_id' in df.columns:
        df.drop('_id', axis=1, inplace=True)

    # Save DataFrame to Excel file
    excel_file_path = f'{excel_path}\\UNT_site-{Website}_{today}.xlsx'
    df.to_excel(
    excel_file_path,
    index=False
)
    print(f"Excel file saved to {excel_file_path}")

    # Save DataFrame to JSON file
    json_file_path = f'{excel_path}\\UNT_site-{Website}_{today}.json'
    df.to_json(json_file_path, orient='records', lines=True)
    print(f"JSON file saved to {json_file_path}")


if __name__ == '__main__':
    website = "Petstock"  # Change this to your actual website name
    Export_Data(website)
