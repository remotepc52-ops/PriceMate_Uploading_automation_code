import requests
from lxml import html
import pymongo
import pandas as pd
from datetime import datetime
import re
from urllib.parse import urljoin
import time
import logging
import os
import hashlib
import json

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# HTML Cache directory
region = "sg"

CACHE_DIR = f"html_cache/{region}"
if not os.path.exists(CACHE_DIR):
    os.makedirs(CACHE_DIR)


# MongoDB connection
client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client["Syioknyn_Data"]
urls_collection = db[f"pending_urls_{region}"]
products_collection = db[f"products_{region}"]
if region == 'sg':
    cookies = {
        'PHPSESSID': '9532dig2agcmt8erclt84srk53',
        '_ga': 'GA1.2.150224127.1756271382',
        '_gid': 'GA1.2.376149613.1756448055',
    }
    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-US,en;q=0.9,hi;q=0.8',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',
        # 'cookie': 'iUUID=2cf9ef1cc3626126d0885fe6c2c892b5; _cc_id=4e1b920cb170809e08b70b3eec3a14c0; panoramaId_expiry=1756876182963; panoramaId=734a305583d1365bae5682444df316d53938eef81bdcd2fb39d68e0841aabf9d; panoramaIdType=panoIndiv; __qca=P1-6f7177c7-6409-48fc-ae30-75a233a99636; cto_bidid=0nJTqV9ZJTJCV0Q0cHFTOGdhS1RiQWpLdzd1cjQxRU9mckhHQlFtcHY0VTI2TkZwTTgyM0I5UTFDNGo5ZmExMzdnTVA0NW9oJTJGbUxPcG15bHRYekFNWklxeGRnMHhCQjAyaXU3OTJsdExsdGJHWHpkQUElM0Q; cto_bundle=ad4K919vZnRKdHJiOENVMU1vdVRZTld3cWRxVm4wMVRJV0VPZXJWam83eFVENllVeDVoamQxaVJNVnF5cHl0RjVwUyUyQkhEVkpLa3ZOb1JBYSUyQld6VWNOS2p6aFp0UFY5WndnS21oZm01MXZEMzlKZWk4bVlMbHpUVFlZS3VTMmRtUGdFU0VxRGtPNVF1UEdTWE9mc0UxZEk3YUdpQmdNJTJGNDJqMnRGVkhubGFoc1lxTE9sJTJGWUYlMkJnbmJBOFQxbzNCdjhjRFk4Q0trZ0ElMkZwOHZUSTMlMkZkUTVpMldMJTJCZyUzRCUzRA; __gads=ID=9a812f6283f51a9b:T=1756271382:RT=1756279116:S=ALNI_MbWlTltXoWYBohILXRzGDeXxNc1lw; __gpi=UID=00001186d944a2cc:T=1756271382:RT=1756279116:S=ALNI_Ma6cCdQ2KdcTSoI1TsvLwFoWsbPuQ; _ga_7B6JB44444=GS2.1.s1756289342$o3$g0$t1756289342$j60$l0$h0; PHPSESSID=9532dig2agcmt8erclt84srk53; __eoi=ID=c8eca6ce0c09d28b:T=1756271382:RT=1756448048:S=AA-AfjbizfOCH2q2ajxwA3Dvirl-; _ga_69QG9X71K6=GS2.1.s1756448048$o1$g0$t1756448050$j58$l0$h0; _ga=GA1.2.150224127.1756271382; _gid=GA1.2.376149613.1756448055; wssplashchk=72cd81749e264ff6ec43926e6bb9f509919b4f19.1756451838.1',
    }
else:
    # Headers from curl
    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-US,en;q=0.9,hi;q=0.8',
        # 'referer': 'https://www.syioknya.com/promotions/99%2BSpeedmart',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36'
    }

    cookies = {
        'PHPSESSID': 'm28qmm25d9domdofdef21fgso2',
        '_ga': 'GA1.2.150224127.1756271382',
        '_gid': 'GA1.2.1336964408.1756271383',
    }

current_proxy = '2c6ea6e6d8c14216a62781b8f850cd5b'

proxy_host = "api.zyte.com"
proxy_port = "8011"
proxy_auth = f"{current_proxy}:"

proxies = {
    "http": "https://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port),
    "https": "http://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port)
}
# Date extraction patterns - Fixed to handle "Until 16 September" without year
date_patterns = [
    r'Until\s+(\d{1,2}\s+\w+\s+\d{4})',  # "Until 16 September 2025"
    r'until\s+(\d{1,2}\s+\w+\s+\d{4})',  # "until 16 September 2025"
    r'Until\s+(\d{1,2}\s+\w+)',  # "Until 16 September" (without year)
    r'until\s+(\d{1,2}\s+\w+)',  # "until 16 September" (without year)
    r'(\d{1,2}\s+\w+\s+\d{4})',  # "16 September 2025"
    r'(\d{1,2}\/\d{1,2}\/\d{4})',  # "16/09/2025"
    r'(\d{1,2}-\d{1,2}-\d{4})',  # "16-09-2025"
]

def extract_date_from_title(title):
    """
    Enhanced date extraction from title with comprehensive regex patterns
    Handles various date formats found in promotion titles
    """

    # Month abbreviations mapping for proper parsing
    month_mapping = {
        'jan': 'january', 'feb': 'february', 'mar': 'march', 'apr': 'april',
        'may': 'may', 'jun': 'june', 'jul': 'july', 'aug': 'august',
        'sep': 'september', 'sept': 'september', 'oct': 'october',
        'nov': 'november', 'dec': 'december'
    }

    # Comprehensive date patterns ordered by specificity
    date_patterns = [
        # "valid until DD MMM YYYY" format
        r'valid\s+until\s+(\d{1,2}\s+\w+\s+\d{4})',

        # "until DD MMM YYYY" format
        r'until\s+(\d{1,2}\s+\w+\s+\d{4})',

        # "until DD MMM" format (without year)
        r'until\s+(\d{1,2}\s+\w+)',

        # IMPROVED: Handle "DD-DD MMM YYYY" patterns - capture end day, month, year separately
        r'\((\d{1,2})[-–](\d{1,2})\s+(\w+)\s+(\d{4})\)',
        r'(\d{1,2})[-–](\d{1,2})\s+(\w+)\s+(\d{4})',

        # Date ranges: "MMM DD - MMM DD, YYYY" format like "April 25 - May 8, 2024"
        r'\w+\s+\d{1,2}\s*[-–]\s*(\w+\s+\d{1,2}),\s*(\d{4})',

        # "MMM DD-DD, YYYY" format like "May 3-5, 2024" or "April 20-21, 2024"
        r'(\w+)\s+(\d{1,2})[-–](\d{1,2}),\s*(\d{4})',

        # Date ranges: "DD MMM YYYY - DD MMM YYYY" (extract end date)
        r'\d{1,2}\s+\w+\s+\d{4}\s*[-–]\s*(\d{1,2}\s+\w+\s+\d{4})',

        # Date ranges: "DD MMM - DD MMM YYYY" (extract end date with year)
        r'\d{1,2}\s+\w+\s*[-–]\s*(\d{1,2}\s+\w+\s+\d{4})',

        # Date ranges with parentheses: "(DD MMM YYYY - DD MMM YYYY)"
        r'\(\d{1,2}\s+\w+\s+\d{4}\s*[-–]\s*(\d{1,2}\s+\w+\s+\d{4})\)',

        # "DD & DD MMM YYYY" format like "7 & 8 July 2024"
        r'\d{1,2}\s*&\s*(\d{1,2})\s+(\w+)\s+(\d{4})',

        # "from DD to DD MMM YYYY" format
        r'from\s+\d{1,2}\s+to\s+(\d{1,2}\s+\w+\s+\d{4})',
        r'from\s+\d{1,2}\s+to\s+(\d{1,2}\s+\w+)',  # without year

        # Single date in parentheses with various formats
        r'\(.*?[-–]\s*(\d{1,2}\s+\w+\s+\d{4})\)',

        # Standalone date formats
        r'(\d{1,2}\s+\w+\s+\d{4})',  # "28 Jan 2021"

        # Numeric date formats
        r'(\d{1,2}\/\d{1,2}\/\d{4})',  # "28/01/2021"
        r'(\d{1,2}-\d{1,2}-\d{4})',  # "28-01-2021"
        r'(\d{4}-\d{1,2}-\d{1,2})',  # "2021-01-28"
    ]

    def normalize_month(month_str):
        """Normalize month abbreviations to full names"""
        month_lower = month_str.lower()
        return month_mapping.get(month_lower, month_str)

    for pattern in date_patterns:
        match = re.search(pattern, title, re.IGNORECASE)
        if match:
            groups = match.groups()

            try:
                # Handle different capture group scenarios
                if len(groups) == 1:
                    date_str = groups[0].strip()

                    # Handle different date formats
                    if '/' in date_str:
                        # DD/MM/YYYY format
                        date_obj = datetime.strptime(date_str, '%d/%m/%Y')
                    elif '-' in date_str and len(date_str.split('-')[0]) == 4:
                        # YYYY-MM-DD format
                        date_obj = datetime.strptime(date_str, '%Y-%m-%d')
                    elif '-' in date_str and not any(alpha.isalpha() for alpha in date_str):
                        # DD-MM-YYYY format (numeric only)
                        date_obj = datetime.strptime(date_str, '%d-%m-%Y')
                    else:
                        # Handle text dates with comma removal
                        date_str = date_str.replace(',', '')
                        parts = date_str.split()

                        if len(parts) == 2:
                            # "16 September" (without year) - assume current year
                            current_year = datetime.now().year
                            day, month = parts
                            normalized_month = normalize_month(month)
                            date_str_with_year = f"{day} {normalized_month} {current_year}"
                            date_obj = datetime.strptime(date_str_with_year, '%d %B %Y')
                        elif len(parts) == 3:
                            # "16 September 2025" or "16 Sept 2025"
                            day, month, year = parts
                            normalized_month = normalize_month(month)
                            normalized_date_str = f"{day} {normalized_month} {year}"
                            date_obj = datetime.strptime(normalized_date_str, '%d %B %Y')
                        else:
                            continue

                elif len(groups) == 2:
                    # Handle different 2-group scenarios
                    if groups[1].isdigit() and len(groups[1]) == 4:
                        # Month and Year format like ('May', '2024')
                        month_str, year_str = groups
                        normalized_month = normalize_month(month_str)

                        # Get last day of the month
                        temp_date = datetime.strptime(f"1 {normalized_month} {year_str}", '%d %B %Y')
                        if temp_date.month == 12:
                            next_month = temp_date.replace(year=temp_date.year + 1, month=1)
                        else:
                            next_month = temp_date.replace(month=temp_date.month + 1)

                        from datetime import timedelta
                        last_day = next_month - timedelta(days=1)
                        date_obj = last_day
                    else:
                        # Handle "May 8, 2024" format - remove comma and parse
                        date_str = f"{groups[0]} {groups[1]}".replace(',', '')
                        parts = date_str.split()
                        if len(parts) == 3:
                            month, day, year = parts
                            normalized_month = normalize_month(month)
                            normalized_date_str = f"{day} {normalized_month} {year}"
                            date_obj = datetime.strptime(normalized_date_str, '%d %B %Y')
                        else:
                            continue

                elif len(groups) == 3:
                    # Handle 3-group scenarios like ('7', 'July', '2024') or ('May', '3', '2024')
                    if groups[2].isdigit() and len(groups[2]) == 4:
                        # Check if first group is day or month
                        if groups[0].isdigit():
                            # Format: day, month, year like ('7', 'July', '2024')
                            day, month, year = groups
                            normalized_month = normalize_month(month)
                            date_str = f"{day} {normalized_month} {year}"
                            date_obj = datetime.strptime(date_str, '%d %B %Y')
                        else:
                            # Format: month, day, year like ('May', '3', '2024')
                            month, day, year = groups
                            normalized_month = normalize_month(month)
                            date_str = f"{day} {normalized_month} {year}"
                            date_obj = datetime.strptime(date_str, '%d %B %Y')
                    else:
                        continue

                elif len(groups) == 4:
                    # Handle "DD-DD MMM YYYY" format where we capture start_day, end_day, month, year
                    # or "MMM DD-DD YYYY" format like ('May', '3', '5', '2024')
                    if all(g.isdigit() for g in groups[1:]):
                        # Format: month, start_day, end_day, year
                        month, start_day, end_day, year = groups
                        normalized_month = normalize_month(month)
                        date_str = f"{end_day} {normalized_month} {year}"
                        date_obj = datetime.strptime(date_str, '%d %B %Y')
                    else:
                        # Format: start_day, end_day, month, year
                        start_day, end_day, month, year = groups
                        normalized_month = normalize_month(month)
                        date_str = f"{end_day} {normalized_month} {year}"
                        date_obj = datetime.strptime(date_str, '%d %B %Y')

                else:
                    continue

                return date_obj.strftime('%d-%b-%Y')

            except ValueError as e:
                # Log the failed parsing for debugging
                print(f"Failed to parse date groups '{groups}' from title: {title}")
                continue

    return ''

def get_cache_filename(url):
    """Generate cache filename from URL"""
    url_hash = hashlib.md5(url.encode()).hexdigest()
    return os.path.join(CACHE_DIR, f"{url_hash}.html")


def save_html_to_cache(url, html_content):
    """Save HTML content to cache"""
    try:
        cache_file = get_cache_filename(url)

        cache_data = {
            'url': url,
            'html': html_content,
            'cached_at': datetime.now().isoformat()
        }

        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(cache_data, f, ensure_ascii=False, indent=2)

        logger.info(f"Cached HTML for: {url}")
    except Exception as e:
        logger.error(f"Failed to cache HTML for {url}: {str(e)}")


def load_html_from_cache(url):
    """Load HTML content from cache"""
    try:
        cache_file = get_cache_filename(url)
        if os.path.exists(cache_file):
            with open(cache_file, 'r', encoding='utf-8') as f:
                cache_data = json.load(f)
            logger.info(f"Loaded from cache: {url}")
            return cache_data['html']
    except Exception as e:
        logger.error(f"Failed to load cache for {url}: {str(e)}")
    return None


def fetch_page(url, use_cache=True):
    """Fetch and parse web page with caching"""
    # Try to load from cache first
    if use_cache:
        cached_html = load_html_from_cache(url)
        if cached_html:
            return html.fromstring(cached_html)

    # Fetch from web
    try:
        if region == 'sg':
            response = requests.get(url, headers=headers, cookies=cookies, proxies=proxies, verify='zyte-ca.crt', timeout=30)
        else:

            response = requests.get(url, headers=headers, cookies=cookies, timeout=30)
        response.raise_for_status()

        html_content = response.text

        # Save to cache
        if use_cache:
            save_html_to_cache(url, html_content)

        return html.fromstring(html_content)
    except Exception as e:
        logger.error(f"Failed to fetch {url}: {str(e)}")
        return None

def build_pagination_url(parent_url, page_num):
    """Build pagination URL like /page/2"""
    if page_num == 1:
        return parent_url
    else:
        return f"{parent_url}/page/{page_num}"

def crawl_all_pages(parent_url, retailer, max_pages=10, use_cache=True):
    """Crawl all pages with pagination and caching"""
    all_data = []

    for page_num in range(1, max_pages + 1):
        url = build_pagination_url(parent_url, page_num)
        logger.info(f"Scraping page {page_num}: {url}")

        page_data = scrape_page(url, parent_url, retailer, use_cache=use_cache)

        # If no data found, assume no more pages
        if not page_data:
            logger.info(f"No data found on page {page_num}, stopping pagination")
            break

        all_data.extend(page_data)

        # Rate limiting (skip if using cache)
        if not use_cache:
            time.sleep(1)

    return all_data


def scrape_page(url, parent_url, retailer, use_cache=True):
    """Scrape single page with caching option"""
    tree = fetch_page(url, use_cache=use_cache)
    if not tree:
        return []

    page_data = []

    # Extract data using XPaths
    titles = tree.xpath('//div[@class="row"]//h2//a[@class="ListTitleLink"]/@title')
    urls = tree.xpath('//div[@class="row"]//h2//a[@class="ListTitleLink"]/@href')
    start_dates = tree.xpath('//p[@class="ListDate"]//i/text()')

    logger.info(f"Found {len(titles)} items on {url}")

    # Process each item
    for i in range(len(titles)):
        item_url = urljoin(url, urls[i]) if i < len(urls) else ''
        start_date = start_dates[i].strip() if i < len(start_dates) else ''
        title = titles[i] if i < len(titles) else ''
        try:end_date = extract_date_from_title(title)
        except: end_date = ""

        item_data = {
            'parent_url': parent_url,
            'retailer': retailer,
            'title': title,
            'url': item_url,
            'type': 'Social',
            'start': start_date,
            'end': end_date,
            'scraped_at': datetime.now().isoformat(),
            'source_page': url
        }

        # Check for blank fields
        blank_fields = []
        for field, value in item_data.items():
            if field not in ['scraped_at', 'source_page'] and not value:
                blank_fields.append(field)

        if blank_fields:
            logger.warning(f"Blank fields in item {i + 1}: {blank_fields} - Title: {title}")

        page_data.append(item_data)

    return page_data


def save_to_mongodb(data):
    """Save data to MongoDB"""
    if data:
        result = products_collection.insert_many(data)
        logger.info(f"Saved {len(result.inserted_ids)} items to MongoDB")


def generate_excel_report(data):
    """Generate Excel report"""
    if not data:
        logger.warning("No data to export")
        return

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"syioknya_promotions_{timestamp}.xlsx"

    # Create DataFrame
    df = pd.DataFrame(data)

    # Reorder columns
    columns = ['parent_url', 'retailer', 'title', 'url', 'type', 'start', 'end', 'scraped_at', 'source_page']
    df = df.reindex(columns=columns)

    # Export to Excel
    df.to_excel(filename, index=False, engine='openpyxl')
    logger.info(f"Excel report generated: {filename}")

    return filename


def main():
    """Main function"""
    logger.info("Starting scraper...")

    # Test the date extraction function
    test_title = "99 Speedmart Merdeka Promotion 2025 – Best Deals Until 16 September"
    test_date = extract_date_from_title(test_title)
    logger.info(f"Date extraction test: '{test_title}' -> '{test_date}'")

    # Get pending URLs from MongoDB
    pending_urls = list(urls_collection.find({'status': 'pending'}))

    if not pending_urls:
        # Insert sample URL if none exists
        sample_url = {
            "parent_url": "https://www.syioknya.com/promotions/99%2BSpeedmart",
            "retailer": "99 Speedmart",
            "status": "pending",
            "created_at": datetime.now()
        }
        # urls_collection.insert_one(sample_url)
        pending_urls = [sample_url]
        logger.info("Inserted sample URL")

    all_scraped_data = []

    # Process each pending URL
    for url_doc in pending_urls:
        parent_url = url_doc['Parent URL']
        retailer = url_doc['Retailer']

        logger.info(f"Processing: {parent_url} - {retailer}")

        # Crawl all pages (use_cache=True for testing)
        data = crawl_all_pages(parent_url, retailer, max_pages=20, use_cache=True)

        if data:
            # Save to MongoDB
            save_to_mongodb(data)
            all_scraped_data.extend(data)

            # Mark as processed
            urls_collection.update_one(
                {'_id': url_doc['_id']},
                {'$set': {'status': 'processed', 'processed_at': datetime.now()}}
            )

        # Rate limiting between URLs
        time.sleep(2)

    # Generate Excel report
    if all_scraped_data:
        generate_excel_report(all_scraped_data)
        logger.info(f"Scraping completed. Total items: {len(all_scraped_data)}")

        # Show summary
        print("\n=== SCRAPING SUMMARY ===")
        print(f"Total items scraped: {len(all_scraped_data)}")
        print(f"Items with missing end dates: {len([item for item in all_scraped_data if not item['end']])}")
        print(f"Items with missing start dates: {len([item for item in all_scraped_data if not item['start']])}")
        print(f"Items with missing titles: {len([item for item in all_scraped_data if not item['title']])}")
        print(f"HTML pages cached in: {CACHE_DIR}")
    else:
        logger.warning("No data scraped")

    # Close MongoDB connection
    client.close()


if __name__ == "__main__":
    main()