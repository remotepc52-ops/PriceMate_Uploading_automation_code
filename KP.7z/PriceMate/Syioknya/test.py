import requests

# cookies = {
#     'iUUID': '2cf9ef1cc3626126d0885fe6c2c892b5',
#     '_cc_id': '4e1b920cb170809e08b70b3eec3a14c0',
#     'panoramaId_expiry': '1756876182963',
#     'panoramaId': '734a305583d1365bae5682444df316d53938eef81bdcd2fb39d68e0841aabf9d',
#     'panoramaIdType': 'panoIndiv',
#     '__qca': 'P1-6f7177c7-6409-48fc-ae30-75a233a99636',
#     'cto_bidid': '0nJTqV9ZJTJCV0Q0cHFTOGdhS1RiQWpLdzd1cjQxRU9mckhHQlFtcHY0VTI2TkZwTTgyM0I5UTFDNGo5ZmExMzdnTVA0NW9oJTJGbUxPcG15bHRYekFNWklxeGRnMHhCQjAyaXU3OTJsdExsdGJHWHpkQUElM0Q',
#     'cto_bundle': 'ad4K919vZnRKdHJiOENVMU1vdVRZTld3cWRxVm4wMVRJV0VPZXJWam83eFVENllVeDVoamQxaVJNVnF5cHl0RjVwUyUyQkhEVkpLa3ZOb1JBYSUyQld6VWNOS2p6aFp0UFY5WndnS21oZm01MXZEMzlKZWk4bVlMbHpUVFlZS3VTMmRtUGdFU0VxRGtPNVF1UEdTWE9mc0UxZEk3YUdpQmdNJTJGNDJqMnRGVkhubGFoc1lxTE9sJTJGWUYlMkJnbmJBOFQxbzNCdjhjRFk4Q0trZ0ElMkZwOHZUSTMlMkZkUTVpMldMJTJCZyUzRCUzRA',
#     '__gads': 'ID=9a812f6283f51a9b:T=1756271382:RT=1756279116:S=ALNI_MbWlTltXoWYBohILXRzGDeXxNc1lw',
#     '__gpi': 'UID=00001186d944a2cc:T=1756271382:RT=1756279116:S=ALNI_Ma6cCdQ2KdcTSoI1TsvLwFoWsbPuQ',
#     '_ga_7B6JB44444': 'GS2.1.s1756289342$o3$g0$t1756289342$j60$l0$h0',
#     'PHPSESSID': '9532dig2agcmt8erclt84srk53',
#     '__eoi': 'ID=c8eca6ce0c09d28b:T=1756271382:RT=1756448048:S=AA-AfjbizfOCH2q2ajxwA3Dvirl-',
#     '_ga_69QG9X71K6': 'GS2.1.s1756448048$o1$g0$t1756448050$j58$l0$h0',
#     '_ga': 'GA1.2.150224127.1756271382',
#     '_gid': 'GA1.2.376149613.1756448055',
#     'wssplashchk': '72cd81749e264ff6ec43926e6bb9f509919b4f19.1756451838.1',
# }
cookies = {
    'PHPSESSID': '9532dig2agcmt8erclt84srk53',
     '_ga': 'GA1.2.150224127.1756271382',
    '_gid': 'GA1.2.376149613.1756448055',
}
headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9,hi;q=0.8',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',
    # 'cookie': 'iUUID=2cf9ef1cc3626126d0885fe6c2c892b5; _cc_id=4e1b920cb170809e08b70b3eec3a14c0; panoramaId_expiry=1756876182963; panoramaId=734a305583d1365bae5682444df316d53938eef81bdcd2fb39d68e0841aabf9d; panoramaIdType=panoIndiv; __qca=P1-6f7177c7-6409-48fc-ae30-75a233a99636; cto_bidid=0nJTqV9ZJTJCV0Q0cHFTOGdhS1RiQWpLdzd1cjQxRU9mckhHQlFtcHY0VTI2TkZwTTgyM0I5UTFDNGo5ZmExMzdnTVA0NW9oJTJGbUxPcG15bHRYekFNWklxeGRnMHhCQjAyaXU3OTJsdExsdGJHWHpkQUElM0Q; cto_bundle=ad4K919vZnRKdHJiOENVMU1vdVRZTld3cWRxVm4wMVRJV0VPZXJWam83eFVENllVeDVoamQxaVJNVnF5cHl0RjVwUyUyQkhEVkpLa3ZOb1JBYSUyQld6VWNOS2p6aFp0UFY5WndnS21oZm01MXZEMzlKZWk4bVlMbHpUVFlZS3VTMmRtUGdFU0VxRGtPNVF1UEdTWE9mc0UxZEk3YUdpQmdNJTJGNDJqMnRGVkhubGFoc1lxTE9sJTJGWUYlMkJnbmJBOFQxbzNCdjhjRFk4Q0trZ0ElMkZwOHZUSTMlMkZkUTVpMldMJTJCZyUzRCUzRA; __gads=ID=9a812f6283f51a9b:T=1756271382:RT=1756279116:S=ALNI_MbWlTltXoWYBohILXRzGDeXxNc1lw; __gpi=UID=00001186d944a2cc:T=1756271382:RT=1756279116:S=ALNI_Ma6cCdQ2KdcTSoI1TsvLwFoWsbPuQ; _ga_7B6JB44444=GS2.1.s1756289342$o3$g0$t1756289342$j60$l0$h0; PHPSESSID=9532dig2agcmt8erclt84srk53; __eoi=ID=c8eca6ce0c09d28b:T=1756271382:RT=1756448048:S=AA-AfjbizfOCH2q2ajxwA3Dvirl-; _ga_69QG9X71K6=GS2.1.s1756448048$o1$g0$t1756448050$j58$l0$h0; _ga=GA1.2.150224127.1756271382; _gid=GA1.2.376149613.1756448055; wssplashchk=72cd81749e264ff6ec43926e6bb9f509919b4f19.1756451838.1',
}

current_proxy = '2c6ea6e6d8c14216a62781b8f850cd5b'

proxy_host = "api.zyte.com"
proxy_port = "8011"
proxy_auth = f"{current_proxy}:"

proxies = {
    "http": "https://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port),
    "https": "http://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port)
}

response = requests.get('https://sg.syioknya.com/promotions/guardian', cookies=cookies, headers=headers, proxies=proxies, verify='zyte-ca.crt')
print(response.text)
print(response.status_code)